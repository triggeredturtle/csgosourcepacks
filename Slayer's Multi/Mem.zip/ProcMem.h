#ifndef PROCMEM_H
#define PROCMEM_H

#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <iostream>
#include <TlHelp32.h>
#include <string>
#include <sstream>

class ProcMem{
protected:


	HANDLE hProcess;
	DWORD dwPID, dwProtection, dwCaveAddress;


	BOOL bPOn, bIOn, bProt;
	bool CompareData(const BYTE*, const BYTE*, const char*);


public:


	ProcMem();
	~ProcMem();
	int chSizeOfArray(char *chArray);
	int iSizeOfArray(int *iArray);
	bool iFind(int *iAry, int iVal);
	DWORD FindPattern(DWORD, DWORD, const char*, const char*);
	DWORD FindArray(DWORD, DWORD, const char*, int, ...);


#pragma region TEMPLATE MEMORY FUNCTIONS



	template <class cData>
	cData Read(DWORD dwAddress)
	{
		cData cRead;
		ReadProcessMemory(hProcess, (LPVOID)dwAddress, &cRead, sizeof(cData), NULL);
		return cRead;
	}


	template <class cData>
	cData Read(DWORD dwAddress, char *Offset, BOOL Type)
	{

		int iSize = iSizeOfArray(Offset) - 1;
		dwAddress = Read<DWORD>(dwAddress);


		for (int i = 0; i < iSize; i++)
			dwAddress = Read<DWORD>(dwAddress + Offset[i]);

		if (!Type)
			return dwAddress + Offset[iSize];
		else
			return Read<cData>(dwAddress + Offset[iSize]);
	}


	template <class cData>
	void Read(DWORD dwAddress, cData Value)
	{
		ReadProcessMemory(hProcess, (LPVOID)dwAddress, &Value, sizeof(cData), NULL);
	}


	template <class cData>
	void Read(DWORD dwAddress, char *Offset, cData Value)
	{
		Read<cData>(Read<cData>(dwAddress, Offset, false), Value);
	}

	template <class Mem>
	void Write(DWORD dwAddress, Mem value)
	{
		WriteProcessMemory(hProcess, (LPVOID)dwAddress, &value, sizeof(Mem), NULL);
	}

	virtual void Process(char* ProcessName);
	virtual void Patch(DWORD dwAddress, char *chPatch_Bts, char *chDefault_Bts);
	virtual DWORD AOB_Scan(DWORD dwAddress, DWORD dwEnd, char *chPattern);
	virtual DWORD Module(LPSTR ModuleName);

#pragma endregion

};
#endif


struct GlowObject
{
	DWORD Entity;
	float red;
	float green;
	float blue;
	float alpha;
	uint8_t unk1[16];
	bool renderOccluded;
	bool renderNotOccluded;
	bool colorFill;
	uint8_t unk2[14];
};
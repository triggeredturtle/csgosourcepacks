#pragma once
#include <Windows.h>
#include <iostream>


void SetColor(int = 7);

void Print(std::string, int = 3, int = 2, int = 40);
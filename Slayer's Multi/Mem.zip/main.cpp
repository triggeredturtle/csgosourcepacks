#include "Text.h"
#include "ProcMem.h"
#include <Windows.h>
#include <iostream>
#include <thread>
#include <TlHelp32.h>
#include <fstream>
#include "slimMem.h"


#define FL_ONGROUND (1 << 0)


ProcMem PM;
GlowObject Glow;

typedef struct
{
	float x, y, z;
}Vector;

//Offsets
const DWORD playerHealth = 0x000000FC;
const DWORD playerCross = 0x0000AA70;
const DWORD playerLoop = 0x00000010;
const DWORD playerTeam = 0x000000F0;
const DWORD entBase = 0x04AC91B4;
const DWORD playerFlags = 0x100;
const DWORD forceJump = 0x04F5FCE4;
const DWORD enginePointer = 0x005CA534;
const DWORD glowPointer = 0x04FE39B4;
const DWORD playerSpotted = 0x939;
const DWORD playerDefusing = 0x38A4;
const DWORD playerReloading = 0x3245;
const DWORD lPlayerIndex = 0x178;
const DWORD spottedByMask = 0x97C;
const DWORD playerBase = 0xAA6834;
const DWORD localPlayerIndex = 0x00000178;
const DWORD FlashMaxAlpha = 0xA304;
const DWORD FlashDuration = 0xA308;
const DWORD radarBase = 0x04EFDF0C;
const DWORD shotsFired = 0x0000A2C0;
const DWORD setView = 0x00004D0C;
const DWORD AimPunch = 0x00000301C;

//Vars
DWORD pid;
DWORD cMod;
DWORD dMod;
DWORD localPlayer;
DWORD engineBase;
DWORD localIndex;
DWORD spotByMe;
DWORD glowBase;
DWORD enemyInC;
DWORD enemyBase;
DWORD triggerKey = 0x04;
int enemyTeam;
int enemyHealth;
int localTeam;
int crossID;
int localPlayerFlag;
int connectState;
int entityCount;
int entClassID;
int entTeam;
int pMask;
int drawOnRadar;
int pShotsFired;
bool trigON = false;
bool bhopON = false;
bool whON = false;
bool nfON = false;
bool rON = false;
bool rcsON = false;
bool entDormant;
bool entSpotted;
bool entDefusing;
bool entReloading;
int connected;
Vector CurrentViewAngles;
Vector vPunch;
Vector NewViewAngles;
Vector OldAimPunch;

void GetCSGO()
{
	Print("Looking for CS:GO...");


	PM.Process("csgo.exe");

	Print("CS:GO found!\n\n\n");
	Print("Getting Modules...");

	cMod = PM.Module("client.dll");
	dMod = PM.Module("engine.dll");

	Print("Modules Found!");
}

void GetConfig()
{
	while (true)
	{
		if (GetAsyncKeyState(VK_F1) & 0x8000)
		{
			std::system("cls");
			std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
			std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
			std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
			std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
			std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
			std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
			std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
			std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
			std::cout << "Type the Virtual Key code (ex. 0x04) you would like to use as your Trigger Bot Key" << std::endl;
			std::cin >> triggerKey;

			std::system("cls");
			std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
			std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
			std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
			std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
			std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
			std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
			std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
			std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
			std::cout << "[INSERT] Triggerbot Status - " << trigON << std::endl;
			std::cout << "[NUMPAD 0] Bunnyhop Status - " << bhopON << std::endl;
			std::cout << "[NUMPAD 1] Wallhack Status - " << whON << std::endl;
			std::cout << "[NUMPAD 2] NoFlash Status - " << nfON << std::endl;
			std::cout << "[NUMPAD 3] Radar Status - " << rON << std::endl;
			std::cout << "[NUMPAD 4] RCS Status - " << rcsON << std::endl;
		}
		while (GetAsyncKeyState(VK_F1) & 0x8000)
		{
			Sleep(100);
		}
	}
}

void Hotkey()
{
	while (true)
	{
		if (GetAsyncKeyState(VK_INSERT) & 0x8000)
		{

			trigON = !trigON;

			std::system("cls");
			std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
			std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
			std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
			std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
			std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
			std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
			std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
			std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
			std::cout << "[INSERT] Triggerbot Status - " << trigON << std::endl;
			std::cout << "[NUMPAD 0] Bunnyhop Status - " << bhopON << std::endl;
			std::cout << "[NUMPAD 1] Wallhack Status - " << whON << std::endl;
			std::cout << "[NUMPAD 2] NoFlash Status - " << nfON << std::endl;
			std::cout << "[NUMPAD 3] Radar Status - " << rON << std::endl;
			std::cout << "[NUMPAD 4] RCS Status - " << rcsON << std::endl;



			while (GetAsyncKeyState(VK_INSERT) & 0x8000)
			{
				Sleep(100);
			}
		}
		if (GetAsyncKeyState(VK_NUMPAD0) & 0x8000)
		{
			bhopON = !bhopON;

			std::system("cls");
			std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
			std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
			std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
			std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
			std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
			std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
			std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
			std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
			std::cout << "[INSERT] Triggerbot Status - " << trigON << std::endl;
			std::cout << "[NUMPAD 0] Bunnyhop Status - " << bhopON << std::endl;
			std::cout << "[NUMPAD 1] Wallhack Status - " << whON << std::endl;
			std::cout << "[NUMPAD 2] NoFlash Status - " << nfON << std::endl;
		    std::cout << "[NUMPAD 3] Radar Status - " << rON << std::endl;
			std::cout << "[NUMPAD 4] RCS Status - " << rcsON << std::endl;


			while (GetAsyncKeyState(VK_NUMPAD0) & 0x8000)
			{
				Sleep(100);
			}
		}
		Sleep(10);

		if (GetAsyncKeyState(VK_NUMPAD1) & 0x8000)
		{
			whON = !whON;

			std::system("cls");
			std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
			std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
			std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
			std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
			std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
			std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
			std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
			std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
			std::cout << "[INSERT] Triggerbot Status - " << trigON << std::endl;
			std::cout << "[NUMPAD 0] Bunnyhop Status - " << bhopON << std::endl;
			std::cout << "[NUMPAD 1] Wallhack Status - " << whON << std::endl;
			std::cout << "[NUMPAD 2] NoFlash Status - " << nfON << std::endl;
			std::cout << "[NUMPAD 3] Radar Status - " << rON << std::endl;
			std::cout << "[NUMPAD 4] RCS Status - " << rcsON << std::endl;


			

			while (GetAsyncKeyState(VK_NUMPAD1) & 0x8000)
			{
				Sleep(100);
			}
		}
		if (GetAsyncKeyState(VK_NUMPAD2) & 0x8000)
		{
			nfON = !nfON;

			std::system("cls");
			std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
			std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
			std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
			std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
			std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
			std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
			std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
			std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
			std::cout << "[INSERT] Triggerbot Status - " << trigON << std::endl;
			std::cout << "[NUMPAD 0] Bunnyhop Status - " << bhopON << std::endl;
			std::cout << "[NUMPAD 1] Wallhack Status - " << whON << std::endl;
			std::cout << "[NUMPAD 2] NoFlash Status - " << nfON << std::endl;
			std::cout << "[NUMPAD 3] Radar Status - " << rON << std::endl;
			std::cout << "[NUMPAD 4] RCS Status - " << rcsON << std::endl;



			while (GetAsyncKeyState(VK_NUMPAD2) & 0x8000)
			{
				Sleep(100);
			}
		}
			if (GetAsyncKeyState(VK_NUMPAD3) & 0x8000)
		{
			rON = !rON;

			std::system("cls");
			std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
			std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
			std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
			std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
			std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
			std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
			std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
			std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
			std::cout << "[INSERT] Triggerbot Status - " << trigON << std::endl;
			std::cout << "[NUMPAD 0] Bunnyhop Status - " << bhopON << std::endl;
			std::cout << "[NUMPAD 1] Wallhack Status - " << whON << std::endl;
			std::cout << "[NUMPAD 2] NoFlash Status - " << nfON << std::endl;
			std::cout << "[NUMPAD 3] Radar Status - " << rON << std::endl;
			std::cout << "[NUMPAD 4] RCS Status - " << rcsON << std::endl;


			while (GetAsyncKeyState(VK_NUMPAD3) & 0x8000)
			{
				Sleep(100);
			}
		}
		if (GetAsyncKeyState(VK_NUMPAD4) & 0x8000)
		{
			rcsON = !rcsON;

			std::system("cls");
			std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
			std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
			std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
			std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
			std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
			std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
			std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
			std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
			std::cout << "[INSERT] Triggerbot Status - " << trigON << std::endl;
			std::cout << "[NUMPAD 0] Bunnyhop Status - " << bhopON << std::endl;
			std::cout << "[NUMPAD 1] Wallhack Status - " << whON << std::endl;
			std::cout << "[NUMPAD 2] NoFlash Status - " << nfON << std::endl;
			std::cout << "[NUMPAD 3] Radar Status - " << rON << std::endl;
			std::cout << "[NUMPAD 4] RCS Status - " << rcsON << std::endl;


			while (GetAsyncKeyState(VK_NUMPAD4) & 0x8000)
			{
				Sleep(100);
			}
		}
		
		
		Sleep(10);
	}
}

void Trig()
{
	while (true)
	{
		if (trigON)
		{
			localPlayer = PM.Read<DWORD>(cMod + playerBase);

			if (GetAsyncKeyState(triggerKey) & 0x8000)
			{
				localTeam = PM.Read<int>(localPlayer + playerTeam);
				crossID = PM.Read<int>(localPlayer + playerCross);

				DWORD enemyInC = PM.Read<DWORD>(cMod + entBase + ((crossID - 1) * playerLoop));
				int enemyTeam = PM.Read<int>(enemyInC + playerTeam);
				int enemyHealth = PM.Read<int>(enemyInC + playerHealth);

				if (localTeam != enemyTeam && crossID > 0 && crossID < 64)
				{
					mouse_event(MOUSEEVENTF_LEFTDOWN, NULL, NULL, NULL, NULL);
					Sleep(20);
					mouse_event(MOUSEEVENTF_LEFTUP, NULL, NULL, NULL, NULL);
					Sleep(20);
				}
			}
		}
		Sleep(10);
	}
}

void bHOP()
{
	while (true)
	{
		if (bhopON)
		{
			localPlayer = PM.Read<DWORD>(cMod + playerBase);

			if (PM.Read<int>(cMod + forceJump) == 5)
			{
				while (GetAsyncKeyState(VK_SPACE) & 0x8000)
				{
					if (PM.Read<int>(localPlayer + playerFlags) & FL_ONGROUND)
					{
						PM.Write<int>(cMod + forceJump, 5);
					}
					else
					{
						PM.Write<int>(cMod + forceJump, 4);
					}
				}
			}
		}
		Sleep(10);
	}
}

void Wallhack()
{
	while (true)
	{
		if (whON)
		{
			localPlayer = PM.Read<DWORD>(cMod + playerBase);
			engineBase = PM.Read<DWORD>(dMod + enginePointer);


			glowBase = PM.Read<DWORD>(cMod + glowPointer);
			entityCount = PM.Read<int>(cMod + glowPointer + 0x4);

			for (int i = 0; i < entityCount; i++)
			{
				Glow = PM.Read<GlowObject>(glowBase + (i * sizeof(GlowObject)));


				if (glowBase != NULL && Glow.Entity != NULL)
				{
					entDormant = PM.Read<bool>(Glow.Entity + 0xE9);
					entClassID = PM.Read<int>(PM.Read<int>(PM.Read<int>(PM.Read<int>(Glow.Entity + 0x8) + 2 * 0x4) + 0x1) + 20);
					entTeam = PM.Read<int>(Glow.Entity + playerTeam);
					localTeam = PM.Read<int>(localPlayer + playerTeam);

					if (entClassID == 35)
					{
						if (!entDormant)
						{
							Glow.renderOccluded = true;
							Glow.renderNotOccluded = false;
							Glow.colorFill = false;
							
							entSpotted = PM.Read<bool>(Glow.Entity + playerSpotted);
							entDefusing = PM.Read<bool>(Glow.Entity + playerDefusing);
							entReloading = PM.Read<bool>(Glow.Entity + playerReloading);

							if (entTeam != localTeam)
							{
								Glow.red = 1.0f;
								Glow.blue = 0.0f;
								Glow.green = 0.0f;
								Glow.alpha = 1.0f;

								PM.Write<GlowObject>(glowBase + (i * sizeof(GlowObject)), Glow);

								if (entSpotted == true) 
								{
									Glow.red = 1.0f;
									Glow.blue = 0.0f;
									Glow.green = 1.0f;
									Glow.alpha = 1.0f;

									PM.Write<GlowObject>(glowBase + (i * sizeof(GlowObject)), Glow);
								}

								if (entDefusing == true)
								{
									Glow.red = 0.0f;
									Glow.blue = 1.0f;
									Glow.green = 0.0f;
									Glow.alpha = 1.0f;

									PM.Write<GlowObject>(glowBase + (i * sizeof(GlowObject)), Glow);
								}
								
								if (entReloading == true)
								{
									Glow.red = 1.0f;
									Glow.blue = 0.0f;
									Glow.green = 1.0f;
									Glow.alpha = 1.0f;

									PM.Write<GlowObject>(glowBase + (i * sizeof(GlowObject)), Glow);
								}
							}

							else
							{
								Glow.red = 0.0f;
								Glow.blue = 0.0f;
								Glow.green = 1.0f;
								Glow.alpha = 1.0f;

								PM.Write<GlowObject>(glowBase + (i * sizeof(GlowObject)), Glow);
							}
						}
					}
				}
			}

		}
		Sleep(10);
	}
}

void NoFlash()
{
	while (true)
	{
		if (nfON)
		{
			localPlayer = PM.Read<DWORD>(cMod + playerBase);

			if (PM.Read<float>(localPlayer + FlashMaxAlpha) > 0.0f)
			{
				PM.Write<float>(localPlayer + FlashMaxAlpha, 0.0f);
				Sleep(1);
			}
			Sleep(10);
		}
		Sleep(10);
	}
}

void Radar()
{
	while (true)
	{
		if (rON)
		{
			entityCount = PM.Read<int>(cMod + 0x04);

			for (int i = 0; i <= entityCount; i++)
			{
				engineBase = PM.Read<DWORD>(dMod + enginePointer);
				enemyBase = PM.Read<DWORD>(cMod + entBase + (i * 16));

					if (!enemyBase)
					{
						continue;
					}

					bool entSpotted = PM.Read<bool>(enemyBase + playerSpotted);

					if (!entSpotted)
					{
						PM.Write<bool>(enemyBase + playerSpotted, true);
						Sleep(10);
					}
				Sleep(10);
			}
		}
		Sleep(10);
	}
}

void RCS()
{
	while (true)
	{
		if (rcsON)
		{
			localPlayer = PM.Read<DWORD>(cMod + playerBase);
			pShotsFired = PM.Read<int>(localPlayer + shotsFired);

			if (pShotsFired > 1)
			{
				engineBase = PM.Read<DWORD>(dMod + enginePointer);

				vPunch = PM.Read<Vector>(localPlayer + AimPunch);
				vPunch.x = vPunch.x * 2.f;
				vPunch.y = vPunch.y * 2.f;
				
				CurrentViewAngles = PM.Read<Vector>(engineBase + setView);

				NewViewAngles.x = CurrentViewAngles.x + (OldAimPunch.x - vPunch.x);
				NewViewAngles.y = CurrentViewAngles.y + (OldAimPunch.y - vPunch.y);
				NewViewAngles.z = 0;

				while (NewViewAngles.y > 180)
					NewViewAngles.y -= 360;

				while (NewViewAngles.y < -180)
					NewViewAngles.y += 360;

				if (NewViewAngles.x > 89.0f)
					NewViewAngles.x = 89.0f;

				if (NewViewAngles.x < -89.0f)
					NewViewAngles.x = -89.0f;

				NewViewAngles.z = 0;

				PM.Write<Vector>(engineBase + setView, NewViewAngles);

				OldAimPunch.x = vPunch.x;
				OldAimPunch.y = vPunch.y;
				OldAimPunch.z = 0;

				Sleep(10);
			}
			else
			{
				OldAimPunch.x = 0;
				OldAimPunch.y = 0;
				OldAimPunch.z = 0;
			}
			Sleep(10);
		}
		Sleep(10);
	}


}

void main()
{
	SetConsoleTitle("Slayer1250's Private Hack");

	std::thread trigThread = std::thread(Trig);
	std::thread hotThread = std::thread(Hotkey);
	std::thread bhopThread = std::thread(bHOP);
	std::thread whThread = std::thread(Wallhack);
	std::thread nfThread = std::thread(NoFlash);
	std::thread rThread = std::thread(Radar);
	std::thread rcsThread = std::thread(RCS);
	std::thread gcThread = std::thread(GetConfig);


	OldAimPunch.x = OldAimPunch.y = OldAimPunch.z = 0;


	std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
	std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
	std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
	std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
	std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
	std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
	std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;

	Print("Welcome to Slayer1250's Private Hack! \n\n");
	Print("Credits go to Motherflufferr, Hf.ub3r, Slayer1250, and the UC community!");

	GetCSGO();

	Sleep(2000);

	std::system("cls");

	std::cout << "  #####                                      #    #####  #######   ###   ###           #     #                      " << std::endl;
	std::cout << " #     # #        ##   #   # ###### #####   ##   #     # #        #   #  ###  ####     #     #   ##    ####  #    # " << std::endl;
	std::cout << " #       #       #  #   # #  #      #    # # #         # #       #     #  #  #         #     #  #  #  #    # #   #" << std::endl;
	std::cout << "  #####  #      #    #   #   #####  #    #   #    #####  ######  #     # #    ####     ####### #    # #      ####   " << std::endl;
	std::cout << "       # #      ######   #   #      #####    #   #             # #     #          #    #     # ###### #      #  #   " << std::endl;
	std::cout << " #     # #      #    #   #   #      #   #    #   #       #     #  #   #      #    #    #     # #    # #    # #   #  " << std::endl;
	std::cout << "  #####  ###### #    #   #   ###### #    # ##### #######  #####    ###        ####     #     # #    #  ####  #    # " << std::endl;
	std::cout << "****Press F1 to change Triggerbot key. Current key = " << triggerKey << " ****" << std::endl;
	std::cout << "[INSERT] Triggerbot Status - " << trigON << std::endl;
	std::cout << "[NUMPAD 0] Bunnyhop Status - " << bhopON << std::endl;
	std::cout << "[NUMPAD 1] Wallhack Status - " << whON << std::endl;
	std::cout << "[NUMPAD 2] NoFlash Status - " << nfON << std::endl;
	std::cout << "[NUMPAD 3] Radar Status - " << rON << std::endl;
	std::cout << "[NUMPAD 4] RCS Status - " << rcsON << std::endl;


	trigThread.join();
	hotThread.join();
	bhopThread.join();
	whThread.join();
	nfThread.join();
	rThread.join();
	rcsThread.join();
	gcThread.join();
}


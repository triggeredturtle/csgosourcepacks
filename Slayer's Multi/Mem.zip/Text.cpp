#include "Text.h"

//Text
void SetColor(int color)
{
	if (color == 7)
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
	else
		SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color | FOREGROUND_INTENSITY);
}



void Print(std::string text, int newLines, int color, int speed)
{
	SetColor(color);

	for (int i = 0; i < text.length(); i++)
	{
		std::cout << text[i];
		Sleep(speed);
	}

	for (int i = 0; i < newLines; i++)
		std::cout << std::endl;

	SetColor();
}


#pragma once
#include <Windows.h>
#include <iostream>
#include <TlHelp32.h>

using namespace std;


struct Module
{
	DWORD dwBase;
	DWORD dwSize;
};



class Memory
{
private:
	HANDLE hProc;
	DWORD dwPID;

	bool procOk;
	bool CompareData(const BYTE*, const BYTE*, const char*);

public:
	Memory();
	~Memory();

	bool LoadProcess(char*);
	Module LoadModule(char*);

	DWORD FindPattern(DWORD, DWORD, const char*, const char*);
	DWORD FindArray(DWORD, DWORD, const char*, int, ...);

	template <class Mem>
	Mem Read(DWORD dwAddress)
	{
		Mem val;
		ReadProcessMemory(hProc, (LPVOID)dwAddress, &val, sizeof(Mem), NULL);
		return val;
	}

	template <class Mem>
	void Write(DWORD dwAddress, Mem value)
	{
		WriteProcessMemory(hProc, (LPVOID)dwAddress, &value, sizeof(Mem), NULL);
	}
};
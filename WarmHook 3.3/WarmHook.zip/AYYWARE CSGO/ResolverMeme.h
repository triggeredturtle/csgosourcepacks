#pragma once
namespace R
{
	void Resolver();
}
/* Paper-Panel */
#include "Paper.hpp"

IPanel* g_pPanel;

/* GetName */
const char* IPanel::GetName(int Panel) {
	typedef const char*(__thiscall* OriginalFn)(void*, int);
	return GetVFunc<OriginalFn>(this, 36)(this, Panel);
}

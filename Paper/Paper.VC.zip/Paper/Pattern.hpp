/* Paper-Pattern */
#pragma once

/* Pattern Namespace */
namespace Pattern {
	DWORD FindPattern(std::string moduleName, std::string pattern);
}
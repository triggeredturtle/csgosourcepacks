/* Paper-Globals */
#include "Paper.hpp"

CGlobalVarsBase* g_pGlobalVars;
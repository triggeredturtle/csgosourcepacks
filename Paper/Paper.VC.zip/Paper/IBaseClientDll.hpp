/* Paper-Base-Client */
#pragma once

/* IBaseClientDll */
class IBaseClientDll {
public:
}; extern IBaseClientDll* g_pClient;

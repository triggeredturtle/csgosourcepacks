/* Paper-IPlayerInfo */
#pragma once

/* Includes */
#include "Globals.hpp"

/* IPlayerInfoManager */
class IPlayerInfoManager {
public:
	CGlobalVarsBase* GetGlobalVars();
}; extern IPlayerInfoManager* g_pPlayerInfo;

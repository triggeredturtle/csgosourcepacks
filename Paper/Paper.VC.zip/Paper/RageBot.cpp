/* Paper-Legit */
#include "Paper.hpp"

CRageBot* g_pRageBot;

#pragma region AntiAim

/* Pitch */
/* ----- */

/* Down */
void AntiAim::Down() {
	G::Cmd->viewangles.x = 89.f;
}

/* Up */
void AntiAim::Up() {
	G::Cmd->viewangles.x = -89.f;
}

/* Emotion */
void AntiAim::Emotion() {
	G::Cmd->viewangles.x = 70.f;
}

/* Fake Emotion */
void AntiAim::FakeEmotion() {
	G::Cmd->viewangles.x = -89.f;
	if (G::SendPacket)
		G::Cmd->viewangles.x = 89.f;
}

/* FakeDown */
void AntiAim::FakeDown() {
	G::Cmd->viewangles.x = -271.f;
}

/* FakeUp */
void AntiAim::FakeUp() {
	G::Cmd->viewangles.x = 271.f;
}

/* LispDown */
void AntiAim::LispDown() {
	G::Cmd->viewangles.x = 1800089;
}

/* LispUp */
void AntiAim::LispUp() {
	G::Cmd->viewangles.x = -1800089;
}

/* UpsideDown */
void AntiAim::UpsideDown() {
	G::Cmd->viewangles.z = -200.f;
}

/* Yaw */
/* ----- */

/* FakeOrigin */
void AntiAim::FakeOrigin() {
	static int m_iChokedPackets = -1;
	m_iChokedPackets++;

	if (m_iChokedPackets < 8) {
		G::SendPacket = false;
		G::Cmd->viewangles.y -= 92;
	}
	else {
		G::SendPacket = true;
		m_iChokedPackets = -1;
	}
}

/* Backwards */
void AntiAim::Backwards() {
	static bool m_bFlip;
	if (m_bFlip) {
		G::Cmd->viewangles.y -= 180;
		m_bFlip = !m_bFlip;
	}
	else {
		G::Cmd->viewangles.y += 180;
		m_bFlip = !m_bFlip;
	}
}

/* Jitter */
void AntiAim::Jitter() {
	static int Jitter = 0;

	if (Jitter <= 1) {

		G::Cmd->viewangles.y += 91;
		Jitter += 1;
	}
	else if (Jitter > 1 && Jitter <= 3) {

		G::Cmd->viewangles.y -= 89;
		Jitter += 1;
	}
	else {
		Jitter = 0;
	}
}

/* SidewaysJitter */
void AntiAim::SidewaysJitter() {
	static int Jitter = 0;
	int temp = 90;
	if (Jitter == 1)
		temp = -90;
	if (G::SendPacket) {
		if (Jitter >= 1)
			Jitter = -1;
		Jitter++;
	}
	G::Cmd->viewangles.y += temp;
}

/* FastSpin */
void AntiAim::FastSpin() {
	const float rate = 360.0f / 1.118033988749895f;
	const int intRate = rate * 10;
	static int state = 0;

	G::Cmd->viewangles.y += rate * (state % intRate);

	if (state > intRate + 1)
		state = 0;

	state++;
}

/* SlowSpin */
void AntiAim::SlowSpin() {
	const float rate = 360.0f / 1.118033988749895f;
	const int intRate = rate * 6000;
	static int state = 0;

	G::Cmd->viewangles.y += rate * (state % intRate);

	if (state > intRate + 1)
		state = 0;

	state++;
}

/* FakeSideways */
void AntiAim::FakeSideways() {
	int temp;
	if (G::SendPacket)
		temp = 90;
	else
		temp = -150;
	G::Cmd->viewangles.y += temp;
}

/* Movement */
/* ----- */

/* CorrectLisp */
void AntiAim::CorrectLisp() {
	if (G::Cmd->buttons & IN_FORWARD)
		G::Cmd->forwardmove = 450.f;
	if (G::Cmd->buttons & IN_BACK)
		G::Cmd->forwardmove = -450.f;
}

#pragma endregion

#pragma region RageBot

/* Vis Check */
bool CRageBot::IsVisible(Vector& vAbsStart, Vector& vAbsEnd, CBaseEntity* Entity) {
	trace_t tr;
	Ray_t ray;
	CTraceFilter filter;

	filter.pSkip = G::Local;

	ray.Init(vAbsStart, vAbsEnd);

	g_pEngineTrace->TraceRay(ray, 0x46004003, &filter, &tr);

	return (tr.m_pEnt == Entity || tr.fraction > 0.99f);
}

/* BestPoint */
void CRageBot::BestPoint(CBaseEntity* Target, Vector& final) {
	trace_t tr;
	Ray_t ray;
	CTraceEntity filter;

	filter.pHit = Target;
	ray.Init(final + Vector(0, 0, 10), final);
	g_pEngineTrace->TraceRay(ray, 0x46004003, &filter, &tr);

	final = tr.endpos;
}

/* FixMovement */
void CRageBot::FixMove(Vector m_vOldAngles, float m_fOldForward, float m_fOldSidemove) {
	float deltaView = G::Cmd->viewangles.y - m_vOldAngles.y;
	float f1;
	float f2;

	if (m_vOldAngles.y < 0.f)
		f1 = 360.0f + m_vOldAngles.y;
	else
		f1 = m_vOldAngles.y;

	if (G::Cmd->viewangles.y < 0.0f)
		f2 = 360.0f + G::Cmd->viewangles.y;
	else
		f2 = G::Cmd->viewangles.y;

	if (f2 < f1)
		deltaView = abs(f2 - f1);
	else
		deltaView = 360.0f - abs(f1 - f2);
	deltaView = 360.0f - deltaView;

	G::Cmd->forwardmove = cos(g_pMath->Deg2Rad(deltaView)) * m_fOldForward + cos(g_pMath->Deg2Rad(deltaView + 90.f)) * m_fOldSidemove;
	G::Cmd->sidemove = sin(g_pMath->Deg2Rad(deltaView)) * m_fOldForward + sin(g_pMath->Deg2Rad(deltaView + 90.f)) * m_fOldSidemove;
}

/* AntiAim */
void CRageBot::AntiAim() {

	/* Movement */
	Vector m_vOldViewAngle = G::Cmd->viewangles;
	float m_fOldSideMove = G::Cmd->sidemove;
	float m_fOldForwardMove = G::Cmd->forwardmove;

	if (G::Cmd->buttons & IN_ATTACK || G::Local->GetMoveType() == MOVETYPE_LADDER || G::Local->GetMoveType() == MOVETYPE_NOCLIP) return;

	// >> Pitch
	if (Settings::m_iAntiAimX == 1) {
		AntiAim::Down();
	}
	if (Settings::m_iAntiAimX == 2) {
		AntiAim::Emotion();
	}
	if (Settings::m_iAntiAimX == 3) {
		AntiAim::FakeEmotion();
	}
	if (Settings::m_iAntiAimX == 4) {
		AntiAim::FakeDown();
	}
	if (Settings::m_iAntiAimX == 5) {
		AntiAim::FakeUp();
	}
	if (Settings::m_iAntiAimX == 6) {
		AntiAim::Up();
	}
	if (Settings::m_iAntiAimX == 7) {
		AntiAim::LispDown();
	}
	if (Settings::m_iAntiAimX == 8) {
		AntiAim::LispUp();
	}

	if (Settings::m_iAntiAimY == 1) {
		AntiAim::Backwards();
	}
	if (Settings::m_iAntiAimY == 2) {
		AntiAim::Jitter();
	}
	if (Settings::m_iAntiAimY == 3) {
		AntiAim::FakeOrigin();
	}
	if (Settings::m_iAntiAimY == 4) {
		AntiAim::SidewaysJitter();
	}
	if (Settings::m_iAntiAimY == 5) {
		AntiAim::FastSpin();
	}
	if (Settings::m_iAntiAimY == 6) {
		AntiAim::SlowSpin();
	}
	if (Settings::m_iAntiAimY == 7) {
		AntiAim::FakeSideways();
	}

	FixMove(m_vOldViewAngle, m_fOldForwardMove, m_fOldSideMove);

}

/* Ragebot */
void CRageBot::RageBot() {

	/* Declarations */
	float m_flFOV = Settings::m_flRageBotFOV; //  FOV
	int m_iBestIndex = -1; // BestIndex
	Vector m_vEnd; // End position

    /* Movement */
	Vector m_vOldViewAngle = G::Cmd->viewangles;
	float m_fOldSideMove = G::Cmd->sidemove;
	float m_fOldForwardMove = G::Cmd->forwardmove;

	if (!Settings::m_bRageBot || G::Local->GetMoveType() == MOVETYPE_OBSERVER) return;

	// Targetting
	for (auto i = 1; i <= g_pIEntList->GetHighestEntityIndex(); i++) {

		CBaseEntity* Entity = (CBaseEntity*)g_pIEntList->GetClientEntity(i); // Get our entity

		if (!Entity || Entity->GetTeam() == G::Local->GetTeam() || Entity->GetDormant() || Entity->GetHealth() <= 0) continue;

		if (Settings::m_bRageBotBodyAim) {
			m_vEnd = Entity->GetBonePosition(3);
		}
		else {
			m_vEnd = Entity->GetBonePosition(8);
		}

		float flFOV = g_pMath->GetFOV(G::Cmd->viewangles, G::Local->GetEyePosition(), m_vEnd); // Calculate the fov of our eye position and the enemies head bone

		if (flFOV < m_flFOV) { // FOV Check
			m_flFOV = flFOV;
			m_iBestIndex = i;
		}

		// Aimbot Code
		if (m_iBestIndex != -1) {

			Vector vDirection = m_vEnd - G::Local->GetEyePosition();

			g_pMath->VectorNormalize(vDirection);

			Vector vAim;

			g_pMath->VectorAngles(vDirection, vAim); // Calculate the angle, start position | end position

			vAim.z = 0.0f;

			if (Settings::m_bRageBotRCS) {
				if (G::Local->GetPunch().Length2d() > 0 && G::Local->GetPunch().Length2d() < 150)
					vAim -= G::Local->GetPunch() * 2.f;
			}

			if (Settings::m_bRageBotPrediction) {
				VelocityPrediction(i);
			}

			if (IsVisible(G::Local->GetEyePosition(), m_vEnd, Entity)) {
				
				if (Settings::m_bRageBotSilent) {
					G::Cmd->viewangles = vAim;
				}
				else {
					g_pEngineClient->SetViewAngles(vAim);
				}

				if (Settings::m_bRageBotAutoShoot) {
					G::Cmd->buttons |= IN_ATTACK;
				}

				if (Settings::m_bRageBotAutoDuck) {
					G::Cmd->buttons |= IN_DUCK;
				}

			}

			FixMove(m_vOldViewAngle, m_fOldForwardMove, m_fOldSideMove);
			g_pMath->ClampAngles(vAim);
			g_pMath->NormalizeAngles(vAim);

		}

	}

}

/* VelocityPrediction */
void CRageBot::VelocityPrediction(int i) {
	auto Entity = (CBaseEntity*)g_pIEntList->GetClientEntity(i);
	Vector Position = ((Entity->GetVelocity() * g_pGlobalVars->interval_per_tick * g_pGlobalVars->frametime) - (G::Local->GetVelocity() * g_pGlobalVars->interval_per_tick * g_pGlobalVars->frametime));
}

#pragma endregion
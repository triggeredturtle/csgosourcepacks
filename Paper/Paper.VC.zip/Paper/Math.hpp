/* Paper-Math */
#pragma once

/* CMath */
class CMath {
public:
	float Deg2Rad(float fl);
	float Rad2Deg(float fl);
	void MakeVector(const Vector& vIn, Vector& vOut);
	void VectorAngles(const Vector& vForward, Vector& vAngles);
	float GetFOV(const Vector& ViewAngles, const Vector& vStart, const Vector& vEnd);
	void SinCos(float x, float& s, float& c);
	Vector ClampAngles(Vector vAngle);
	void NormalizeAngles(Vector& vAngle);
	float VectorNormalize(Vector& v);
	float AngleDifference(Vector vAngle, Vector vTargetAngles, float flDistance);
	void AngleVectors(const Vector& angles, Vector* forward);
}; extern CMath* g_pMath;

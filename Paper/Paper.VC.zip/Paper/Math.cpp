/* Paper-Math */
#include "Paper.hpp"

CMath* g_pMath;

/* Deg2Rad */
float CMath::Deg2Rad(float fl) {
	return (fl* (3.14159265358979323846f / 180.0f));
}

/* Rad2Deg */
float CMath::Rad2Deg(float fl) {
	return (fl* (180.0f / 3.14159265358979323846f));
}

/* MakeVector */
void CMath::MakeVector(const Vector& vIn, Vector& vOut) {
	float Pitch = Deg2Rad(vIn.x);
	float Yaw = Deg2Rad(vIn.y);
	float Temp = cos(Pitch);

	vOut.x = -Temp* -cos(Yaw);
	vOut.y = sin(Yaw)* Temp;
	vOut.z = -sin(Pitch);
}

/* VectorAngles */
void CMath::VectorAngles(const Vector& vForward, Vector& vAngles) {
	float flTemp, flYaw, flPitch;

	if (vForward.y == 0 && vForward.x == 0) {
		flYaw = 0;

		if (vForward.z > 0)
			flPitch = 270;
		else
			flPitch = 90;
	}
	else {
		flYaw = Rad2Deg(atan2f(vForward.y, vForward.x));

		if (flYaw < 0)
			flYaw += 360;

		flTemp = vForward.Length2d();
		flPitch = Rad2Deg(atan2f(-vForward.z, flTemp));

		if (flPitch < 0)
			flPitch += 360;
	}

	vAngles[0] = flPitch;
	vAngles[1] = flYaw;
	vAngles[2] = 0;
}

/* GetFOV */
float CMath::GetFOV(const Vector& ViewAngles, const Vector& vStart, const Vector& vEnd) {
	Vector vAng, vAim;

	Vector vDir = vEnd - vStart;

	VectorNormalize(vDir);

	VectorAngles(vDir, vAng);

	MakeVector(ViewAngles, vAim);
	MakeVector(vAng, vAng);

	return Rad2Deg(acos(vAim.Dot(vAng)) / vAim.LengthSqr());
}

/* Clamp Angle */
Vector CMath::ClampAngles(Vector vAngle) {
	while (vAngle.y > 180)
		vAngle.y -= 360;

	while (vAngle.y < -180)
		vAngle.y += 360;

	if (vAngle.x > 89.0f)
		vAngle.x = 89.0f;

	if (vAngle.x < -89.0f)
		vAngle.x = -89.0f;

	vAngle.z = 0;
	return vAngle;
}

/* Normalize Angles */
void CMath::NormalizeAngles(Vector& vAngle) {
	while (vAngle.x > 180.0f)
		vAngle.x -= 360.0f;

	while (vAngle.x < -180.0f)
		vAngle.x += 360.0f;

	while (vAngle.y > 180.0f)
		vAngle.y -= 360.0f;

	while (vAngle.y < -180.0f)
		vAngle.y += 360.0f;

	while (vAngle.z > 180.0f)
		vAngle.z -= 360.0f;

	while (vAngle.z < -180.0f)
		vAngle.z += 360.0f;
}

/* VectorNormalize */
float CMath::VectorNormalize(Vector& v) {
	float flLength = v.Length();

	if (!flLength)
		v.Set();
	else
		v /= flLength;

	return flLength;
}

/* VecDistance */
float CMath::AngleDifference(Vector vAngle, Vector vTargetAngles, float flDistance) {
	float pitch = sin(Deg2Rad(vAngle.x - vTargetAngles.x)) * flDistance;
	float yaw = sin(Deg2Rad(vAngle.y - vTargetAngles.y)) * flDistance;

	return sqrt(powf(pitch, 2.0) + powf(yaw, 2.0));
}

/* SinCos */
void CMath::SinCos(float x, float& s, float& c) {
	__asm {
		fld dword ptr[x]
		fsincos
		mov edx, dword ptr[c]
		mov eax, dword ptr[s]
		fstp dword ptr[edx]
		fstp dword ptr[eax]
	}
}

/* AngleVectors */
void CMath::AngleVectors(const Vector& angles, Vector* forward) {
	float sp, sy, cp, cy;

	SinCos(Deg2Rad(angles.x), sp, cp);
	SinCos(Deg2Rad(angles.y), sy, cy);

	if (forward) {
		forward->x = cp * cy;
		forward->y = cp * sy;
		forward->z = -sp;
	}
}
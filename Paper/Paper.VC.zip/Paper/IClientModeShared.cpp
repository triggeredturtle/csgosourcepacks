/* Paper-Client-Mode */
#include "Paper.hpp"

IClientModeShared** g_pClientMode;
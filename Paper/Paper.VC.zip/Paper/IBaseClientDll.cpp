/* Paper-Base-Client */
#include "Paper.hpp"

IBaseClientDll* g_pClient;
/* Paper-Engine-Client */
#include "Paper.hpp"

IVEngineClient* g_pEngineClient;

/* GetLocalPlayer */
int IVEngineClient::GetLocalPlayer() {
	typedef int(__thiscall* OriginalFn)(void*);
	return GetVFunc<OriginalFn>(this, 12)(this);
}

/* IsInGame */
bool IVEngineClient::IsInGame() {
	typedef bool(__thiscall* OriginalFn)(void*);
	return GetVFunc<OriginalFn>(this, 26)(this);
}

/* IsConnected */
bool IVEngineClient::IsConnected() {
	typedef bool(__thiscall* OriginalFn)(void*);
	return GetVFunc<OriginalFn>(this, 27)(this);
}

/* SetViewAngles */
void IVEngineClient::SetViewAngles(Vector& Ang) {
	typedef void(__thiscall* OriginalFn)(void*, Vector&);
	return GetVFunc<OriginalFn>(this, 19)(this, Ang);
}

/* GetViewAngles */
void IVEngineClient::GetViewAngles(Vector& vAngles) {
	typedef void(__thiscall* OriginalFn)(void*, Vector&);
	return GetVFunc<OriginalFn>(this, 18)(this, vAngles);
}

/* IVEngineClient */
void IVEngineClient::GetScreenSize(int& Width, int& Height) {
	typedef void(__thiscall* OriginalFn)(void*, int&, int&);
	return GetVFunc<OriginalFn>(this, 5)(this, Width, Height);
}

/* WorldToScreenMatix */
const VMatrix& IVEngineClient::WorldToScreenMatrix() {
	typedef VMatrix&(__thiscall* OriginalFn)(void*);
	return GetVFunc<OriginalFn>(this, 37)(this);
}

/* ClientCmd */
void IVEngineClient::ClientCmd_Unrestricted(char const* chCmd) {
	typedef void(__thiscall* OriginalFn)(void*, const char*);
	return GetVFunc<OriginalFn>(this, 114)(this, chCmd);
}
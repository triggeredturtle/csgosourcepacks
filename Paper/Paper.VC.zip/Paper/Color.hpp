/* Paper-Color */
#pragma once

/* Color */
class Color {
public:

	unsigned char rgba[4];

	Color() {
		*((int *)this) = 0;
	}

	Color(int color32) {
		*((int *)this) = color32;
	}

	Color(int _r, int _g, int _b) {
		SetColor(_r, _g, _b, 255);
	}

	Color(int _r, int _g, int _b, int _a) {
		SetColor(_r, _g, _b, _a);
	}

	void SetColor(int _r, int _g, int _b, int _a = 255) {
		rgba[0] = (unsigned char)_r;
		rgba[1] = (unsigned char)_g;
		rgba[2] = (unsigned char)_b;
		rgba[3] = (unsigned char)_a;
	}

	inline int r() const { return rgba[0]; }
	inline int g() const { return rgba[1]; }
	inline int b() const { return rgba[2]; }
	inline int a() const { return rgba[3]; }

	inline float rBase() const { return rgba[0] / 255.0f; }
	inline float gBase() const { return rgba[1] / 255.0f; }
	inline float bBase() const { return rgba[2] / 255.0f; }
	inline float aBase() const { return rgba[3] / 255.0f; }

	static Color FromHSB(float hue, float saturation, float brightness) {
		float h = hue == 1.0f ? 0 : hue * 6.0f;
		float f = h - (int)h;
		float p = brightness * (1.0f - saturation);
		float q = brightness * (1.0f - saturation * f);
		float t = brightness * (1.0f - (saturation * (1.0f - f)));

		if (h < 1) {
			return Color(
				(unsigned char)(brightness * 255),
				(unsigned char)(t * 255),
				(unsigned char)(p * 255)
			);
		}
		else if (h < 2) {
			return Color(
				(unsigned char)(q * 255),
				(unsigned char)(brightness * 255),
				(unsigned char)(p * 255)
			);
		}
		else if (h < 3) {
			return Color(
				(unsigned char)(p * 255),
				(unsigned char)(brightness * 255),
				(unsigned char)(t * 255)
			);
		}
		else if (h < 4) {
			return Color(
				(unsigned char)(p * 255),
				(unsigned char)(q * 255),
				(unsigned char)(brightness * 255)
			);
		}
		else if (h < 5) {
			return Color(
				(unsigned char)(t * 255),
				(unsigned char)(p * 255),
				(unsigned char)(brightness * 255)
			);
		}
		else {
			return Color(
				(unsigned char)(brightness * 255),
				(unsigned char)(p * 255),
				(unsigned char)(q * 255)
			);
		}
	}

};

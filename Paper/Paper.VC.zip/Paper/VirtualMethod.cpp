/* Paper-Virtual-Method */
#include "Paper.hpp"

CVMT* g_pVGuiHook;
CVMT* g_pClientModeHook;
CVMT* g_pPanelHook;

#pragma region VMT

/* GetVMTCount */
DWORD CVMT::dwGetVMTCount(PDWORD pdwVMT) {
	DWORD dwIndex = 0;

	for (dwIndex = 0; pdwVMT[dwIndex]; dwIndex++) {
		if (IsBadCodePtr((FARPROC)pdwVMT[dwIndex])) {
			break;
		}
	}
	return dwIndex;
}

/* Initialize */
bool CVMT::Initialize(PDWORD* dwClassBase) {
	dwClassBase = dwClassBase;
	m_ppdwOldVmt = *dwClassBase;
	m_dwVMTSize = dwGetVMTCount(*dwClassBase);
	m_ppdwNewVmt = new DWORD[m_dwVMTSize];
	memcpy(m_ppdwNewVmt, m_ppdwOldVmt, sizeof(DWORD)* m_dwVMTSize);
	*dwClassBase = m_ppdwNewVmt;

	return true;
}

/* Initialize */
bool CVMT::Initialize(PDWORD** pClassBase) {
	return Initialize(*pClassBase);
}

/* HookMethod */
DWORD CVMT::dwHookMethod(DWORD dwNewFunc, unsigned int iIndex) {
	if (m_ppdwNewVmt && m_ppdwOldVmt && iIndex <= m_dwVMTSize && iIndex >= 0) {
		m_ppdwNewVmt[iIndex] = dwNewFunc;

		return m_ppdwOldVmt[iIndex];
	}
	return NULL;
}

#pragma endregion 
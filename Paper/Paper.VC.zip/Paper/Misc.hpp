/* Paper-Misc */
#pragma once

/* CMisc */
class CMisc {
public:
	void AutoHop();
	void AutoStrafe();
	void AirStuck();
	void Tag();
}; extern CMisc* g_pMisc;

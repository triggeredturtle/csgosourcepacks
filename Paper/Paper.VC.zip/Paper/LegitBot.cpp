/* Paper-Legit */
#include "Paper.hpp"

CLegitBot* g_pLegitBot;

#pragma region LegitBot

/* Vis Check */
bool CLegitBot::IsVisible(Vector& vAbsStart, Vector& vAbsEnd, CBaseEntity* Entity) {
	trace_t tr;
	Ray_t ray;
	CTraceFilter filter;

	filter.pSkip = G::Local;

	ray.Init(vAbsStart, vAbsEnd);

	g_pEngineTrace->TraceRay(ray, 0x46004003, &filter, &tr);

	return (tr.m_pEnt == Entity || tr.fraction > 0.99f);
}

/* FixMovement */
void CLegitBot::FixMove(Vector m_vOldAngles, float m_fOldForward, float m_fOldSidemove) {
	float deltaView = G::Cmd->viewangles.y - m_vOldAngles.y;
	float f1;
	float f2;

	if (m_vOldAngles.y < 0.f)
		f1 = 360.0f + m_vOldAngles.y;
	else
		f1 = m_vOldAngles.y;

	if (G::Cmd->viewangles.y < 0.0f)
		f2 = 360.0f + G::Cmd->viewangles.y;
	else
		f2 = G::Cmd->viewangles.y;

	if (f2 < f1)
		deltaView = abs(f2 - f1);
	else
		deltaView = 360.0f - abs(f1 - f2);
	deltaView = 360.0f - deltaView;

	G::Cmd->forwardmove = cos(g_pMath->Deg2Rad(deltaView)) * m_fOldForward + cos(g_pMath->Deg2Rad(deltaView + 90.f)) * m_fOldSidemove;
	G::Cmd->sidemove = sin(g_pMath->Deg2Rad(deltaView)) * m_fOldForward + sin(g_pMath->Deg2Rad(deltaView + 90.f)) * m_fOldSidemove;
}

/* Aimbot */
void CLegitBot::LegitBot(bool& bSendPacket) {

	/* Declarations */
	float m_flFOV = Settings::m_flLegitBotFOV; //  FOV
	int m_iBestIndex = -1; // BestIndex
	Vector m_vEnd; // End position

	/* Movement */
	Vector m_vOldViewAngle = G::Cmd->viewangles;
	float m_fOldSideMove = G::Cmd->sidemove;
	float m_fOldForwardMove = G::Cmd->forwardmove;

	if (!Settings::m_bLegitBot || G::Local->GetMoveType() == MOVETYPE_OBSERVER) return;

	// Targetting
	for (auto i = 1; i <= g_pIEntList->GetHighestEntityIndex(); i++) {

		CBaseEntity* Entity = (CBaseEntity*)g_pIEntList->GetClientEntity(i); // Get our entity

		if (!Entity || Entity->GetTeam() == G::Local->GetTeam() || Entity->GetDormant() || Entity->GetHealth() <= 0) continue;

		if (Settings::m_bLegitBotBodyAim) {
			m_vEnd = Entity->GetBonePosition(3);
		}
		else {
			m_vEnd = Entity->GetBonePosition(8);
		}

		float flFOV = g_pMath->GetFOV(G::Cmd->viewangles, G::Local->GetEyePosition(), m_vEnd); // Calculate the fov of our eye position and the enemies head bone

		if (flFOV < m_flFOV) { // FOV Check
			m_flFOV = flFOV;
			m_iBestIndex = i;
		}

		// Aimbot Code
		if (m_iBestIndex != -1) {

			Vector vDirection = m_vEnd - G::Local->GetEyePosition();

			g_pMath->VectorNormalize(vDirection);

			Vector vAim;

			g_pMath->VectorAngles(vDirection, vAim); // Calculate the angle, start position | end position

			vAim.z = 0.0f;

			if (Settings::m_bLegitBotPrediction) {
				VelocityPrediction(i);
			}

			static int iChokedPackets = 0;
			iChokedPackets++;

			if (iChokedPackets < 14) {

				if (IsVisible(G::Local->GetEyePosition(), m_vEnd, Entity)) {

					if (flFOV <= m_flFOV) {

						if (G::Cmd->buttons & IN_ATTACK) {

							if (Settings::m_bLegitBotSilent) {
								G::Cmd->viewangles = vAim;
							}
							else {
								g_pEngineClient->SetViewAngles(vAim);
							}
							if (Settings::m_bLegitBotpSilent) {
								bSendPacket = false;
							}

						}

					}

				}
				else {
					bSendPacket = true;
				}

			}
			else {
				bSendPacket = true;
				iChokedPackets = 0;
			}

			FixMove(m_vOldViewAngle, m_fOldForwardMove, m_fOldSideMove);
			g_pMath->ClampAngles(vAim);
			g_pMath->NormalizeAngles(vAim);

		}

	}

}

/* VelocityPrediction */
void CLegitBot::VelocityPrediction(int i) {
	auto Entity = (CBaseEntity*)g_pIEntList->GetClientEntity(i);
	Vector Position = ((Entity->GetVelocity() * g_pGlobalVars->interval_per_tick * g_pGlobalVars->frametime) - (G::Local->GetVelocity() * g_pGlobalVars->interval_per_tick * g_pGlobalVars->frametime));
}

#pragma endregion

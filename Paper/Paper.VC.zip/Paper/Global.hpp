/* Paper-Global */
#pragma once

/* Includes */
#include "CUserCmd.hpp"
#include "CBaseEntity.hpp"

/* Global Namespace */
namespace G {
	extern CBaseEntity* Local;
	extern CUserCmd* Cmd;
	extern bool SendPacket;
}
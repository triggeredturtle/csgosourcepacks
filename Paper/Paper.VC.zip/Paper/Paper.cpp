/* 
.-.
(_) )-.
.:   \  .-.  `..:.   .-.   .;.::.
.:'    );   :  ;;  :.;.-'   .;
.-:. `--' `:::'-';;_.` `:::'.;'
(_/
*/
/*

Description: Cheat for counter-strike global offensive.

Credits: 

       aphu
	   EddyK
	   UnKnownCheats
	   Valve
	   A5
	   NanoCat
	   how02
	   imitat0r

*/
#include "Paper.hpp"

/* Paper Function */
/*
Purpose: Init everything here.
*/
void Paper() {
	Setup::SetupInterfaces();
	Setup::SetupHooks();
	Setup::SetupFonts();
	Offsets::GetOffsets();
}

/* Entry */
/*
Purpose: hinstDLL - Handle to the Dll Module, fdwReason - Reason for calling func, lpReserved - "reserved"
*/
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpReserved)   {
	switch (fdwReason) {
	case DLL_PROCESS_ATTACH:
		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)Paper, NULL, NULL, NULL);
	}
	return TRUE;
}
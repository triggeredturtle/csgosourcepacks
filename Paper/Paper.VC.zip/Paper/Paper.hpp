/* Paper-Header */
#pragma once

/* Dependencies */
#include <windows.h>
#include <string>
#include <vector>
#include <math.h>
#include <algorithm>
#include <Psapi.h>

/* Utilities */
#include "VirtualMethod.hpp"
#include "GetVFunc.hpp"
#include "Color.hpp"
#include "Pattern.hpp"
#include "Draw.hpp"
#include "Vector.hpp"
#include "Math.hpp"
#include "Offsets.hpp"
#include "Global.hpp"

/* Setup */
#include "Setup.hpp"

/* SDK */

// >> Client
#include "IBaseClientDll.hpp"
#include "CUserCmd.hpp"
#include "IClientEntityList.hpp"
#include "IClientModeShared.hpp"
#include "CBaseEntity.hpp"
#include "IClientEntity.hpp"
#include "ICollideable.hpp"
#include "Trace.hpp"

// >> Player
#include "IPlayerInfoManager.hpp"
#include "VMatrix.hpp"
#include "CGlowObjectManager.hpp"

// >> Engine
#include "IEngineVGui.hpp"
#include "IVEngineClient.hpp"

// >> VGui
#include "ISurface.hpp"
#include "IPanel.hpp"

/* Features */
#include "RageBot.hpp"
#include "LegitBot.hpp"
#include "Visuals.hpp"
#include "Misc.hpp"

// >> Util
#include "MenuItem.hpp"
#include "Buttons.hpp"
#include "KeyStroke.hpp"

// >> Settings
#include "Settings.hpp"

// >> Main
#include "Menu.hpp"
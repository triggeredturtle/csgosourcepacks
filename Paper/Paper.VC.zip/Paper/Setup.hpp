/* Paper-Setup */
#pragma once

/* Type Definitions */
typedef void *(*CreateInterfaceFn)(const char* Name, int* IRet);
typedef unsigned long HFont;
typedef float matrix3x4[3][4];

/* Fonts Namespace */
namespace Fonts {
	extern HFont Tahoma;
}

/* Setup Namespace */
/*
Purpose: Stores functions used for initializing hooks, grabbing interfaces, etc.
*/
namespace Setup {
	extern void SetupFonts();
	extern void SetupInterfaces();
	extern void SetupHooks();
}

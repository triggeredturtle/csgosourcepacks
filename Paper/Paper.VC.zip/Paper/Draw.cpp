/* Paper-Draw */
#include "Paper.hpp"

/* DrawString */
void Draw::DrawString(int x, int y, Color Col, unsigned long Font, const char* pszText) {
	if (pszText == NULL)
		return;
	wchar_t szString[1024] = { '\0' };
	wsprintfW(szString, L"%S", pszText);
	g_pSurface->DrawSetTextPos(x, y);
	g_pSurface->DrawSetTextFont(Font);
	g_pSurface->DrawSetTextColor(Col);
	g_pSurface->DrawPrintText(szString, wcslen(szString));
}

/* Clear */
void Draw::Clear(int x, int y, int w, int h, Color Col) {
	g_pSurface->DrawSetColor(Col);
	g_pSurface->DrawFilledRect(x, y, x + w, y + h);
}

/* FillRGBA */
void Draw::FillRGBA(int x, int y, int w, int h, int r, int g, int b, int a) {
	g_pSurface->DrawSetColor(r, g, b, a);
	g_pSurface->DrawFilledRect(x, y, x + w, y + h);
}

/* TextW */
/*
Credits: imitat0r
*/
void Draw::TextW(unsigned long font, int x, int y, Color Col, wchar_t* pszString) {
	g_pSurface->DrawSetTextColor(Col);
	g_pSurface->DrawSetTextFont(font);
	g_pSurface->DrawSetTextPos(x, y);
	g_pSurface->DrawPrintText(pszString, (int)wcslen(pszString));
}

/* Text */
/*
Credits: imitat0r
*/
void Draw::Text(int x, int y,Color Col, unsigned long font, const char*fmt, ...) {
	if (!font)
		return;

	va_list va_alist;
	char szBuffer[1024] = { '\0' };

	va_start(va_alist, fmt);
	vsprintf_s(szBuffer, fmt, va_alist);
	va_end(va_alist);

	wchar_t* pszStringWide = reinterpret_cast<wchar_t*>(malloc((strlen(szBuffer) + 1) * sizeof(wchar_t)));
	mbstowcs(pszStringWide, szBuffer, (strlen(szBuffer) + 1) * sizeof(wchar_t));
	
	TextW(font, x, y, Col, pszStringWide);

	delete[] pszStringWide;
}

/* DrawOutlinedRect */
void Draw::DrawOutlinedRect(int x, int y, int w, int h, Color col) {
	g_pSurface->DrawSetColor(col);
	g_pSurface->DrawOutlinedRect(x, y, x + w, y + h);
}

/* DrawLine */
void Draw::DrawLine(int x0, int y0, int x1, int y1, Color col) {
	g_pSurface->DrawSetColor(col);
	g_pSurface->DrawLine(x0, y0, x1, y1);
}

/* DrawCircle */
void Draw::DrawCircle(int x, int y, float r, int s, Color Col) {
	g_pSurface->DrawSetColor(Col);
	g_pSurface->DrawOutlinedCircle(x, y, r, s);
}
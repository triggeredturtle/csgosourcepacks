/* Paper-Entity */
#include "Paper.hpp"

/* GetFlags */
int CBaseEntity::GetFlags() {
	return *(int*)((DWORD)this + 0x100); // Returns m_fFlags
}

/* GetHealth */
int CBaseEntity::GetHealth() {
	return *(int*)((DWORD)this + 0xFC); // returns m_iHealth
}

/* GetTeam */
int CBaseEntity::GetTeam() {
	return *(int*)((DWORD)this + 0xF0); // returns m_iTeamNum
}

/* GetShotsFired */
int CBaseEntity::GetShotsFired() {
	return *(int*)((DWORD)this + 0xA2C0); // returns m_iShotsFired
}

/* GetTickCount */
int CBaseEntity::GetTickBase() {
	return *(int*)((DWORD)this + 0x3424);
}

/* GetDormant */
bool CBaseEntity::GetDormant() {
	return *(bool*)((DWORD)this + 0xE9); // returns m_bDormant
}

/* GetOrigin */
Vector CBaseEntity::GetOrigin() {
	return *(Vector*)((DWORD)this + 0x134); // returns m_vecOrigin
}

/* GetEyePosition */
Vector CBaseEntity::GetEyePosition() {
	return *(Vector*)((DWORD)this + 0x104) + GetOrigin(); // returns the players eye position
}

/* GetBonePosition */
Vector CBaseEntity::GetBonePosition(int Bone) {
	matrix3x4 matrix[128];

	this->SetupBones(matrix, 128, 0x100, g_pGlobalVars->curtime);

	return Vector(matrix[Bone][0][3], matrix[Bone][1][3], matrix[Bone][2][3]); // returns a bone
}

/* GetPunch */
Vector CBaseEntity::GetPunch() {
	return *(Vector*)((DWORD)this + 0x301C); // returns m_vecPunch
}

/* GetVisPunch */
Vector CBaseEntity::GetVisPunch() {
	return *(Vector*)((DWORD)this + 0x300C);
}

/* GetVelocity */
Vector CBaseEntity::GetVelocity() {
	return *(Vector*)((DWORD)this + 0x110);
}

/* GetMoveType */
int CBaseEntity::GetMoveType() {
	return *(int*)((DWORD)this + 0x258); // returns m_bMoveType;
}

/* GetCollideable */
ICollideable* CBaseEntity::GetCollideable() {
	return (ICollideable*)((DWORD)this + 0x318);
}


/* Paper-Virtual-Method */
#pragma once

/* Virtual Method Table */
/*
Purpose: A virtual method table is an array of pointers to -virtual- functions. The pointer to the VMT, to the MS C++ Compiler, is placed in the first object
         of a class, or the first 4 bytes. - https://www.unknowncheats.me/forum/unreal-3-engine/69951-tutorial-vtable-hooking-vmt-hooking-unreal-engine-c.html
		                                   - https://en.wikipedia.org/wiki/Virtual_method_table
*/
class CVMT {
public:
	/* Contructors */
	CVMT(void) { memset(this, 0, sizeof(CVMT)); } // Set the size of the VMT using memset.
	CVMT(PDWORD* dwClassBase) { Initialize(dwClassBase); }
	/* Funcs */
	DWORD dwGetVMTCount(PDWORD pdwVMT);
	bool Initialize(PDWORD* dwClassBase);
	bool Initialize(PDWORD** pClassBase);
	DWORD dwHookMethod(DWORD dwNewFunc, unsigned int iIndex);
	/* Function */
	template< typename T > T Function(int iIndex) {
		return (T)(m_ppdwOldVmt[iIndex]);
	}
private:
	PDWORD* m_ppdwClassBase;
	PDWORD m_ppdwNewVmt, m_ppdwOldVmt;
	DWORD m_dwVMTSize;
}; extern CVMT* g_pVGuiHook; extern CVMT* g_pClientModeHook; extern CVMT* g_pPanelHook;
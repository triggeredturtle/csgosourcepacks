/* Paper-Panel */
#pragma once

/* IPanel */
class IPanel {
public:
	const char* GetName(int Panel);
}; extern IPanel* g_pPanel;

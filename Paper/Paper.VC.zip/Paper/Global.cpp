/* Paper-Global */
#include "Paper.hpp"

CBaseEntity* G::Local;
CUserCmd* G::Cmd;
bool G::SendPacket;
/* Paper-Engine-VGui */
#include "Paper.hpp"

IEngineVGui* g_pEngineVGui;

/* IsGameUIVisible */
bool IEngineVGui::IsGameUIVisible() {
	typedef bool(__thiscall* OriginalFn)(void*);
	return GetVFunc<OriginalFn>(this, 3)(this);
}
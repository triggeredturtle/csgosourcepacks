/* Paper-Entity */
#pragma once

/* Includes */
#include "ICollideable.hpp"
#include "IClientEntity.hpp"

/* CBaseEntity */
class CBaseEntity : public IClientEntity {
public:
	int GetFlags();
	int GetHealth();
	int GetTeam();
	int GetShotsFired();
	int GetMoveType();
	int GetTickBase();
	bool GetDormant();
	Vector GetOrigin();
	Vector GetEyePosition();
	Vector GetBonePosition(int Bone);
	Vector GetPunch();
	Vector GetVisPunch();
	Vector GetVelocity();
	ICollideable* GetCollideable();
};

/* Paper-Setup */
#include "Paper.hpp"

/* Factories */
CreateInterfaceFn g_ClientFactory = NULL;
CreateInterfaceFn g_EngineFactory = NULL;
CreateInterfaceFn g_ServerFactory = NULL;
CreateInterfaceFn g_MatSurfaceFactory = NULL;
CreateInterfaceFn g_VGUI2Factory = NULL;

/* Fonts */
HFont Fonts::Tahoma;

/* CreateMove */
typedef bool(__thiscall* CreateMoveFn)(void*, float, CUserCmd*);
CreateMoveFn g_fnCreateMove;
bool __stdcall hkCreateMove(float flInputSampleTime, CUserCmd* Cmd) {

	g_pClientModeHook->Function<CreateMoveFn>(24)(g_pClientMode, flInputSampleTime, Cmd);

	if (Cmd->command_number == 0)
		return false;

	uintptr_t* fp;
	__asm mov fp, ebp;
	bool* pbSendPacket = (bool*)(*fp - 0x1C);
	bool& bSendPacket = *pbSendPacket;

	G::Local = (CBaseEntity*)g_pIEntList->GetClientEntity(g_pEngineClient->GetLocalPlayer());
	G::Cmd = Cmd;
	G::SendPacket = bSendPacket;

	if (g_pEngineClient->IsInGame() && g_pEngineClient->IsConnected()) {
		g_pMisc->AutoHop();
		g_pMisc->AutoStrafe();
		g_pMisc->AirStuck();
		g_pMisc->Tag();
		g_pRageBot->AntiAim();
		g_pRageBot->RageBot();
		g_pLegitBot->LegitBot(bSendPacket);
	}

	if (Settings::m_bAntiUntrusted) {
		g_pMath->ClampAngles(Cmd->viewangles);
		g_pMath->NormalizeAngles(Cmd->viewangles);
	}

	return false;

}

/* Paint */
typedef void(__thiscall* PaintFn)(IEngineVGui*, int);
PaintFn g_fnPaint;
void __stdcall hkPaint(int Mode) {

	/* Start & Finish Drawing */
	static auto StartDrawing = reinterpret_cast<void(__thiscall*)(void*)>(Pattern::FindPattern("vguimatsurface.dll", "55 8B EC 83 E4 C0 83 EC 38"));
	static auto FinishDrawing = reinterpret_cast<void(__thiscall*)(void*)>(Pattern::FindPattern("vguimatsurface.dll", "8B 0D ? ? ? ? 56 C6 05"));

	/* Call the original to make sure cs go runs properly */
	g_pVGuiHook->Function<PaintFn>(14)(g_pEngineVGui, Mode);

	if (!g_pEngineClient->IsInGame() && !g_pEngineClient->IsConnected()) return;

	if (Mode & PAINT_UIPANELS) {

		// >> Start
		StartDrawing(g_pSurface);

		g_pVisuals->WaterMark();
		g_pVisuals->ESP();

		// >> Menu 
		static auto m_bMenuActive = false;

		if (GetAsyncKeyState(VK_INSERT) & 1)
			m_bMenuActive = !m_bMenuActive;

		if (m_bMenuActive) {
			g_pMenu->InsertMenuItems();
			g_pMenu->DrawMenu();
		}

		// >> End
		FinishDrawing(g_pSurface);

	}

}

/* PaintTraverse */
typedef void(__thiscall* PaintTraverseFn)(void*, unsigned int, bool, bool);
PaintTraverseFn g_fnPaintTraverse;
void __stdcall hkPaintTraverse(int vguiPanel, bool forceRepaint, bool allowForce) {

	g_pPanelHook->Function<PaintTraverseFn>(41)(g_pPanel, vguiPanel, forceRepaint, allowForce);

	static unsigned int drawPanel;
	if (!drawPanel)
		if (strstr(g_pPanel->GetName(vguiPanel), "MatSystemTopPanel"))
			drawPanel = vguiPanel;

	if (vguiPanel != drawPanel) return;

	if (!g_pEngineClient->IsInGame() || !g_pEngineClient->IsConnected()) return;

	g_pVisuals->Glow();

}

/* SetupFonts */
void Setup::SetupFonts() {
	g_pSurface->SetFontGlyphSet(Fonts::Tahoma = g_pSurface->Create_Font(), "Tahoma", 12, FW_BOLD, NULL, NULL, FONTFLAG_DROPSHADOW);
}

/* SetupInterfaces */
void Setup::SetupInterfaces() {

	/* Setup Factories */ 
	/*
	Purpose: Open handles to modules we need.
	*/
	g_ClientFactory = reinterpret_cast<CreateInterfaceFn>(GetProcAddress(GetModuleHandleA("client.dll"), "CreateInterface"));
	g_EngineFactory = reinterpret_cast<CreateInterfaceFn>(GetProcAddress(GetModuleHandleA("engine.dll"), "CreateInterface"));
	g_ServerFactory = reinterpret_cast<CreateInterfaceFn>(GetProcAddress(GetModuleHandleA("server.dll"), "CreateInterface"));
	g_MatSurfaceFactory = reinterpret_cast<CreateInterfaceFn>(GetProcAddress(GetModuleHandleA("vguimatsurface.dll"), "CreateInterface"));
	g_VGUI2Factory = reinterpret_cast<CreateInterfaceFn>(GetProcAddress(GetModuleHandleA("vgui2.dll"), "CreateInterface"));

	if (g_pClient == nullptr) { // Prevent repeat calling

		// >> Client
		g_pClient = static_cast<IBaseClientDll*>(g_ClientFactory("VClient018", nullptr));
		g_pIEntList = static_cast<IClientEntityList*>(g_ClientFactory("VClientEntityList003", nullptr));

		// >> Engine
		g_pEngineClient = static_cast<IVEngineClient*>(g_EngineFactory("VEngineClient014", nullptr));
		g_pEngineVGui = static_cast<IEngineVGui*>(g_EngineFactory("VEngineVGui001", nullptr));
		g_pEngineTrace = static_cast<IEngineTrace*>(g_EngineFactory("EngineTraceClient004", nullptr));

		// >> Player
		g_pPlayerInfo = static_cast<IPlayerInfoManager*>(g_ServerFactory("PlayerInfoManager002", nullptr));
		g_pGlobalVars = g_pPlayerInfo->GetGlobalVars();

		// >> VGui
		g_pSurface = static_cast<ISurface*>(g_MatSurfaceFactory("VGUI_Surface031", nullptr));
		g_pPanel = static_cast<IPanel*>(g_VGUI2Factory("VGUI_Panel009", nullptr));

	}

}

/* SetupHooks */
void Setup::SetupHooks() {

	g_pVGuiHook = new CVMT((DWORD**)g_pEngineVGui); // Init the VGui hook.
	void ** g_pBaseClient = *(void***)g_pClient;
	g_pClientMode = *(IClientModeShared***)((DWORD)g_pBaseClient[10] + 5);
	g_pClientModeHook = new CVMT(*(DWORD***)g_pClientMode);
	g_pPanelHook = new CVMT((DWORD**)g_pPanel);

	// We are taking the pointer to the Paint function, and replacing it with our own.
	g_fnCreateMove = (CreateMoveFn)g_pClientModeHook->dwHookMethod((DWORD)hkCreateMove, 24);
	g_fnPaint = (PaintFn)g_pVGuiHook->dwHookMethod((DWORD)hkPaint, 14);
	g_fnPaintTraverse = (PaintTraverseFn)g_pPanelHook->dwHookMethod((DWORD)hkPaintTraverse, 41);

}


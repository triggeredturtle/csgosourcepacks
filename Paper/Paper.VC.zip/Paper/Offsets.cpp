/* Paper-Offsets */
#include "Paper.hpp"

Offsets_t tOffsets;

/* GetOffsets */
void Offsets::GetOffsets() {
	tOffsets.GlowManager = *(DWORD*)(Pattern::FindPattern("client.dll", "F3 ?? ?? ?? ?? ?? ?? ?? 83 C8 01 C7 05") + 0x4);
}
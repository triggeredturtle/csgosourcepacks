/* Paper-Trace */
#include "Paper.hpp"

IEngineTrace* g_pEngineTrace;

/* TraceRay */
void IEngineTrace::TraceRay(const Ray_t& ray, unsigned int fMask, ITraceFilter* pTraceFilter, trace_t* pTrace) {
	typedef void(__thiscall* oTraceRay)(void*, const Ray_t&, unsigned int, ITraceFilter*, trace_t*);
	return GetVFunc<oTraceRay>(this, 5)(this, ray, fMask, pTraceFilter, pTrace);
}
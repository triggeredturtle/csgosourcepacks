/* Paper-ClientEntity */
#pragma once

/* Includes */
#include "Setup.hpp"

/* IClientEntity */
class IClientEntity {
public:
	void* GetClientRenderable();
	bool SetupBones(matrix3x4* pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime);
}; extern IClientEntity* g_pClientEnt;

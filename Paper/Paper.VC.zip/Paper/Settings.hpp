/* Paper-Settings */
#pragma once

namespace Settings {

	// >> RageBot
	extern bool m_bRageBot;
	extern float m_flRageBotFOV;
	extern bool m_bRageBotSilent;
	extern bool m_bRageBotAutoShoot;
	extern bool m_bRageBotAutoDuck;
	extern bool m_bRageBotBodyAim;
	extern bool m_bRageBotPrediction;
	extern bool m_bRageBotRCS;
	extern bool m_bRageBotHitChance;
	extern float m_flRageBotHitChanceAmount;

	// >> LegitBot
	extern bool m_bLegitBot;
	extern float m_flLegitBotFOV;
	extern bool m_bLegitBotSilent;
	extern bool m_bLegitBotpSilent;
	extern bool m_bLegitBotBodyAim;
	extern bool m_bLegitBotPrediction;

	// >> Visuals 
	extern bool m_bBoxEsp;
	extern bool m_bGlowEsp;
	extern bool m_bHealthBar;
	extern bool m_bWaterMark;
	extern bool m_bTimeStamp;
	extern bool m_bCrossHair;
	extern int m_iCrossHairType;

	// >> Misc 
	extern bool m_bAutoHop;
	extern bool m_bAutoStrafe;
	extern bool m_bAirStuck;
	extern bool m_bAntiUntrusted;
	extern bool m_bClanTag;
	extern int m_iClanTagStyle;

	// >> HvH
	extern int m_iAntiAimX;
	extern int m_iAntiAimY;

	// >> Color
	extern int m_iESPR_T;
	extern int m_iESPG_T;
	extern int m_iESPB_T;
	extern int m_iESPA_T;
	extern int m_iESPR_CT;
	extern int m_iESPG_CT;
	extern int m_iESPB_CT;
	extern int m_iESPA_CT;
}
/* Paper-Client-Entity-List */
#include "Paper.hpp"

IClientEntityList* g_pIEntList;

/* GetClientEntity */
int IClientEntityList::GetClientEntity(int Index) {
	typedef int(__thiscall* OriginalFn)(void*, int);
	return GetVFunc<OriginalFn>(this, 3)(this, Index);
}

/* GetHighestEntityIndex */
int IClientEntityList::GetHighestEntityIndex() {
	typedef int(__thiscall* OriginalFn)(void*);
	return GetVFunc<OriginalFn>(this, 6)(this);
}

/* GetClientEntityFromHandle */
DWORD IClientEntityList::GetClientEntityFromHandle(DWORD Entity) {
	typedef DWORD(__thiscall* OriginalFn)(void*, DWORD);
	return GetVFunc<OriginalFn>(this, 4)(this, Entity);
}
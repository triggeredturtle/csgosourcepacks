/* Paper-ClientMode */
#pragma once

/* IClientModeShared */
class IClientModeShared {
public:
}; extern IClientModeShared** g_pClientMode;

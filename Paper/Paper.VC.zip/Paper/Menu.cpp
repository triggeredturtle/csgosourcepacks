/* Paper-Menu */
#include "Paper.hpp"

CMenu* g_pMenu;

/* Definitions */
MenuItem_t Items[120];
bool m_bLegitBotTab = false;
bool m_bRageBotTab = false;
bool m_bVisualsTab = false;
bool m_bMiscTab = false;
bool m_bHvHTab = false;
bool m_bColorTab = false;
int m_iTotalItems = 0, m_iCurrentPos = 0, m_iMenuX = 250, m_iMenuY = 250;

/* AddMenuEntry */
int AddMenuEntry(int n, std::string sName, bool* bValue) {
	Items[n].m_Name = sName;
	Items[n].m_Bool = bValue;
	Items[n].m_Type = 0;
	return (n + 1);
}

/* AddMenuEntry, pt.2 Electric Boogaloo! */
int AddMenuEntry(int n, std::string sName, int* iValue, int iMin, int iMax, int iStep) {
	Items[n].m_Name = sName;
	Items[n].m_Int = iValue;
	Items[n].m_IntMin = iMin;
	Items[n].m_IntMax = iMax;
	Items[n].m_IntStep = iStep;
	Items[n].m_Type = 1;
	return (n + 1);
}

/* AddMenuEntry, pt.3 Back to the future! */
int AddMenuEntry(int n, std::string sName, float* flValue, float flMin, float flMax, float flStep) {
	Items[n].m_Name = sName;
	Items[n].m_Float = flValue;
	Items[n].m_FloatMin = flMin;
	Items[n].m_FloatMax = flMax;
	Items[n].m_FloatStep = flStep;
	Items[n].m_Type = 2;
	return (n + 1);
}

/* InsertMenuItems */
void CMenu::InsertMenuItems() {

	int i = 0;

	if (!m_bLegitBotTab)
		i = AddMenuEntry(i, "[+] LEGITBOT", &m_bLegitBotTab);
	if (m_bLegitBotTab) {
		i = AddMenuEntry(i, "[-] LEGITBOT", &m_bLegitBotTab);
		i = AddMenuEntry(i, "Enabled", &Settings::m_bLegitBot);
		i = AddMenuEntry(i, "Fov", &Settings::m_flLegitBotFOV, 0.f, 15.f, .1f);
		i = AddMenuEntry(i, "Silent", &Settings::m_bLegitBotSilent);
		i = AddMenuEntry(i, "pSilent", &Settings::m_bLegitBotpSilent);
		i = AddMenuEntry(i, "Body Aim", &Settings::m_bLegitBotBodyAim);
		i = AddMenuEntry(i, "Prediction", &Settings::m_bLegitBotPrediction);
	}

	if (!m_bRageBotTab)
		i = AddMenuEntry(i, "[+] RAGEBOT", &m_bRageBotTab);
	if (m_bRageBotTab) {
		i = AddMenuEntry(i, "[-] RAGEBOT", &m_bRageBotTab);
		i = AddMenuEntry(i, "Enabled", &Settings::m_bRageBot);
		i = AddMenuEntry(i, "Auto Shoot", &Settings::m_bRageBotAutoShoot);
		i = AddMenuEntry(i, "Auto Duck", &Settings::m_bRageBotAutoDuck);
		i = AddMenuEntry(i, "Silent", &Settings::m_bRageBotSilent);
		i = AddMenuEntry(i, "Fov", &Settings::m_flRageBotFOV, 0.f, 180.f, .1f);
		i = AddMenuEntry(i, "Body Aim", &Settings::m_bRageBotBodyAim);
		i = AddMenuEntry(i, "Prediction", &Settings::m_bRageBotPrediction);
		i = AddMenuEntry(i, "Recoil Control", &Settings::m_bRageBotRCS);
	}

	if (!m_bVisualsTab)
		i = AddMenuEntry(i, "[+] VISUALS", &m_bVisualsTab);
	if (m_bVisualsTab) {
		i = AddMenuEntry(i, "[-] VISUALS", &m_bVisualsTab);
		i = AddMenuEntry(i, "Box Esp", &Settings::m_bBoxEsp);
		i = AddMenuEntry(i, "Health Bar", &Settings::m_bHealthBar);
		i = AddMenuEntry(i, "Glow", &Settings::m_bGlowEsp);
		i = AddMenuEntry(i, "Watermark", &Settings::m_bWaterMark);
		i = AddMenuEntry(i, "Timestamp", &Settings::m_bTimeStamp);
	}

	if (!m_bMiscTab)
		i = AddMenuEntry(i, "[+] MISC", &m_bMiscTab);
	if (m_bMiscTab) {
		i = AddMenuEntry(i, "[-] MISC", &m_bMiscTab);
		i = AddMenuEntry(i, "Autohop", &Settings::m_bAutoHop);
		i = AddMenuEntry(i, "Autostrafe", &Settings::m_bAutoStrafe);
		i = AddMenuEntry(i, "Air Stuck", &Settings::m_bAirStuck);
		i = AddMenuEntry(i, "Anti Untrusted", &Settings::m_bAntiUntrusted);
		i = AddMenuEntry(i, "Clan Tag", &Settings::m_bClanTag);
		i = AddMenuEntry(i, "Clan Tag Style", &Settings::m_iClanTagStyle, 0, 4, 1);
	}

	if (!m_bHvHTab)
		i = AddMenuEntry(i, "[+] HVH", &m_bHvHTab);
	if (m_bHvHTab) {
		i = AddMenuEntry(i, "[-] HVH", &m_bHvHTab);
		i = AddMenuEntry(i, "Anti Aim Yaw", &Settings::m_iAntiAimY, 0, 7, 1);
		i = AddMenuEntry(i, "Anti Aim Pitch", &Settings::m_iAntiAimX, 0, 8, 1);

		// >> Pitch
		if (Settings::m_iAntiAimX == 1) {
			Draw::Text(m_iMenuX, m_iMenuY - 10, Color(255, 255, 255, 255), Fonts::Tahoma, "Pitch: Down");
		}
		if (Settings::m_iAntiAimX == 2) {
			Draw::Text(m_iMenuX, m_iMenuY - 10, Color(255, 255, 255, 255), Fonts::Tahoma, "Pitch: Emotion");
		}
		if (Settings::m_iAntiAimX == 3) {
			Draw::Text(m_iMenuX, m_iMenuY - 10, Color(255, 255, 255, 255), Fonts::Tahoma, "Pitch: Fake Emotion");
		}
		if (Settings::m_iAntiAimX == 4) {
			Draw::Text(m_iMenuX, m_iMenuY - 10, Color(255, 255, 255, 255), Fonts::Tahoma, "Pitch: Fake Down");
		}
		if (Settings::m_iAntiAimX == 5) {
			Draw::Text(m_iMenuX, m_iMenuY - 10, Color(255, 255, 255, 255), Fonts::Tahoma, "Pitch: Fake Up");
		}
		if (Settings::m_iAntiAimX == 6) {
			Draw::Text(m_iMenuX, m_iMenuY - 10, Color(255, 255, 255, 255), Fonts::Tahoma, "Pitch: Up");
		}
		if (Settings::m_iAntiAimX == 7) {
			Draw::Text(m_iMenuX, m_iMenuY - 10, Color(255, 255, 255, 255), Fonts::Tahoma, "Pitch: Lisp Down");
		}
		if (Settings::m_iAntiAimX == 8) {
			Draw::Text(m_iMenuX, m_iMenuY - 10, Color(255, 255, 255, 255), Fonts::Tahoma, "Pitch: Lisp Up");
		}

		// >> Yaw
		if (Settings::m_iAntiAimY == 1) {
			Draw::Text(m_iMenuX, m_iMenuY - 20, Color(255, 255, 255, 255), Fonts::Tahoma, "Yaw: Backwards");
		}
		if (Settings::m_iAntiAimY == 2) {
			Draw::Text(m_iMenuX, m_iMenuY - 20, Color(255, 255, 255, 255), Fonts::Tahoma, "Yaw: Jitter");
		}
		if (Settings::m_iAntiAimY == 3) {
			Draw::Text(m_iMenuX, m_iMenuY - 20, Color(255, 255, 255, 255), Fonts::Tahoma, "Yaw: Fake Origin");
		}
		if (Settings::m_iAntiAimY == 4) {
			Draw::Text(m_iMenuX, m_iMenuY - 20, Color(255, 255, 255, 255), Fonts::Tahoma, "Yaw: Sideways Jitter");
		}
		if (Settings::m_iAntiAimY == 5) {
			Draw::Text(m_iMenuX, m_iMenuY - 20, Color(255, 255, 255, 255), Fonts::Tahoma, "Yaw: Fast Spin");
		}
		if (Settings::m_iAntiAimY == 6) {
			Draw::Text(m_iMenuX, m_iMenuY - 20, Color(255, 255, 255, 255), Fonts::Tahoma, "Yaw: Slow Spin");
		}
		if (Settings::m_iAntiAimY == 7) {
			Draw::Text(m_iMenuX, m_iMenuY - 20, Color(255, 255, 255, 255), Fonts::Tahoma, "Yaw: Fake Sideways");
		}

	}

	if (!m_bColorTab)
		i = AddMenuEntry(i, "[+] COLOR", &m_bColorTab);
	if (m_bColorTab) {
		i = AddMenuEntry(i, "[-] COLOR", &m_bColorTab);
		i = AddMenuEntry(i, "color_esp_ct_r", &Settings::m_iESPR_CT, 1, 255, 1);
		i = AddMenuEntry(i, "color_esp_ct_g", &Settings::m_iESPG_CT, 1, 255, 1);
		i = AddMenuEntry(i, "color_esp_ct_b", &Settings::m_iESPB_CT, 1, 255, 1);
		i = AddMenuEntry(i, "color_esp_ct_a", &Settings::m_iESPA_CT, 1, 255, 1);
		i = AddMenuEntry(i, "color_esp_t_r", &Settings::m_iESPR_T, 1, 255, 1);
		i = AddMenuEntry(i, "color_esp_t_g", &Settings::m_iESPG_T, 1, 255, 1);
		i = AddMenuEntry(i, "color_esp_t_b", &Settings::m_iESPB_T, 1, 255, 1);
		i = AddMenuEntry(i, "color_esp_t_a", &Settings::m_iESPA_T, 1, 255, 1);
	}

	m_iTotalItems = i;

}

/* DrawMenu */
void CMenu::DrawMenu() {

	// FontSize 
	int FontSize = 13;

	/* Draw Box */
	Draw::FillRGBA(m_iMenuX - 20, m_iMenuY + 2 + (FontSize * m_iCurrentPos) + 3, 215, FontSize + 2, 223, 185, 229, 220);

	/* Stuff Here */
	for (int i = 0; i < m_iTotalItems; ++i) {

		if (!strncmp(Items[i].m_Name.c_str(), "[+]", 3) || !strncmp(Items[i].m_Name.c_str(), "[-]", 3))
			Draw::Text(m_iMenuX, m_iMenuY + 2 + (FontSize * i) + 4, Color(255, 255, 255, 255), Fonts::Tahoma, Items[i].m_Name.c_str());

		else {

			switch (Items[i].m_Type) {
			case 0:
				Draw::Text(m_iMenuX, m_iMenuY + 2 + (FontSize * i) + 4, Color(255, 255, 255, 255), Fonts::Tahoma, Items[i].m_Name.c_str());
				Draw::Text(m_iMenuX + 150, m_iMenuY + 2 + (FontSize * i) + 4, Color(255, 255, 255, 255), Fonts::Tahoma, "%s", (*Items[i].m_Bool) ? "true" : "false");
				break;
			case 1:
				Draw::Text(m_iMenuX, m_iMenuY + 2 + (FontSize * i) + 4, Color(255, 255, 255, 255), Fonts::Tahoma, Items[i].m_Name.c_str());
				Draw::Text(m_iMenuX + 150, m_iMenuY + 2 + (FontSize * i) + 4, Color(255, 255, 255, 255), Fonts::Tahoma, "%i", *Items[i].m_Int);
				break;
			case 2:
				Draw::Text(m_iMenuX, m_iMenuY + 2 + (FontSize * i) + 4, Color(255, 255, 255, 255), Fonts::Tahoma, Items[i].m_Name.c_str());
				Draw::Text(m_iMenuX + 150, m_iMenuY + 2 + (FontSize * i) + 4, Color(255, 255, 255, 255), Fonts::Tahoma, "%.2f", *Items[i].m_Float);
				break;
			default:
				break;
			}
		}
	}

	if (GetAsyncKeyState(VK_UP) & 1) {
		if (m_iCurrentPos > 0)
			m_iCurrentPos--;
		else
			m_iCurrentPos = m_iTotalItems - 1;
	}

	else if (GetAsyncKeyState(VK_DOWN) & 1) {
		if (m_iCurrentPos < m_iTotalItems - 1)
			m_iCurrentPos++;
		else
			m_iCurrentPos = 0;
	}

	else if (GetAsyncKeyState(VK_LEFT) & 1) {
		switch (Items[m_iCurrentPos].m_Type) {
		case 0:
			*Items[m_iCurrentPos].m_Bool = !*Items[m_iCurrentPos].m_Bool;
			break;
		case 1:
			*Items[m_iCurrentPos].m_Int -= Items[m_iCurrentPos].m_IntStep;
			if (*Items[m_iCurrentPos].m_Int < Items[m_iCurrentPos].m_IntMin)
				*Items[m_iCurrentPos].m_Int = Items[m_iCurrentPos].m_IntMax;
			break;
		case 2:
			*Items[m_iCurrentPos].m_Float -= Items[m_iCurrentPos].m_FloatStep;
			if (*Items[m_iCurrentPos].m_Float < Items[m_iCurrentPos].m_FloatMin)
				*Items[m_iCurrentPos].m_Float = Items[m_iCurrentPos].m_FloatMax;
			break;
		default:
			break;
		}
	}
	else if (GetAsyncKeyState(VK_RIGHT) & 1) {
		switch (Items[m_iCurrentPos].m_Type) {
		case 0:
			*Items[m_iCurrentPos].m_Bool = !*Items[m_iCurrentPos].m_Bool;
			break;
		case 1:
			*Items[m_iCurrentPos].m_Int += Items[m_iCurrentPos].m_IntStep;
			if (*Items[m_iCurrentPos].m_Int > Items[m_iCurrentPos].m_IntMax)
				*Items[m_iCurrentPos].m_Int = Items[m_iCurrentPos].m_IntMin;
			break;
		case 2:
			*Items[m_iCurrentPos].m_Float += Items[m_iCurrentPos].m_FloatStep;
			if (*Items[m_iCurrentPos].m_Float > Items[m_iCurrentPos].m_FloatMax)
				*Items[m_iCurrentPos].m_Float = Items[m_iCurrentPos].m_FloatMin;
			break;
		default:
			break;
		}
	}
}
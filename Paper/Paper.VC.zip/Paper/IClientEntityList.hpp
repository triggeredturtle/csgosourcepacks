/* Paper-Client-Entity-List */
#pragma once

/* IClientEntityList */
class IClientEntityList {
public:
	int GetClientEntity(int Index);
	int GetHighestEntityIndex();
	DWORD GetClientEntityFromHandle(DWORD Entity);
}; extern IClientEntityList* g_pIEntList;

/* Paper-ClientEntity */
#include "Paper.hpp"

/* get renderable */
void * IClientEntity::GetClientRenderable() {
	return reinterpret_cast<void*>(this + 0x4);
}

/* setup bones */
bool IClientEntity::SetupBones(matrix3x4* pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime) {
	typedef bool(__thiscall * oSetupBones)(void*, matrix3x4*, int, int, float);
	return GetVFunc<oSetupBones>(this->GetClientRenderable(), 13)(this->GetClientRenderable(), pBoneToWorldOut, nMaxBones, boneMask, currentTime);
}
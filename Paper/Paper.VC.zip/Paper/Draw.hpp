/* Paper-Draw */
#pragma once

/* Warnings */
#pragma warning (disable : 4996)

/* Draw Namespace */
namespace Draw {
	extern void DrawString(int x, int y, Color Col, unsigned long Font, const char* pszText);
	extern void Clear(int x, int y, int w, int h, Color Col);
	extern void FillRGBA(int x, int y, int w, int h, int r, int g, int b, int a);
	extern void TextW(unsigned long font, int x, int y, Color Col, wchar_t* pszString);
	extern void Text(int x, int y, Color Col, unsigned long font, const char*fmt, ...);
	extern void DrawOutlinedRect(int x, int y, int w, int h, Color col);
	extern void DrawLine(int x0, int y0, int x1, int y1, Color col);
	extern void DrawCircle(int x, int y, float r, int s, Color Col);
}

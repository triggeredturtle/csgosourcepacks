/* Paper-Engine-Client */
#pragma once

/* IVEngineClient */
class IVEngineClient {
public:
	int GetLocalPlayer();
	bool IsInGame();
	bool IsConnected();
	void SetViewAngles(Vector& Ang);
	void GetViewAngles(Vector& vAngles);
	void GetScreenSize(int& Width, int& Height);
	const VMatrix& WorldToScreenMatrix();
	void ClientCmd_Unrestricted(char const* chCmd);
}; extern IVEngineClient* g_pEngineClient;

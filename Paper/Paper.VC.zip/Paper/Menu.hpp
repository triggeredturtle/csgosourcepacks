/* Paper-Menu */
#pragma once

/* CMenu */
class CMenu {
public:
	void InsertMenuItems();
	void DrawMenu();
}; extern CMenu* g_pMenu;
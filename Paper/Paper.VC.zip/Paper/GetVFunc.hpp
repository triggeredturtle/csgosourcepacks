/* Paper-GetVFunc */
#pragma once

// Credits : Nanocat

/* Get Virtual Func */
template< typename Fn >
inline Fn GetVFunc(const void* v, int i) {
	return (Fn)*(*(const void***)v + i);
}
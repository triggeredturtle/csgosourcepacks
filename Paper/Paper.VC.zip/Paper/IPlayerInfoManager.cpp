/* Paper-IPlayerInfo */
#include "Paper.hpp"

IPlayerInfoManager* g_pPlayerInfo;

/* GetGlobalVars */
CGlobalVarsBase * IPlayerInfoManager::GetGlobalVars() {
	typedef CGlobalVarsBase*(__thiscall* OriginalFn)(void*);
	return GetVFunc<OriginalFn>(this, 1)(this);
}
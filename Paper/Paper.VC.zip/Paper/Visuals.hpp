/* Paper-Visuals */
#pragma once

/* Warnings */
#pragma warning (disable : 4244)

/* CVisuals */
class CVisuals {
public:
	void DrawBox(int x, int y, int w, int h, Color Col);
	void HealthBar(Vector bot, Vector top, float health);
	bool WorldToScreen(const Vector& origin, Vector& screen);
	bool ScreenTransform(const Vector& point, Vector& screen);
	void ESP();
	void WaterMark();
	void Glow();
	void Crosshair();
}; extern CVisuals* g_pVisuals;

/* Paper-Trace */
#pragma once

/* Includes */
#include "Vector.hpp"
#include "Windows.h"
#include "CBaseEntity.hpp"

/* Defs */
class CGameTrace;
typedef float matrix3x4[3][4];
typedef CGameTrace trace_t;
#define CONTENTS_MOVEABLE		0x4000
#define	CONTENTS_MONSTER		0x2000000
#define	CONTENTS_EMPTY			0		
#define	CONTENTS_SOLID			0x1		
#define	CONTENTS_WINDOW			0x2		
#define	CONTENTS_AUX			0x4
#define	CONTENTS_GRATE			0x8		
#define	CONTENTS_SLIME			0x10
#define	CONTENTS_WATER			0x20
#define	CONTENTS_BLOCKLOS		0x40	
#define CONTENTS_OPAQUE			0x80	
#define	LAST_VISIBLE_CONTENTS	0x80
#define	CONTENTS_DEBRIS			0x4000000
#define CONTENTS_HITBOX			0x40000000
#define	MASK_SOLID		(CONTENTS_SOLID|CONTENTS_MOVEABLE|CONTENTS_WINDOW|CONTENTS_MONSTER|CONTENTS_GRATE)
#define	CONTENTS_MONSTERCLIP	0x20000
#define MASK_NPCWORLDSTATIC (CONTENTS_SOLID | CONTENTS_WINDOW | CONTENTS_MONSTERCLIP | CONTENTS_GRATE)
#define	HITGROUP_GENERIC	0
#define	HITGROUP_HEAD		1
#define	HITGROUP_CHEST		2
#define	HITGROUP_STOMACH	3
#define HITGROUP_LEFTARM	4	
#define HITGROUP_RIGHTARM	5
#define HITGROUP_LEFTLEG	6
#define HITGROUP_RIGHTLEG	7
#define HITGROUP_GEAR		10			// alerts NPC, but doesn't do damage or bleed (1/100th damage)

/* VectorAligned */
class VectorAligned : public Vector {
public:
	VectorAligned() { }

	VectorAligned(const Vector& vec) {
		this->x = vec.x;
		this->y = vec.y;
		this->z = vec.z;
	}

	float w;
};

/* TraceType */
enum TraceType_t {
	TRACE_EVERYTHING = 0,
	TRACE_WORLD_ONLY,
	TRACE_ENTITIES_ONLY,
	TRACE_EVERYTHING_FILTER_PROPS,
};

/* Surface*/
struct csurface_t {
	const char * name;
	short surfaceProps;
	unsigned short flags;
};

/* Plane */
struct cplane_t {
	Vector normal;
	float dist;
	BYTE type;
	BYTE signbits;
	BYTE pad[2];
};

/* TraceFilter */
class ITraceFilter {
public:
	virtual bool ShouldHitEntity(void* pEntity, int contentsMask) = 0;
	virtual TraceType_t	GetTraceType() const = 0;
};

/* TraceFilter pt.2 Electric Boogaloo */
class CTraceFilter : public ITraceFilter {
public:

	bool ShouldHitEntity(void* pEntityHandle, int contentsMask) {
		return !(pEntityHandle == pSkip);
	}

	virtual TraceType_t	GetTraceType() const {
		return TRACE_EVERYTHING;
	}

	void * pSkip;
};

/* TraceFilterSkip */
class CTraceFilterSkipTwoEntities : public ITraceFilter {
public:

	CTraceFilterSkipTwoEntities(void* pPassEnt1, void* pPassEnt2) {
		passentity1 = pPassEnt1;
		passentity2 = pPassEnt2;
	}

	virtual bool ShouldHitEntity(void* pEntityHandle, int contentsMask) {
		return !(pEntityHandle == passentity1 || pEntityHandle == passentity2);
	}

	virtual TraceType_t GetTraceType() const {
		return TRACE_EVERYTHING;
	}

	void* passentity1;
	void* passentity2;
};

/* Ray Struct */
struct Ray_t {
	Ray_t() { }

	VectorAligned m_Start;
	VectorAligned m_Delta;
	VectorAligned m_StartOffset;
	VectorAligned m_Extents;
	const matrix3x4* m_pWorldAxisTransform;
	bool m_IsRay;
	bool m_IsSwept;

	void Init(Vector vecStart, Vector vecEnd) {
		m_Delta = VectorAligned(vecEnd - vecStart);
		m_IsSwept = (m_Delta.LengthSqr() != 0);
		m_Extents.Zero();
		m_pWorldAxisTransform = NULL;
		m_IsRay = true;
		m_StartOffset.Zero();
		m_Start = vecStart;
	}
};

/* BaseTrace */
class CBaseTrace {
public:

	Vector startpos;
	Vector endpos;
	cplane_t plane;
	float fraction;
	int	contents;
	unsigned short dispFlags;
	bool allsolid;
	bool startsolid;

	CBaseTrace() {}
};

/* GameTrace */
class CGameTrace : public CBaseTrace {
public:
	bool DidHitWorld() const;
	bool DidHitNonWorldEntity() const;
	int GetEntityIndex() const;
	bool DidHit() const;
	bool IsVisible() const;
public:
	float fractionleftsolid;
	csurface_t surface;
	int hitgroup;
	short physicsbone;
	unsigned short worldSurfaceIndex;
	CBaseEntity * m_pEnt;
	int hitbox;
	CGameTrace() { }
private:
	CGameTrace(const CGameTrace& vOther);
};

/* CTraceEntity */
class CTraceEntity : public ITraceFilter {
public:
	bool ShouldHitEntity(void* pEntityHandle, int contentsMask) {
		return (pEntityHandle == pHit);
	}
	virtual TraceType_t	GetTraceType() const {
		return TRACE_ENTITIES_ONLY;
	}
	void* pHit;
};

/* IEngineTrace */
class IEngineTrace {
public:
	void TraceRay(const Ray_t& ray, unsigned int fMask, ITraceFilter* pTraceFilter, trace_t* pTrace);
}; extern IEngineTrace* g_pEngineTrace;
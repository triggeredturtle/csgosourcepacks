/* Paper-Visuals */
#include "Paper.hpp"

CVisuals* g_pVisuals;

/* Box */
void CVisuals::DrawBox(int x, int y, int w, int h, Color Col) {
	g_pSurface->DrawSetColor(Col);
	g_pSurface->DrawOutlinedRect(x - w, y, x + w, y + h);

	g_pSurface->DrawSetColor(Color(0, 0, 0, 255));
	g_pSurface->DrawOutlinedRect(x - w - 1, y - 1, x + w + 1, y + h + 1);
	g_pSurface->DrawOutlinedRect(x - w + 1, y + 1, x + w - 1, y + h - 1);
}

/* HealthBar */
void CVisuals::HealthBar(Vector bot, Vector top, float health) {
	float h = (bot.y - top.y);
	float offset = (h / 4.f) + 5;
	float w = h / 64.f;

	UINT hp = h - (UINT)((h * health) / 100); // Percentage

	int Red = 255 - (health*2.55);
	int Green = health*2.55;

	Draw::DrawOutlinedRect((top.x - offset) - 1, top.y - 1, 3, h + 2, Color(0, 0, 0, 255));

	Draw::DrawLine((top.x - offset), top.y + hp, (top.x - offset), top.y + h, Color(Red, Green, 0, 255));
}


/* ScreenTransform */
bool CVisuals::ScreenTransform(const Vector& point, Vector& screen) {
	float w;
	const VMatrix &worldToScreen = g_pEngineClient->WorldToScreenMatrix();

	screen.x = worldToScreen[0][0] * point[0] + worldToScreen[0][1] * point[1] + worldToScreen[0][2] * point[2] + worldToScreen[0][3];
	screen.y = worldToScreen[1][0] * point[0] + worldToScreen[1][1] * point[1] + worldToScreen[1][2] * point[2] + worldToScreen[1][3];
	w = worldToScreen[3][0] * point[0] + worldToScreen[3][1] * point[1] + worldToScreen[3][2] * point[2] + worldToScreen[3][3];
	screen.z = 0.0f;

	bool behind = false;

	if (w < 0.001f) {
		behind = true;
		screen.x *= 100000;
		screen.y *= 100000;
	}
	else {
		behind = false;
		float invw = 1.0f / w;
		screen.x *= invw;
		screen.y *= invw;
	}

	return behind;
}

/* WorldToScreen */
bool CVisuals::WorldToScreen(const Vector& origin, Vector& screen) {

	if (!ScreenTransform(origin, screen)) {
		int ScreenWidth, ScreenHeight;
		g_pEngineClient->GetScreenSize(ScreenWidth, ScreenHeight);
		float x = ScreenWidth / 2;
		float y = ScreenHeight / 2;
		x += 0.5 * screen.x * ScreenWidth + 0.5;
		y -= 0.5 * screen.y * ScreenHeight + 0.5;
		screen.x = x;
		screen.y = y;
		return true;
	}

	return false;
}

/* ESP */
void CVisuals::ESP() {

	int iScreenWidth, iScreenHeight;
	g_pEngineClient->GetScreenSize(iScreenWidth, iScreenHeight);

	for (int i = 0; i < g_pIEntList->GetHighestEntityIndex(); i++) {

		auto Entity = (CBaseEntity*)g_pIEntList->GetClientEntity(i);

		if (!G::Local || !Entity || Entity == G::Local || i == g_pEngineClient->GetLocalPlayer() || 0 >= Entity->GetHealth() || Entity->GetDormant()) continue;

		Vector vecMax = Entity->GetCollideable()->OBBMaxs();
		Vector vecPos, vecPos3D;
		Vector vecTop, vecTop3D;
		vecPos3D = Entity->GetOrigin();
		vecTop3D = vecPos3D + Vector(0, 0, vecMax.z);

		if (!WorldToScreen(vecPos3D, vecPos) || !WorldToScreen(vecTop3D, vecTop)) continue;

		float height = (vecPos.y - vecTop.y);
		float width = height / 4.f;

		if (Settings::m_bBoxEsp) {
			if (Entity->GetTeam() == 3) {
				DrawBox(vecTop.x, vecTop.y, width, height, Color(Settings::m_iESPR_CT, Settings::m_iESPG_CT, Settings::m_iESPB_CT, Settings::m_iESPA_CT));
			}
			if (Entity->GetTeam() == 2) {
				DrawBox(vecTop.x, vecTop.y, width, height, Color(Settings::m_iESPR_T, Settings::m_iESPG_T, Settings::m_iESPB_T, Settings::m_iESPA_T));
			}
		}

		if (Settings::m_bHealthBar) {
			HealthBar(vecPos, vecTop, Entity->GetHealth());
		}

	}

}

/* WaterMark */
void CVisuals::WaterMark() {

	if (Settings::m_bWaterMark) {
		Draw::DrawString(4, 4, Color(223, 185, 229, 220), Fonts::Tahoma, "Paper");
	}

	if (Settings::m_bTimeStamp) {
		Draw::DrawString(4, 17, Color(215, 227, 247, 130), Fonts::Tahoma, __TIMESTAMP__);
	}

}

/* Glow */
void CVisuals::Glow() {

	if (!Settings::m_bGlowEsp) return;

	/* GlowObjectManager pointer */
	CGlowObjectManager* GlowObjectManager = (CGlowObjectManager*)tOffsets.GlowManager;

	for (int i = 0; i < GlowObjectManager->size; ++i) {

		/* Grab Entity */
		CGlowObjectManager::GlowObjectDefinition_t* GlowEntity = &GlowObjectManager->m_GlowObjectDefinitions[i];
		CBaseEntity* Entity = GlowEntity->GetEntity();

		if (GlowEntity->IsEmpty() || !Entity)
			continue;

		if (!G::Local || !Entity || Entity == G::Local || i == g_pEngineClient->GetLocalPlayer() || 0 >= Entity->GetHealth() || Entity->GetDormant()) continue;

		if (Entity->GetTeam() == 3) // CT
			GlowEntity->Set(Color(Settings::m_iESPR_CT, Settings::m_iESPG_CT, Settings::m_iESPB_CT, Settings::m_iESPA_CT));
		if (Entity->GetTeam() == 2) // T
			GlowEntity->Set(Color(Settings::m_iESPR_T, Settings::m_iESPG_T, Settings::m_iESPB_T, Settings::m_iESPA_T));

	}

}

/* Crosshair */
void CVisuals::Crosshair() {

}
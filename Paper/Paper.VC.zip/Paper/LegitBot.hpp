/* Paper-Legit */
#pragma once

/* CLegitBot */
class CLegitBot {
public:
	bool IsVisible(Vector& vecAbsStart, Vector& vecAbsEnd, CBaseEntity* Entity);
	void FixMove(Vector m_vOldAngles, float m_fOldForward, float m_fOldSidemove);
	void LegitBot(bool& bSendPacket);
	void VelocityPrediction(int i);
}; extern CLegitBot* g_pLegitBot;

/* Paper-Offsets */
#pragma once

/* Offsets Struct */
struct Offsets_t {
	DWORD GlowManager;
}; extern Offsets_t tOffsets;

/* Offsets */
namespace Offsets {
	extern void GetOffsets();
}

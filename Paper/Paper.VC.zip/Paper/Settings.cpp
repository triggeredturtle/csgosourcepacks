/* Paper-Settings */
#include "Paper.hpp"

// >> RageBot
bool Settings::m_bRageBot = false;
float Settings::m_flRageBotFOV;
bool Settings::m_bRageBotSilent = false;
bool Settings::m_bRageBotAutoShoot = false;
bool Settings::m_bRageBotAutoDuck = false;
bool Settings::m_bRageBotBodyAim = false;
bool Settings::m_bRageBotPrediction = false;
bool Settings::m_bRageBotRCS = false;
bool Settings::m_bRageBotHitChance = false;
float Settings::m_flRageBotHitChanceAmount;

// >> LegitBot
bool Settings::m_bLegitBot = false;
float Settings::m_flLegitBotFOV;
bool Settings::m_bLegitBotSilent = false;
bool Settings::m_bLegitBotpSilent = false;
bool Settings::m_bLegitBotBodyAim = false;
bool Settings::m_bLegitBotPrediction = false;

// >> Visuals
bool Settings::m_bBoxEsp = false;
bool Settings::m_bGlowEsp = false;
bool Settings::m_bHealthBar = false;
bool Settings::m_bWaterMark = true;
bool Settings::m_bTimeStamp = true;
bool Settings::m_bCrossHair = false;
int Settings::m_iCrossHairType;

// >> Misc
bool Settings::m_bAutoHop = false;
bool Settings::m_bAutoStrafe = false;
bool Settings::m_bAirStuck = false;
bool Settings::m_bAntiUntrusted = true;
bool Settings::m_bClanTag = false;
int Settings::m_iClanTagStyle;

// >> HvH
int Settings::m_iAntiAimX;
int Settings::m_iAntiAimY;

// >> Color
int Settings::m_iESPR_T = 91;
int Settings::m_iESPG_T = 185;
int Settings::m_iESPB_T = 217;
int Settings::m_iESPA_T = 160;
int Settings::m_iESPR_CT = 219;
int Settings::m_iESPG_CT = 184;
int Settings::m_iESPB_CT = 241;
int Settings::m_iESPA_CT = 160;

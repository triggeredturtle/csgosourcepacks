/* Paper-Misc */
#include "Paper.hpp"

CMisc* g_pMisc;

/* AutoHop */
void CMisc::AutoHop() {
	
	if (!Settings::m_bAutoHop || G::Local->GetMoveType() == MOVETYPE_LADDER) return;

	static bool m_bLastJumped = false;
	static bool m_bShouldFake = false;
	if (!m_bLastJumped && m_bShouldFake) {
		m_bShouldFake = false;
		G::Cmd->buttons |= (1 << 1);
	}
	else if (G::Cmd->buttons & (1 << 1)) {
		if (G::Local->GetFlags() & (1 << 0)) {
			m_bLastJumped = true;
			m_bShouldFake = true;
		}
		else {
			G::Cmd->buttons &= ~(1 << 1);
			m_bLastJumped = false;
		}
	}
	else {
		m_bLastJumped = false;
		m_bShouldFake = false;
	}

}

/* AutoStrafe */
void CMisc::AutoStrafe() {
	if (!Settings::m_bAutoStrafe || G::Local->GetMoveType() == MOVETYPE_LADDER || G::Local->GetMoveType() == MOVETYPE_OBSERVER || G::Local->GetMoveType() == MOVETYPE_NOCLIP || G::Local->GetMoveType() == MOVETYPE_FLY) return;

	if (GetAsyncKeyState(VK_SPACE) & 0x8000 && GetActiveWindow() == FindWindowA("Valve001", NULL)) {
		if (!(G::Local->GetFlags() & (1 << 0))) {
			if (G::Cmd->mousedx > 1 || G::Cmd->mousedx < -1) {
				G::Cmd->sidemove = G::Cmd->mousedx < 0.f ? -400.f : 400.f;
			}
			else {
				G::Cmd->forwardmove = 5850.f / G::Local->GetVelocity().Length2d();
				G::Cmd->sidemove = (G::Cmd->command_number % 2) == 0 ? -400.f : 400.f;
			}
		}
	}

}

/* AirStuck */
void CMisc::AirStuck() {
	if (!Settings::m_bAirStuck || G::Cmd->buttons & IN_ATTACK || G::Cmd->buttons & IN_RELOAD) return;
	if (GetAsyncKeyState(VK_MENU) & 0x8000 && GetActiveWindow() == FindWindowA("Valve001", NULL)) {
		G::Cmd->tick_count = INT_MAX;
	}
}

/* ClanTag Changer */
void SetClanTag(const char* tag, const char* name) {
	static auto pSetClanTag = reinterpret_cast<void(__fastcall*)(const char*, const char*)>(Pattern::FindPattern("engine.dll", "53 56 57 8B DA 8B F9 FF 15"));

	pSetClanTag(tag, name);
}

/* Tag */
void CMisc::Tag() {

	if (!Settings::m_bClanTag) return;

	int m_iRand = rand() % 4 + 1;

	if (Settings::m_iClanTagStyle == 1) {
		SetClanTag("STAINLESS'", "STAINLESS'");
	}
	if (Settings::m_iClanTagStyle == 2) {
		SetClanTag("cool beans club", "cool beans club");
	}
	if (Settings::m_iClanTagStyle == 3) {
		SetClanTag("DAD COP 09'", "DAD COP 09'");
	}
	if (Settings::m_iClanTagStyle == 4) {
		if (m_iRand == 1) {
			SetClanTag("paper", "paper");
		}
		if (m_iRand == 2) {
			SetClanTag(" paper", " paper");
		}
		if (m_iRand == 3) {
			SetClanTag("  paper", "  paper");
		}
		if (m_iRand == 4) {
			SetClanTag("    paper", "    paper");
		}
	}

}
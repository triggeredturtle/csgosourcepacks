/* Paper-Rage */
#pragma once

/* Anti Aim Namespace */
namespace AntiAim {
	/* Pitch */
	void Down();
	void Up();
	void Emotion();
	void FakeEmotion();
	void FakeDown();
	void FakeUp();
	void LispDown();
	void LispUp();
	void UpsideDown();
	/* Yaw */
	void FakeOrigin();
	void Backwards();
	void Jitter();
	void SidewaysJitter();
	void FastSpin();
	void SlowSpin();
	void FakeSideways();
	/* Movement */
	void CorrectLisp();
}

/* CRageBot */
class CRageBot {
public:
	bool IsVisible(Vector& vecAbsStart, Vector& vecAbsEnd, CBaseEntity* Entity);
	void BestPoint(CBaseEntity* Target, Vector& final);
	void FixMove(Vector m_vOldAngles, float m_fOldForward, float m_fOldSidemove);
	void AntiAim();
	void RageBot();
	void VelocityPrediction(int i);
}; extern CRageBot* g_pRageBot;

﻿Public Class KeyBinds
    Public Shared TriggerKey = 164
    Public Shared SkinchangerKey = 165
    Public Shared RankScannerKey = 46
End Class

#pragma once


#include "main.h"


#ifndef CLIENT_DLL
#define CLIENT_DLL
#endif

// Public
#include "SDK\\wchartypes.h"
#include "SDK\\cdll_int.h"
#include "SDK\\iprediction.h"
#include "SDK\\bone_setup.h"
#include "SDK\\icliententitylist.h"
#include "SDK\\ienginevgui.h"
#include "SDK\\IGameUIFuncs.h"
#include "SDK\\igameevents.h"
#include "SDK\\view_shared.h"
#include "SDK\\inetchannelinfo.h"
#include "SDK\\iachievementmgr.h"
#include "SDK\\steam_api.h"
#include "SDK\\isteamuserstats.h"
#include "SDK\\model_types.h"
#include "SDK\\iinputstacksystem.h"
// Client
#include "SDK\\cbase.h"
#include "SDK\\imessagechars.h"
#include "SDK\\iclientmode.h"
#include "SDK\\cliententitylist.h"
#include "SDK\\cdll_client_int.h"
#include "SDK\\c_baseanimating.h"
#include "SDK\\c_basecombatweapon.h"
#include "SDK\\c_baseplayer.h"
#include "SDK\\enginesprite.h"
#include "SDK\\input.h"
#include "SDK\\c_playerresource.h"
#include "SDK\\iviewrender.h"
#include "SDK\\viewrender.h"
#include "SDK\\commandmenu.h"
#include "SDK\\hudelement.h"
#include "SDK\\gamemovement.h"
#include "SDK\\clientmode_shared.h"
#include "SDK\\glow_outline_effect.h"

// Engine
#include "SDK\\client.h"
#include "SDK\\ivmodelrender.h"
#include "SDK\\ivdebugoverlay.h"
#include "SDK\\ivmodelinfo.h"
#include "SDK\\IEngineTrace.h"
#include "SDK\\IEngineSound.h"

// Material System
#include "SDK\\imaterialsystemstub.h"
#include "SDK\\itexture.h"
#include "SDK\\imaterialvar.h"
#include "SDK\\checksum_md5.h"

// VGUI
#include "SDK\\matsyscontrols.h"
#include "SDK\\IClientPanel.h"
#include "SDK\\IPanel.h"
#include "SDK\\ISurface.h"
#include "SDK\\ILocalize.h"
#include "SDK\\collisionutils.h"
#include "SDK\\random.h"

// Server
#include "SDK\\playerinfomanager.h"

// VGUI Controls
#include "SDK\\Panel.h"

// VGUI Material Surface
#include "SDK\\IMatSystemSurface.h"
#include "SDK\\vector.h"

// Shared
#include "SDK\\usermessages.h"
#include "SDK\\basecombatweapon_shared.h"
#include "SDK\\takedamageinfo.h"
#include "SDK\\igamemovement.h"
#include "SDK\\in_buttons.h"
#include "SDK\\props_shared.h"
// Utils
#include "SDK\\utlvector.h"

#include "SDK\\bspfile.h"
#include "SDK\\gamebspfile.h"
#pragma comment(lib, "public\\tier0.lib")
#pragma comment(lib, "public\\tier1.lib")
#pragma comment(lib, "public\\tier2.lib")
#pragma comment(lib, "public\\tier3.lib")
#pragma comment(lib, "public\\mathlib.lib")
#pragma comment(lib, "public\\vstdlib.lib")


#pragma optimize("gsy",on)
#pragma warning( disable : 4244 )



enum WeaponId
{
	WEAPON_NULL = 0,
	WEAPON_DEAGLE = 1,
	WEAPON_ELITE = 2,
	WEAPON_FIVESEVEN = 3,
	WEAPON_GLOCK = 4,
	WEAPON_P228 = 5,
	WEAPON_USP = 6,
	WEAPON_AK47 = 7,
	WEAPON_AUG = 8,
	WEAPON_AWP = 9,
	WEAPON_FAMAS = 10,
	WEAPON_G3SG1 = 11,
	WEAPON_GALIL = 12,
	WEAPON_GALILAR = 13,
	WEAPON_M249 = 14,
	WEAPON_M3 = 15,
	WEAPON_M4A1 = 16,
	WEAPON_MAC10 = 17,
	WEAPON_MP5NAVY = 18,
	WEAPON_P90 = 19,
	WEAPON_SCOUT = 20,
	WEAPON_SG550 = 21,
	WEAPON_SG552 = 22,
	WEAPON_TMP = 23,
	WEAPON_UMP45 = 24,
	WEAPON_XM1014 = 25,
	WEAPON_BIZON = 26,
	WEAPON_MAG7 = 27,
	WEAPON_NEGEV = 28,
	WEAPON_SAWEDOFF = 29,
	WEAPON_TEC9 = 30,
	WEAPON_TASER = 31,
	WEAPON_HKP2000 = 32,
	WEAPON_MP7 = 33,
	WEAPON_MP9 = 34,
	WEAPON_NOVA = 35,
	WEAPON_P250 = 36,
	WEAPON_SCAR17 = 37,
	WEAPON_SCAR20 = 38,
	WEAPON_SG556 = 39,
	WEAPON_SSG08 = 40,
	WEAPON_KNIFE_GG = 41,
	WEAPON_KNIFE_T = 42,
	WEAPON_FLASHBANG = 43,
	WEAPON_HE_GRENADE = 44,
	WEAPON_SMOKE_GRENADE = 45,
	WEAPON_MOLOTOV = 46,
	WEAPON_DECOY = 47,
	WEAPON_INC_GRENADE = 48,
	WEAPON_C4 = 49,
	ITEM_KEVLAR = 50,
	ITEM_ASSAULTSUIT = 51,
	ITEM_NVG = 52,
	ITEM_DEFUSER = 53,
	ITEM_CUTTERS = 54,
	WEAPON_KNIFE_CT = 59,
	WEAPON_CZ75 = 63,
	WEAPON_M4A1S = 60,
	WEAPON_USPS = 61,
	WEAPON_R8REVOLVER = 64,
	WEAPON_KNIFE_BAYONET = 500,
	WEAPON_KNIFE_FLIP = 505,
	WEAPON_KNIFE_GUT = 506,
	WEAPON_KNIFE_KARAMBIT = 507,
	WEAPON_KNIFE_M9BAYONET = 508,
	WEAPON_KNIFE_HUNTSMAN = 509,
	WEAPON_KNIFE_FALCHION = 512,
	WEAPON_KNIFE_BOWIE = 514,
	WEAPON_KNIFE_BUTTERFLY= 515,
	WEAPON_KNIFE_SHADOWDAGGER = 516,
};

class ICustomTraceFilter
{
public:
	virtual bool ShouldHitEntity(PVOID pEntity, int contentsMask) = 0;
	virtual TraceType_t	GetTraceType() const = 0;
};
class CTraceSkipEntity : public ICustomTraceFilter
{
public:
	CTraceSkipEntity(PVOID pEntToSkip = NULL)
	{
		pSkip = pEntToSkip;
	}
	bool ShouldHitEntity(PVOID pEntityHandle, int contentsMask)
	{
		return !(pEntityHandle == pSkip);
	}
	virtual TraceType_t GetTraceType() const
	{
		return TRACE_EVERYTHING;
	}
	void* pSkip;
};

/*enum EFontFlags
{
	FONTFLAG_NONE,
	FONTFLAG_ITALIC			= 0x001,
	FONTFLAG_UNDERLINE		= 0x002,
	FONTFLAG_STRIKEOUT		= 0x004,
	FONTFLAG_SYMBOL			= 0x008,
	FONTFLAG_ANTIALIAS		= 0x010,
	FONTFLAG_GAUSSIANBLUR	= 0x020,
	FONTFLAG_ROTARY			= 0x040,
	FONTFLAG_DROPSHADOW		= 0x080,
	FONTFLAG_ADDITIVE		= 0x100,
	FONTFLAG_OUTLINE		= 0x200,
	FONTFLAG_CUSTOM			= 0x400,		// custom generated font - never fall back to asian compatibility mode
	FONTFLAG_BITMAP			= 0x800,		// compiled bitmap font - no fallbacks
};
*/

template <typename T>
__forceinline T Member( void *base, DWORD offset = 0 )
{
	return (T)( (DWORD)base + offset );
}


template <typename T>
__forceinline T Member( DWORD base, DWORD offset = 0 )
{
	return (T)( base + offset );
}


typedef void ( __thiscall *void_t )( void *thisptr );
typedef int ( __thiscall *GetInt_t )( void *thisptr );
typedef float ( __thiscall *GetFloat_t )( void *thisptr );


#define TIME2TICKS( time ) ( (int)( .5f + ( (float)time / Globals()->interval_per_tick ) ) )
#ifndef CONCAT_IMPL
#define CONCAT_IMPL(x, y) x##y
#ifndef MACRO_CONCAT
#define MACRO_CONCAT(x, y) CONCAT_IMPL(x, y)
#ifndef PAD
#define PAD(SIZE) BYTE MACRO_CONCAT(_pad, __COUNTER__)[SIZE];
#endif
#endif
#endif
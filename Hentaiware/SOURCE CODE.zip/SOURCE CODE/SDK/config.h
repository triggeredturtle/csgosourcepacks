/* protobuf config.h for SNC compiler on PS3.  On other platforms, this is generated
 * automatically by autoheader / autoconf / configure. */

/* define if you want to use pthreads */
#define HAVE_PTHREAD 1

/* define if you want to use zlib.  See readme.txt for additional
 * requirements. */
// #define HAVE_ZLIB 1

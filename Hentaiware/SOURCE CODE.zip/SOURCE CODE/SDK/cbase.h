//========= Copyright Valve Corporation, All rights reserved. ============//
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================//

#ifndef CBASE_H
#define CBASE_H
#ifdef _WIN32
#pragma once
#endif

struct studiohdr_t;

#include <stdio.h>
#include <stdlib.h>

#include <SDK//platform.h>
#include <SDK//dbg.h>

#include <SDK//strtools.h>
#include <SDK//random.h>
#include <SDK//utlvector.h>

#include <SDK//const.h>

#include "SDK//string_t.h"

// These two have to be included very early
#include <SDK//predictableid.h>
#include <SDK//predictable_entity.h>

#include "SDK//cdll_util.h"
#include <SDK//util_shared.h>

#include <SDK//icvar.h>
#include <SDK//baseentity_shared.h>


// This is a precompiled header.  Include a bunch of common stuff.
// This is kind of ugly in that it adds a bunch of dependency where it isn't needed.
// But on balance, the compile time is much lower (even incrementally) once the precompiled
// headers contain these headers.
#include "SDK//precache_register.h"
#include "SDK//c_basecombatweapon.h"
#include "SDK//c_basecombatcharacter.h"
#include "SDK//gamerules.h"
#include "SDK//c_baseplayer.h"
#include "SDK//itempents.h"
#include "SDK//vphysics_interface.h"
#include "SDK//physics.h"
#include "SDK//c_recipientfilter.h"
#include "SDK//cdll_client_int.h"
#include "SDK//worldsize.h"
#include "SDK//ivmodelinfo.h"

#endif // CBASE_H

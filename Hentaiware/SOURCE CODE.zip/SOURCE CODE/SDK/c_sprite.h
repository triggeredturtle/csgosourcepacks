//========= Copyright Valve Corporation, All rights reserved. ============//
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================//
#if !defined( C_SPRITE_H )
#define C_SPRITE_H
#ifdef _WIN32
#pragma once
#endif

#include "Sprite.h"
#include "c_pixel_visibility.h"

#endif // C_SPRITE_H

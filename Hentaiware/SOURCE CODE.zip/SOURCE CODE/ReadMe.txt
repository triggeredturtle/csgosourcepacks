========================================================================
    DYNAMIC LINK LIBRARY : LayZ_Pz_GO Project Overview
========================================================================

This Project contains the whole source code for LayZ_Pz Hack, intended for CS:GO.

It contains code, snippets made by different persons.

The Interface, Netvars, and Weapon/Entity classes are Kiro's, aswell as Math, Module and Memory one.

The base is therefore furnished by Kiro, with somewhat heavy modifications.

The whole project has been ported by Benny, aswell as the brand new SDK for GO.

The rest of the code is made by my own beside few snippets made by Kamay, Benny, Sam and NanoCat

Therefore the credits should be given to Kiro, Sam, Kamay, Benny and NanoCat. 
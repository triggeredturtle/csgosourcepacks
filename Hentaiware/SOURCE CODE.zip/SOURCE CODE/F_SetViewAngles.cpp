#include "main.h"

void __fastcall C_Interface::SetViewAngles(void *thisptr, int edx, QAngle& angle)
{

}

#pragma once

#include "Vector.h"

namespace SSDK {
	typedef Vector QAngle;
}
#pragma once

namespace SSDK {
	class IViewRender {

	};
}
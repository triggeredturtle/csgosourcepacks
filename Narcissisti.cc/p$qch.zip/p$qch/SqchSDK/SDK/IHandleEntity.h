#pragma once

namespace SSDK {
	class IHandleEntity;
}
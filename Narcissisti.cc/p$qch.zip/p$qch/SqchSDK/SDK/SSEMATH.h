#pragma once

namespace SSDK {

}
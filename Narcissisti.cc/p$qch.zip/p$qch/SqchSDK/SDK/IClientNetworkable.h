#pragma once

namespace SSDK {
	class ClientClass;

	class IClientNetworkable {

	};
}
#pragma once

namespace SSDK {
	typedef unsigned short MDLHandle_t;

	class IMDLCache;
}
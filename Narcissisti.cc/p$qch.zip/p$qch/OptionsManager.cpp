#include "OptionsManager.h"

COptions OptionsManager;
#include "Checksum.h"

CCRC gCRC;
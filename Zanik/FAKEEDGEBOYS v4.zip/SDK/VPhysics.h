#pragma once

struct surfacephysicsparams_t
{
	float			friction;
	float			elasticity;
	float			density;
	float			thickness;
	float			dampening;
};

struct surfaceaudioparams_t
{
	float			reflectivity;
	float			hardnessFactor;
	float			roughnessFactor;
	float			roughThreshold;
	float			hardThreshold;
	float			hardVelocityThreshold;
};

struct surfacesoundnames_t
{
	unsigned short	walkStepLeft;
	unsigned short	walkStepRight;
	unsigned short	runStepLeft;
	unsigned short	runStepRight;
	unsigned short	impactSoft;
	unsigned short	impactHard;
	unsigned short	scrapeSmooth;
	unsigned short	scrapeRough;
	unsigned short	bulletImpact;
	unsigned short	rolling;
	unsigned short	breakSound;
	unsigned short	strainSound;
};

struct surfacesoundhandles_t
{
	short	walkStepLeft;
	short	walkStepRight;
	short	runStepLeft;
	short	runStepRight;
	short	impactSoft;
	short	impactHard;
	short	scrapeSmooth;
	short	scrapeRough;
	short	bulletImpact;
	short	rolling;
	short	breakSound;
	short	strainSound;
};

struct surfacegameprops_t
{
public:
	float				maxSpeedFactor;
	float				jumpFactor;
	char				pad00[0x4];
	float				flPenetrationModifier;
	float				flDamageModifier;
	unsigned short		material;
	char				pad01[0x3];
};

struct surfacedata_t
{
	surfacephysicsparams_t	physics;
	surfaceaudioparams_t	audio;
	surfacesoundnames_t		sounds;
	surfacegameprops_t		game;
	surfacesoundhandles_t	soundhandles;
};

class IPhysicsSurfaceProps
{
public:
	virtual void Func0();
	virtual void Func1();
	virtual void Func2();
	virtual void Func3();
	virtual void Func4();
	virtual surfacedata_t *GetSurfaceData(int surfaceDataIndex);
};
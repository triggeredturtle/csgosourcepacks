typedef float matrix3x4[3][4];

// Credits to Casual_Hacker 


class ICollideable {
public:
	virtual void Func0();
	virtual const Vector& OBBMins() const;
	virtual const Vector& OBBMaxs() const;
};

class C_BaseEntity {
public:

	Vector GetAbsOrigin() {
		return *reinterpret_cast<Vector*>((DWORD)this + (DWORD)0x134); // Has not been changed for a while.
	}

	Vector GetAbsAngles() {
		typedef Vector(__thiscall* getxAngle)(PVOID);
		return ReadFunc<getxAngle>(this, 11)(this);
	}

	Vector GetEyePos() {
		return GetAbsOrigin() + *reinterpret_cast<Vector*>((DWORD)this + (DWORD)0x104);
	}

	Vector GetVelocity() {
		return *reinterpret_cast<Vector*>((DWORD)this + (DWORD)0x110);
	}

	int Health() {
		return *reinterpret_cast<int*>((DWORD)this + (DWORD)offsets->m_iHealth); // Same here.
	}

	int Team() {
		return *reinterpret_cast<int*>((DWORD)this + (DWORD)offsets->m_iTeamNum); // and here...
	}

	bool Dormant() {
		return *reinterpret_cast<bool*>((DWORD)this + (DWORD)0xE9); // sigh.... and here.
	}

	model_t* GetModel()
	{
		return *(model_t**)((DWORD)this + 0x6C);
	}


	int GetIndex()
	{
		PVOID pNetworkable = (PVOID)(this + 0x8);
		typedef int(__thiscall* OriginalFn)(PVOID);
		return ReadFunc<OriginalFn>(pNetworkable, 10)(pNetworkable);
	}


	ICollideable* GetCollideable()
	{
		int m_Collision = netvars->getOffset("DT_BaseEntity", "m_Collision");
		return (ICollideable*)((DWORD)this + m_Collision);
	}

	int	entindex(void) {
		typedef int(__thiscall* OriginalFn)(PVOID);
		return ReadFunc<OriginalFn>(this, 16)(this);
	}

	bool SetupBones(matrix3x4 *pBoneToWorldOut, int nMaxBones, int boneMask, float currentTime)
	{
		__asm
		{
			mov edi, this
			lea ecx, dword ptr ds : [edi + 0x4]
			mov edx, dword ptr ds : [ecx]
			push currentTime
			push boneMask
			push nMaxBones
			push pBoneToWorldOut
			call dword ptr ds : [edx + 0x34]
		}
	}

	void setPos(Vector& vPos1, Vector& vPos2) {
		typedef void(__thiscall* OriginalFn)(PVOID, Vector&, Vector&);
		return ReadFunc<OriginalFn>(this, 109)(this, vPos1, vPos2);
	}

	int Flags() {
		return *reinterpret_cast<int*>((DWORD)this + (DWORD)offsets->m_fFlags); // And this one.
	}

	int GlowIndex() {
		int getIndex = netvars->getOffset("DT_CSPlayer", "m_flFlashMaxAlpha") + 0x18;
		return *reinterpret_cast<int*>((DWORD)this + (DWORD)0xA310);
	}

	bool HasDefuser() {
		return *reinterpret_cast<bool*>((DWORD)this + (DWORD)0x17B8);
	}

	bool IsDefusing() {
		return *reinterpret_cast<bool*>((DWORD)this + (DWORD)0x3894);
	}

	bool IsImmune() {
		int getImmunity = netvars->getOffset("DT_CSPlayer", "m_bGunGameImmunity");
		return *reinterpret_cast<bool*>((DWORD)this + (DWORD)getImmunity);
	}

	bool IsWalking() {
		return *reinterpret_cast<bool*>((DWORD)this + (DWORD)offsets->MoveMent);
	}

	bool IsScoped() {
		return *reinterpret_cast<bool*>((DWORD)this + (DWORD)offsets->isScoped);
	}

	bool HasHelmet() {
		return *reinterpret_cast<bool*>((DWORD)this + (DWORD)offsets->m_bHasHelmet);
	}

	DWORD BoneMatrix() {
		int pBoner = offsets->ForceBone + 0x1C;
		return *reinterpret_cast<DWORD*>((DWORD)this + (DWORD)pBoner);
	}

	Vector GetPunch() {
		int getPunch = offsets->m_Local + 0x70;
		return *reinterpret_cast<Vector*>((DWORD)this + (DWORD)getPunch);
	}

	Vector GetVisualPunch() {
		int getPunch = offsets->m_Local + 0x64;
		return *reinterpret_cast<Vector*>((DWORD)this + (DWORD)getPunch);
	}

	int ArmorValue() {
		return *reinterpret_cast<int*>((DWORD)this + (DWORD)offsets->m_ArmorValue);
	}

	int hittime() {
		return *reinterpret_cast<int*>((DWORD)this + (DWORD)0xA2C8);
	}

	ULONG GetWeapon() {
		static int offset = netvars->getOffset("DT_BaseCombatCharacter", "m_hActiveWeapon");
		return *reinterpret_cast<ULONG*>((DWORD)this + (DWORD)offset);
	}

	float TickBase() {
		static int offset = netvars->getOffset("DT_BasePlayer", "m_nTickBase");
		return (float)*(int*)((DWORD)this + offset);
	}

	char GetLifeState() {
		return *reinterpret_cast<char*>((DWORD)this + (DWORD)offsets->m_lifeState);
	}

	bool IsValid() {
		return (GetLifeState() == 0 && !this->Dormant() && this->Health() > 0);
	}

	int ObserverTarget() {
		int offsetx = netvars->getOffset("DT_BasePlayer", "m_hObserverTarget");
		return *reinterpret_cast<int*>((DWORD)this + (DWORD)offsetx);
	}

	CUserCmd* m_pCurrentCommand() {
		int offsersetter = netvars->getOffset("DT_BasePlayer", "m_nButtons") + 0x4;
		return *reinterpret_cast<CUserCmd**>((DWORD)this + (DWORD)0x3328);
	}

	int MoveType() {
		return *reinterpret_cast<int*>((DWORD)this + (DWORD)offsets->m_movetype);
	}

	C_BaseCombatWeapon* Active();

};


class xKeyValues;
class CSWeaponInfo {
public:
	virtual void Function0(); //
	virtual void Function1(); //
	virtual void Parse(xKeyValues *pKeyValuesData, const char *szWeaponName); //
	virtual void RefreshDynamicParameters(void); //
	virtual void Function4(); //
	virtual void Function5(); //
	virtual void Function6(); //
	virtual void Function7(); //
	virtual void Function8(); //

	char pad_0x0004[0x2]; //0x0004
	char m_pszName[32]; //0x0006 
	char pad_0x0026[0x7E]; //0x0026
	__int16 N0000002E; //0x00A4 
	char m_pszModelName[32]; //0x00A6 
	char pad_0x00C6[0x6DE]; //0x00C6
	BYTE m_IsFullAuto; //0x07A4 
	char pad_0x07A5[0x7]; //0x07A5
	__int32 m_iPrice; //0x07AC 
	float m_flArmorRatio; //0x07B0 
	char pad_0x07B4[0x10]; //0x07B4
	float m_flPenetration; //0x07C4 
	__int32 m_iDamage; //0x07C8 
	float m_flRange; //0x07CC 
	float m_flRangeModifier; //0x07D0 
	char pad_0x07D4[0x4]; //0x07D4
	float m_flCycleTime; //0x07D8 
};

class CUserCmd;
class CPrediction {
public:
	bool InPrediction() {
		typedef bool(__thiscall* oInPrediction)(void*);
		return ReadFunc< oInPrediction >(this, 14)(this);
	}
	void SetupMove(C_BaseEntity *player, CUserCmd *ucmd, PVOID empty, PVOID moveData) {
		typedef void(__thiscall* OriginalFn)(PVOID, C_BaseEntity *player, CUserCmd *ucmd, PVOID empty, PVOID moveData);
		ReadFunc<OriginalFn>(this, 20)(this, player, ucmd, NULL, moveData);
	}
	void FinishMove(C_BaseEntity *player, CUserCmd *ucmd, PVOID moveData) {
		typedef void(__thiscall* OriginalFn)(PVOID, C_BaseEntity *player, CUserCmd *ucmd, PVOID moveData);
		ReadFunc<OriginalFn>(this, 21)(this, player, ucmd, moveData);
	}
};

class ImoveHelper {
public:
	void SetHost(C_BaseEntity *pPlayer) {
		typedef void(__thiscall* OriginalFn)(PVOID, C_BaseEntity *pPlayer);
		ReadFunc<OriginalFn>(this, 1)(this, pPlayer);
	}
};

class CGameMovement {
public:
	void ProcessMovement(C_BaseEntity *pPlayer, PVOID moveData)
	{
		typedef void(__thiscall* OriginalFn)(PVOID, C_BaseEntity *pPlayer, PVOID moveData);
		ReadFunc<OriginalFn>(this, 1)(this, pPlayer, moveData);
	}
};


#include "main.h"
#include "drawings.h"
#include "SDK\\GetInterface.h"
#include "md5split.h"
#include "selfscan.h"

#define M_PI		3.14159265358979323846
#define M_RADPI 57.295779513082
#define PI 3.14159265358979323846f
#define M_PI_F		((float)(M_PI))
#define DEG2RAD( x  )  ( (float)(x) * (float)(M_PI_F / 180.f) )
#define RAD2DEG( x ) ( ( float )( x ) * ( float )( 180.0f / ( float )( PI ) ) )

using InitKeyValuesFn = void(__thiscall*)(void* thisptr, const char* name);
using LoadFromBufferFn = void(__thiscall*)(void* thisptr, const char* resourceName, const char* pBuffer, void* pFileSystem, const char* pPathID, void* pfnEvaluateSymbolProc);

InitKeyValuesFn InitKeyValuesEx;
LoadFromBufferFn LoadFromBufferEx;


Source* vlv = new Source();
CNetworkedVariableManager* netvars = new CNetworkedVariableManager();
Vector vAngles;
class BoxStruct {
public:
	int x, y, w, h;
};

bool WorldToScreen(Vector& vFrom, Vector& vTo) {
	return (vlv->pOverlay->ScreenPosition(vFrom, vTo) != 1);
}


bool DrawPlayerBox(C_BaseEntity* pEntity, BoxStruct& structer) {
	Vector vOrigin = pEntity->GetAbsOrigin();
	Vector min = pEntity->GetCollideable()->OBBMins() + vOrigin;
	Vector max = pEntity->GetCollideable()->OBBMaxs() + vOrigin;

	Vector points[] = { Vector(min.x, min.y, min.z),
		Vector(min.x, max.y, min.z),
		Vector(max.x, max.y, min.z),
		Vector(max.x, min.y, min.z),
		Vector(max.x, max.y, max.z),
		Vector(min.x, max.y, max.z),
		Vector(min.x, min.y, max.z),
		Vector(max.x, min.y, max.z) };

	Vector pos = pEntity->GetAbsOrigin();
	Vector flb;
	Vector brt;
	Vector blb;
	Vector frt;
	Vector frb;
	Vector brb;
	Vector blt;
	Vector flt;


	if (!WorldToScreen(points[3], flb) || !WorldToScreen(points[5], brt)
		|| !WorldToScreen(points[0], blb) || !WorldToScreen(points[4], frt)
		|| !WorldToScreen(points[2], frb) || !WorldToScreen(points[1], brb)
		|| !WorldToScreen(points[6], blt) || !WorldToScreen(points[7], flt))
		return false;

	Vector arr[] = { flb, brt, blb, frt, frb, brb, blt, flt };

	float left = flb.x;        // left
	float top = flb.y;        // top
	float right = flb.x;    // right
	float bottom = flb.y;    // bottom

	for (int i = 1; i < 8; i++)
	{
		if (left > arr[i].x)
			left = arr[i].x;
		if (bottom < arr[i].y)
			bottom = arr[i].y;
		if (right < arr[i].x)
			right = arr[i].x;
		if (top > arr[i].y)
			top = arr[i].y;
	}

	structer.x = left;
	structer.y = top;
	structer.w = right - left;
	structer.h = bottom - top;

	return true;
}

extern void InitKeyValues(KeyValues* pKeyValues, const char* name);
void InitKeyValues(KeyValues* pKeyValues, const char* name) {
	InitKeyValuesEx = (InitKeyValuesFn)(offsets->InitKeyValuesEx);
	InitKeyValuesEx(pKeyValues, name);
}

extern void LoadFromBuffer(KeyValues* pKeyValues, const char* resourceName, const char* pBuffer, void* pFileSystem = nullptr, const char* pPathID = NULL, void* pfnEvaluateSymbolProc = nullptr);
void LoadFromBuffer(KeyValues* pKeyValues, const char* resourceName, const char* pBuffer, void* pFileSystem, const char* pPathID, void* pfnEvaluateSymbolProc) {
	LoadFromBufferEx = (LoadFromBufferFn)(offsets->LoadFromBufferEx);
	LoadFromBufferEx(pKeyValues, resourceName, pBuffer, pFileSystem, pPathID, pfnEvaluateSymbolProc);
}



/* Credits: Kiro */

#define MAT( _TYPE_ ) "\"" + _TYPE_ + "\"\n{\n\t\"$basetexture\" \"VGUI/white_additive\"\n\t\"$ignorez\" \"1\"\n\t\"$nofog\" \"1\"\n\t\"$halflambert\" \"1\"\n}"
#define MAT_IGNOREZ( _TYPE_ ) "\"" + _TYPE_ + "\"\n{\n\t\"$basetexture\" \"VGUI/white_additive\"\n\t\"$ignorez\" \"0\"\n\t\"$nofog\" \"1\"\n\t\"$halflambert\" \"1\"\n}"

IMaterial* CreateMaterial(bool shouldIgnoreZ)
{
	static int created = 0;

	//this is a pointer to the cvar I use for controlling lighting on the materials,
	//I registered it in the source engines linked list of ConVars,
	//and it's changable through the games console
	std::string type = "VertexLitGeneric";

	//materialBuffer holds the vmt "script" or what to call it
	char materialBuffer[2048];
	if (shouldIgnoreZ)
	{
		std::string tmp(MAT(type));
		sprintf(materialBuffer, tmp.c_str());
	}
	else
	{
		std::string tmp(MAT_IGNOREZ(type));
		sprintf(materialBuffer, tmp.c_str());
	}

	//make a unique name for our material
	char materialName[512];
	sprintf(materialName, "febs_material_%i.vmt", created);
	++created;

	//construct keyvalues based on the material type
	KeyValues* pKeyValues = new KeyValues(materialName);

	//load vmt "script" into our instance of keyvalues
	InitKeyValues(pKeyValues, type.c_str());
	LoadFromBuffer(pKeyValues, materialName, materialBuffer);

	//create the actual material
	IMaterial* createdMaterial = vlv->pMatSystem->CreateMaterial(materialName, pKeyValues);
	createdMaterial->IncrementReferenceCount();

	return createdMaterial;
}

void SinCos(float a, float* s, float*c) {
	*s = sin(a);
	*c = cos(a);
}

void AngleNormalize(Vector &vIn, Vector &vOut) {
	float flLen = vIn.Length();
	if (flLen == 0) {
		vOut.Init(0, 0, 1);
		return;
	}
	flLen = 1 / flLen;
	vOut.Init(vIn.x * flLen, vIn.y * flLen, vIn.z * flLen);
}

void AngleVectors(const Vector &angles, Vector *forward, Vector *right, Vector *up) {
	float sr, sp, sy, cr, cp, cy;

	SinCos(DEG2RAD(angles[1]), &sy, &cy);
	SinCos(DEG2RAD(angles[0]), &sp, &cp);
	SinCos(DEG2RAD(angles[2]), &sr, &cr);

	if (forward) {
		forward->x = cp*cy;
		forward->y = cp*sy;
		forward->z = -sp;
	}

	if (right) {
		right->x = (-1 * sr*sp*cy + -1 * cr*-sy);
		right->y = (-1 * sr*sp*sy + -1 * cr*cy);
		right->z = -1 * sr*cp;
	}

	if (up) {
		up->x = (cr*sp*cy + -sr*-sy);
		up->y = (cr*sp*sy + -sr*cy);
		up->z = cr*cp;
	}
}

void SpreadVectorAngles(const Vector &vecForward, Vector &vecAngles)
{
	Vector vecView;
	if (vecForward[1] == 0.f && vecForward[0] == 0.f)
	{
		vecView[0] = 0.f;
		vecView[1] = 0.f;
	}
	else
	{
		vecView[1] = atan2(vecForward[1], vecForward[0]) * 180.f / M_PI;

		if (vecView[1] < 0.f)
			vecView[1] += 360.f;

		vecView[2] = sqrt(vecForward[0] * vecForward[0] + vecForward[1] * vecForward[1]);

		vecView[0] = atan2(vecForward[2], vecView[2]) * 180.f / M_PI;
	}

	vecAngles[0] = -vecView[0];
	vecAngles[1] = vecView[1];
	vecAngles[2] = 0.f;
}

void AngleToVectors(const Vector &angles, Vector *forward, Vector *right, Vector *up)
{
	float angle;
	static float sr, sp, sy, cr, cp, cy, cpi = (M_PI * 2 / 360);

	angle = angles.y * cpi;
	sy = sin(angle);
	cy = cos(angle);
	angle = angles.x * cpi;
	sp = sin(angle);
	cp = cos(angle);
	angle = angles.z * cpi;
	sr = sin(angle);
	cr = cos(angle);

	if (forward)
	{
		forward->x = cp*cy;
		forward->y = cp*sy;
		forward->z = -sp;
	}

	if (right)
	{
		right->x = (-1 * sr*sp*cy + -1 * cr*-sy);
		right->y = (-1 * sr*sp*sy + -1 * cr*cy);
		right->z = -1 * sr*cp;
	}

	if (up)
	{
		up->x = (cr*sp*cy + -sr*-sy);
		up->y = (cr*sp*sy + -sr*cy);
		up->z = cr*cp;
	}
}

void AngleVectors(const Vector &angles, Vector *forward) {
	float    sp, sy, cp, cy;

	sy = sin(DEG2RAD(angles[1]));
	cy = cos(DEG2RAD(angles[1]));
	sp = sin(DEG2RAD(angles[0]));
	cp = cos(DEG2RAD(angles[0]));


	forward->x = cp*cy;
	forward->y = cp*sy;
	forward->z = -sp;
}


bool IsVisible(C_BaseEntity* pLoc, C_BaseEntity* pEnt) {
	trace_t tr;
	Ray_t ray;
	CTraceFilter filter;
	filter.pSkip = pLoc;

	ray.Init(pLoc->GetEyePos(), pEnt->GetEyePos());
	vlv->pEngineTrace->TraceRay(ray, 0x46004003, &filter, &tr);

	return (tr.m_pEnt == pEnt || tr.fraction > 0.99f);
}

/* Md5 Stuff */
/*
==================
MD5Init

Start MD5 accumulation.  Set bit count to 0 and buffer to mysterious initialization constants.
==================
*/
void MD5Init(MD5Context_t *ctx)
{
	ctx->buf[0] = 0x67452301;
	ctx->buf[1] = 0xefcdab89;
	ctx->buf[2] = 0x98badcfe;
	ctx->buf[3] = 0x10325476;

	ctx->bits[0] = 0;
	ctx->bits[1] = 0;
}

/*
===================
MD5Update

Update context to reflect the concatenation of another buffer full of bytes.
===================
*/
void MD5Update(MD5Context_t *ctx, unsigned char const *buf, unsigned int len)
{
	unsigned int t;

	/* Update bitcount */

	t = ctx->bits[0];
	if ((ctx->bits[0] = t + ((unsigned int)len << 3)) < t)
		ctx->bits[1]++;         /* Carry from low to high */
	ctx->bits[1] += len >> 29;

	t = (t >> 3) & 0x3f;        /* Bytes already in shsInfo->data */

								/* Handle any leading odd-sized chunks */

	if (t)
	{
		unsigned char *p = (unsigned char *)ctx->in + t;

		t = 64 - t;
		if (len < t)
		{
			memcpy(p, buf, len);
			return;
		}
		memcpy(p, buf, t);
		//byteReverse(ctx->in, 16);
		MD5Transform(ctx->buf, (unsigned int *)ctx->in);
		buf += t;
		len -= t;
	}
	/* Process data in 64-byte chunks */

	while (len >= 64)
	{
		memcpy(ctx->in, buf, 64);
		//byteReverse(ctx->in, 16);
		MD5Transform(ctx->buf, (unsigned int *)ctx->in);
		buf += 64;
		len -= 64;
	}

	/* Handle any remaining bytes of data. */
	memcpy(ctx->in, buf, len);
}

/*
===============
MD5Final


Final wrapup - pad to 64-byte boundary with the bit pattern
1 0* (64-bit count of bits processed, MSB-first)
===============
*/
void MD5Final(unsigned char digest[16], MD5Context_t *ctx)
{
	unsigned count;
	unsigned char *p;

	/* Compute number of bytes mod 64 */
	count = (ctx->bits[0] >> 3) & 0x3F;

	/* Set the first char of padding to 0x80.  This is safe since there is
	always at least one byte free */
	p = ctx->in + count;
	*p++ = 0x80;

	/* Bytes of padding needed to make 64 bytes */
	count = 64 - 1 - count;

	/* Pad out to 56 mod 64 */
	if (count < 8)
	{
		/* Two lots of padding:  Pad the first block to 64 bytes */
		memset(p, 0, count);
		//byteReverse(ctx->in, 16);
		MD5Transform(ctx->buf, (unsigned int *)ctx->in);

		/* Now fill the next block with 56 bytes */
		memset(ctx->in, 0, 56);
	}
	else {
		/* Pad block to 56 bytes */
		memset(p, 0, count - 8);
	}
	//byteReverse(ctx->in, 14);

	/* Append length in bits and transform */
	((unsigned int *)ctx->in)[14] = ctx->bits[0];
	((unsigned int *)ctx->in)[15] = ctx->bits[1];

	MD5Transform(ctx->buf, (unsigned int *)ctx->in);
	//byteReverse((unsigned char *) ctx->buf, 4);
	memcpy(digest, ctx->buf, 16);
	memset(ctx, 0, sizeof(ctx));        /* In case it's sensitive */
}

/* The four core functions - F1 is optimized somewhat */
/* #define F1(x, y, z) (x & y | ~x & z) */
#define F1(x, y, z) (z ^ (x & (y ^ z)))
#define F2(x, y, z) F1(z, x, y)
#define F3(x, y, z) (x ^ y ^ z)
#define F4(x, y, z) (y ^ (x | ~z))

/* This is the central step in the MD5 algorithm. */
#define MD5STEP(f, w, x, y, z, data, s) \
        ( w += f(x, y, z) + data,  w = w<<s | w>>(32-s),  w += x )

/*
=================
MD5Transform

The core of the MD5 algorithm, this alters an existing MD5 hash to
reflect the addition of 16 longwords of new data.  MD5Update blocks
the data and converts bytes into longwords for this routine.
=================
*/
void MD5Transform(unsigned int buf[4], unsigned int const in[16]) {
	register unsigned int a, b, c, d;

	a = buf[0];
	b = buf[1];
	c = buf[2];
	d = buf[3];

	MD5STEP(F1, a, b, c, d, in[0] + 0xd76aa478, 7);
	MD5STEP(F1, d, a, b, c, in[1] + 0xe8c7b756, 12);
	MD5STEP(F1, c, d, a, b, in[2] + 0x242070db, 17);
	MD5STEP(F1, b, c, d, a, in[3] + 0xc1bdceee, 22);
	MD5STEP(F1, a, b, c, d, in[4] + 0xf57c0faf, 7);
	MD5STEP(F1, d, a, b, c, in[5] + 0x4787c62a, 12);
	MD5STEP(F1, c, d, a, b, in[6] + 0xa8304613, 17);
	MD5STEP(F1, b, c, d, a, in[7] + 0xfd469501, 22);
	MD5STEP(F1, a, b, c, d, in[8] + 0x698098d8, 7);
	MD5STEP(F1, d, a, b, c, in[9] + 0x8b44f7af, 12);
	MD5STEP(F1, c, d, a, b, in[10] + 0xffff5bb1, 17);
	MD5STEP(F1, b, c, d, a, in[11] + 0x895cd7be, 22);
	MD5STEP(F1, a, b, c, d, in[12] + 0x6b901122, 7);
	MD5STEP(F1, d, a, b, c, in[13] + 0xfd987193, 12);
	MD5STEP(F1, c, d, a, b, in[14] + 0xa679438e, 17);
	MD5STEP(F1, b, c, d, a, in[15] + 0x49b40821, 22);

	MD5STEP(F2, a, b, c, d, in[1] + 0xf61e2562, 5);
	MD5STEP(F2, d, a, b, c, in[6] + 0xc040b340, 9);
	MD5STEP(F2, c, d, a, b, in[11] + 0x265e5a51, 14);
	MD5STEP(F2, b, c, d, a, in[0] + 0xe9b6c7aa, 20);
	MD5STEP(F2, a, b, c, d, in[5] + 0xd62f105d, 5);
	MD5STEP(F2, d, a, b, c, in[10] + 0x02441453, 9);
	MD5STEP(F2, c, d, a, b, in[15] + 0xd8a1e681, 14);
	MD5STEP(F2, b, c, d, a, in[4] + 0xe7d3fbc8, 20);
	MD5STEP(F2, a, b, c, d, in[9] + 0x21e1cde6, 5);
	MD5STEP(F2, d, a, b, c, in[14] + 0xc33707d6, 9);
	MD5STEP(F2, c, d, a, b, in[3] + 0xf4d50d87, 14);
	MD5STEP(F2, b, c, d, a, in[8] + 0x455a14ed, 20);
	MD5STEP(F2, a, b, c, d, in[13] + 0xa9e3e905, 5);
	MD5STEP(F2, d, a, b, c, in[2] + 0xfcefa3f8, 9);
	MD5STEP(F2, c, d, a, b, in[7] + 0x676f02d9, 14);
	MD5STEP(F2, b, c, d, a, in[12] + 0x8d2a4c8a, 20);

	MD5STEP(F3, a, b, c, d, in[5] + 0xfffa3942, 4);
	MD5STEP(F3, d, a, b, c, in[8] + 0x8771f681, 11);
	MD5STEP(F3, c, d, a, b, in[11] + 0x6d9d6122, 16);
	MD5STEP(F3, b, c, d, a, in[14] + 0xfde5380c, 23);
	MD5STEP(F3, a, b, c, d, in[1] + 0xa4beea44, 4);
	MD5STEP(F3, d, a, b, c, in[4] + 0x4bdecfa9, 11);
	MD5STEP(F3, c, d, a, b, in[7] + 0xf6bb4b60, 16);
	MD5STEP(F3, b, c, d, a, in[10] + 0xbebfbc70, 23);
	MD5STEP(F3, a, b, c, d, in[13] + 0x289b7ec6, 4);
	MD5STEP(F3, d, a, b, c, in[0] + 0xeaa127fa, 11);
	MD5STEP(F3, c, d, a, b, in[3] + 0xd4ef3085, 16);
	MD5STEP(F3, b, c, d, a, in[6] + 0x04881d05, 23);
	MD5STEP(F3, a, b, c, d, in[9] + 0xd9d4d039, 4);
	MD5STEP(F3, d, a, b, c, in[12] + 0xe6db99e5, 11);
	MD5STEP(F3, c, d, a, b, in[15] + 0x1fa27cf8, 16);
	MD5STEP(F3, b, c, d, a, in[2] + 0xc4ac5665, 23);

	MD5STEP(F4, a, b, c, d, in[0] + 0xf4292244, 6);
	MD5STEP(F4, d, a, b, c, in[7] + 0x432aff97, 10);
	MD5STEP(F4, c, d, a, b, in[14] + 0xab9423a7, 15);
	MD5STEP(F4, b, c, d, a, in[5] + 0xfc93a039, 21);
	MD5STEP(F4, a, b, c, d, in[12] + 0x655b59c3, 6);
	MD5STEP(F4, d, a, b, c, in[3] + 0x8f0ccc92, 10);
	MD5STEP(F4, c, d, a, b, in[10] + 0xffeff47d, 15);
	MD5STEP(F4, b, c, d, a, in[1] + 0x85845dd1, 21);
	MD5STEP(F4, a, b, c, d, in[8] + 0x6fa87e4f, 6);
	MD5STEP(F4, d, a, b, c, in[15] + 0xfe2ce6e0, 10);
	MD5STEP(F4, c, d, a, b, in[6] + 0xa3014314, 15);
	MD5STEP(F4, b, c, d, a, in[13] + 0x4e0811a1, 21);
	MD5STEP(F4, a, b, c, d, in[4] + 0xf7537e82, 6);
	MD5STEP(F4, d, a, b, c, in[11] + 0xbd3af235, 10);
	MD5STEP(F4, c, d, a, b, in[2] + 0x2ad7d2bb, 15);
	MD5STEP(F4, b, c, d, a, in[9] + 0xeb86d391, 21);

	buf[0] += a;
	buf[1] += b;
	buf[2] += c;
	buf[3] += d;
}

char *MD5_Print(unsigned char hash[16]) {
	static char szReturn[64];
	unsigned char c;
	char szChunk[10];
	int i;

	memset(szReturn, 0, 64);

	for (i = 0; i < 16; i++) {
		c = (unsigned char)hash[i];
		sprintf(szChunk, "%02x", c);
		strcat(szReturn, szChunk);
	}

	return szReturn;
}
unsigned int MD5_PseudoRandom(unsigned int nSeed) {
	MD5Context_t ctx;
	unsigned char digest[MD5_DIGEST_LENGTH]; // The MD5 Hash

	memset(&ctx, 0, sizeof(ctx));

	MD5Init(&ctx);
	MD5Update(&ctx, (unsigned char*)&nSeed, sizeof(nSeed));
	MD5Final(digest, &ctx);

	return *(unsigned int*)(digest + 6);	// use 4 middle bytes for random value
}
/* End */

float RandomFloat(float min, float max) {
	typedef float(*RandomFloat_t)(float, float);
	static RandomFloat_t m_RandomFloat = (RandomFloat_t)GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomFloat");
	return m_RandomFloat(min, max);
}

void RandomSeed(UINT seed) {
	typedef void(*RandomSeed_t)(UINT);
	static RandomSeed_t m_RandomSeed = (RandomSeed_t)GetProcAddress(GetModuleHandle("vstdlib.dll"), "RandomSeed");
	m_RandomSeed(seed);
	return;
}

float GetInaccuracy(C_BaseCombatWeapon *pWeapon) {
	DWORD dwInaccuracyVMT = (*reinterpret_cast< PDWORD_PTR* >(pWeapon))[484]; //459
	return ((float(__thiscall*)(C_BaseCombatWeapon*)) dwInaccuracyVMT)(pWeapon);
}

float GetSpread(C_BaseCombatWeapon *pWeapon) {
	DWORD dwSpreadVMT = (*reinterpret_cast< PDWORD_PTR* >(pWeapon))[485]; //460
	return ((float(__thiscall*)(C_BaseCombatWeapon*)) dwSpreadVMT)(pWeapon);
}

void UpdateAccuracyPenalty(C_BaseCombatWeapon *pWeapon) {
	DWORD dwUpdateVMT = (*reinterpret_cast< PDWORD_PTR* >(pWeapon))[486]; //461
	return ((void(__thiscall*)(C_BaseCombatWeapon*)) dwUpdateVMT)(pWeapon);
}

void SpreadFactor(CUserCmd *pCmd, C_BaseCombatWeapon *pWeapon) {
	
	if (!X::aim_nospread)
		return;

	if (X::misc_antiuntrust)
		return;

	Vector vecForward, vecRight, vecDir, vecUp, vecAntiDir;
	float flSpread, flInaccuracy;

	Vector qAntiSpread;

	UpdateAccuracyPenalty(pWeapon);

	flSpread = GetSpread(pWeapon);

	flInaccuracy = GetInaccuracy(pWeapon);
	pCmd->random_seed = MD5_PseudoRandom(pCmd->command_number) & 0x7FFFFFFF;
	RandomSeed((pCmd->random_seed & 0xFF) + 1);


	float fRand1 = RandomFloat(0.f, 1.f);
	float fRandPi1 = RandomFloat(0.f, 2.f * (float)M_PI);
	float fRand2 = RandomFloat(0.f, 1.f);
	float fRandPi2 = RandomFloat(0.f, 2.f * (float)M_PI);



	float fRandInaccuracy = fRand1 * GetInaccuracy(pWeapon);
	float fRandSpread = fRand2 * GetSpread(pWeapon);

	float fSpreadX = cos(fRandPi1) * fRandInaccuracy + cos(fRandPi2) * fRandSpread;
	float fSpreadY = sin(fRandPi1) * fRandInaccuracy + sin(fRandPi2) * fRandSpread;

	AngleToVectors(pCmd->viewangles, &vecForward, &vecRight, &vecUp);

	vecDir.x = (float)((float)(vecRight.x * fSpreadX) + vecForward.x) + (float)(vecUp.x * fSpreadY);
	vecDir.y = (float)((float)(fSpreadX * vecRight.y) + vecForward.y) + (float)(fSpreadY * vecUp.y);
	vecDir.z = (float)((float)(vecRight.z * fSpreadX) + vecForward.z) + (float)(vecUp.z * fSpreadY);

	vecAntiDir = vecForward + (vecRight * -fSpreadX) + (vecUp * -fSpreadY);

	vecAntiDir.NormalizeInPlace();

	SpreadVectorAngles(vecAntiDir, qAntiSpread);

	pCmd->viewangles = qAntiSpread;
}

bool qOnce = false;

void __fastcall hkDrawModelExecute(void* thisptr, int edx, void* context, void* state, const ModelRender_t &pInfo, matrix3x4 *pCustomBoneToWorld) {
	C_BaseEntity* pLocal = (C_BaseEntity*)vlv->pEntList->GetClientEntity(vlv->pEngine->GetLocalPlayer());
	C_BaseCombatWeapon* pWeapon = pLocal->Active();
	static IMaterial* mat1 = CreateMaterial(true);
	static IMaterial* mat2 = CreateMaterial(false);

	static IMaterial* playerMat1 = CreateMaterial(true);
	static IMaterial* playerMat2 = CreateMaterial(false);

	static IMaterial* pweapon = CreateMaterial(false);

	float flColor4[3];
	float flColor3[3];
	if (pInfo.pModel) {
		const char* szName = vlv->pModelInfo->GetModelName(pInfo.pModel);
		/* Arms */
		if (strstr(szName, "arms") && X::misc_enable && X::misc_nohands && (pWeapon)) {

			float flColor1[3] = { hands::r / 255.f, hands::g / 255.f, hands::b / 255.f }; // r, g, b [Orange]
			float flColor2[3] = { handsVis::r / 255.f, handsVis::g / 255.f, handsVis::b / 255.f }; // r, g, b [Blue]


			vlv->pRenderView->SetColorModulation(flColor1);
			vlv->pRenderView->SetBlend(1.f);
			vlv->pModelRender->ForcedMaterialOverride(mat1);
			vlv->oDrawModelExecute(thisptr, edx, context, state, pInfo, pCustomBoneToWorld);


			vlv->pRenderView->SetColorModulation(flColor2);
			vlv->pRenderView->SetBlend(1.f);
			vlv->pModelRender->ForcedMaterialOverride(mat2);
			vlv->oDrawModelExecute(thisptr, edx, context, state, pInfo, pCustomBoneToWorld);
		}

		/* No Sky World Stuff
		
		for (MaterialHandle_t i = vlv->pMatSystem->FirstMaterial(); i != vlv->pMatSystem->InvalidMaterial(); i = vlv->pMatSystem->NextMaterial(i)) {
			IMaterial *pMaterial = vlv->pMatSystem->GetMaterial(i);
			if (!pMaterial)
				continue;

			if (strstr(pMaterial->GetTextureGroupName(), "SkyBox textures")) {
				if (X::misc_enable && X::misc_nosky) {
					pMaterial->ColorModulate(0, 0, 0);
				}
			}

			if (strstr(pMaterial->GetTextureGroupName(), TEXTURE_GROUP_WORLD)) {
				if (X::esp_enable && X::esp_transparentwalls) {
					pMaterial->AlphaModulate(X::esp_transparentwalls_factor);
					pMaterial->SetVarFlag(MATERIAL_VAR_IGNOREZ, false);
				}
				else {
					pMaterial->AlphaModulate(1.f);
				}
			}
		}

		
		
		*/
		
		/* Ghost Active Weapon */
		if (strstr(szName, "models/weapons/v_") && X::misc_enable && X::misc_noweapons && (pWeapon)) {
			IMaterial* pHands = vlv->pMatSystem->FindMaterial(szName, TEXTURE_GROUP_MODEL);
			pHands->SetVarFlag(MATERIAL_VAR_NO_DRAW, true);
			vlv->pModelRender->ForcedMaterialOverride(pHands);
			vlv->oDrawModelExecute(thisptr, edx, context, state, pInfo, pCustomBoneToWorld);
		}

		if (strstr(szName, "flash") && X::misc_enable && X::misc_noflash) {
			IMaterial* Flash = vlv->pMatSystem->FindMaterial("effects\\flashbang", TEXTURE_GROUP_CLIENT_EFFECTS);
			IMaterial* FlashWhite = vlv->pMatSystem->FindMaterial("effects\\flashbang_white", TEXTURE_GROUP_CLIENT_EFFECTS);
			Flash->SetVarFlag(MATERIAL_VAR_NO_DRAW, true);
			FlashWhite->SetVarFlag(MATERIAL_VAR_NO_DRAW, true);
			vlv->pModelRender->ForcedMaterialOverride(Flash);
			vlv->pModelRender->ForcedMaterialOverride(FlashWhite);
		}
		

		/* Players */
		if (strstr(szName, "models/player") && X::esp_enable && X::esp_chams) {
			C_BaseEntity* pBaseEntity = vlv->pEntList->GetClientEntity(pInfo.entity_index);
			if (!pBaseEntity)
				return;

			if (pBaseEntity && pBaseEntity->Health() > 0) {


				if (pBaseEntity->Team() == 2) {
					flColor3[0] = model_ter::r / 255.f;
					flColor3[1] = model_ter::g / 255.f;
					flColor3[2] = model_ter::b / 255.f;
				}
				else if (pBaseEntity->Team() == 3) {
					flColor3[0] = model_ct::r / 255.f;
					flColor3[1] = model_ct::g / 255.f;
					flColor3[2] = model_ct::b / 255.f;
				}

				vlv->pRenderView->SetBlend(1.f);
				vlv->pRenderView->SetColorModulation(flColor3);
				vlv->pModelRender->ForcedMaterialOverride(playerMat1);
				vlv->oDrawModelExecute(thisptr, edx, context, state, pInfo, pCustomBoneToWorld);

				if (pBaseEntity->Team() == 2) {
					flColor4[0] = model_terVis::r / 255.f;
					flColor4[1] = model_terVis::g / 255.f;
					flColor4[2] = model_terVis::b / 255.f;
				}
				else if (pBaseEntity->Team() == 3) {
					flColor4[0] = model_ctVis::r / 255.f;
					flColor4[1] = model_ctVis::g / 255.f;
					flColor4[2] = model_ctVis::b / 255.f;
				}

				vlv->pRenderView->SetBlend(1.f);
				vlv->pRenderView->SetColorModulation(flColor4);
				vlv->pModelRender->ForcedMaterialOverride(playerMat2);
				vlv->oDrawModelExecute(thisptr, edx, context, state, pInfo, pCustomBoneToWorld);
			}
		}
	}
	vlv->oDrawModelExecute(thisptr, edx, context, state, pInfo, pCustomBoneToWorld);
	vlv->pModelRender->ForcedMaterialOverride(NULL);
}

void WriteVisuals() {
	BoxStruct structer;
	C_BaseEntity* pLocalEntity = (C_BaseEntity*)vlv->pEntList->GetClientEntity(vlv->pEngine->GetLocalPlayer());
	for (int i = 1; i < vlv->pEntList->GetHighestEntityIndex(); i++) {
		C_BaseEntity* pBaseEntity = (C_BaseEntity*)vlv->pEntList->GetClientEntity(i);

		if (!pBaseEntity)
			continue;

		if (pBaseEntity->Health() < 1)
			continue;

		if (pBaseEntity->Dormant())
			continue;

		if (!pBaseEntity->IsValid())
			continue;

		if (!X::esp_enable)
			continue;

		if (X::esp_ignoreteam) {
			if (pBaseEntity->Team() == pLocalEntity->Team()) {
				continue;
			}
		}

		player_info_t pinfo;
		vlv->pEngine->GetPlayerInfo(i, &pinfo);
		bool bVis = IsVisible(pLocalEntity, pBaseEntity);
		if (DrawPlayerBox(pBaseEntity, structer)) {
			if (pBaseEntity->Team() == 2) {
				if (X::esp_box) {
					if (buddy[pBaseEntity->GetIndex()]) {
						Draw->DrawBoxOutline(structer.x, structer.y, structer.w, structer.h, bVis ? Color::Orange() : Color::DarkOrange());
					}
					else {
						if(X::esp_boxoutline)
							Draw->DrawBoxOutline(structer.x, structer.y, structer.w, structer.h, bVis ? Color::Red() : Color::Yellow());
						else
							Draw->DrawBox(structer.x, structer.y, structer.w, structer.h, bVis ? Color::Red() : Color::Yellow());
					}
				}
				if (X::esp_health) {
					if (buddy[pBaseEntity->GetIndex()]) {
						Draw->DrawHealthbar(structer.x, structer.y + structer.h + 2, structer.w, 4, pBaseEntity->Health(), bVis ? Color::Orange() : Color::DarkOrange(), bVis ? Color(255, 120, 0, 255) : Color(255, 70, 0, 255));
					}
					else {
						Draw->DrawHealthbar(structer.x, structer.y + structer.h + 2, structer.w, 4, pBaseEntity->Health(), bVis ? Color(255, 0, 0, 255) : Color(255, 255, 0, 255), bVis ? Color(155, 0, 0, 255) : Color(155, 155, 0, 255));
					}
				}
			}

			if (pBaseEntity->Team() == 3) {
				if (X::esp_box) {
					if (buddy[pBaseEntity->GetIndex()]) {
						Draw->DrawBoxOutline(structer.x, structer.y, structer.w, structer.h, bVis ? Color::Orange() : Color::DarkOrange());
					}
					else {
						if(X::esp_boxoutline)
						Draw->DrawBoxOutline(structer.x, structer.y, structer.w, structer.h, bVis ? Color::Green() : Color::Blue());
						else
							Draw->DrawBox(structer.x, structer.y, structer.w, structer.h, bVis ? Color::Green() : Color::Blue());
					}
				}
				if (X::esp_health) {


					if (buddy[pBaseEntity->GetIndex()]) {
						Draw->DrawHealthbar(structer.x, structer.y + structer.h + 2, structer.w, 4, pBaseEntity->Health(), bVis ? Color::Orange() : Color::DarkOrange(), bVis ? Color(255, 120, 0, 255) : Color(255, 70, 0, 255));
					}
					else {
						Draw->DrawHealthbar(structer.x, structer.y + structer.h + 2, structer.w, 4, pBaseEntity->Health(), bVis ? Color::Green() : Color::Blue(), bVis ? Color(0, 155, 0, 255) : Color(0, 0, 155, 255));
					}
				}
			}
			if (X::esp_name) {
				if (buddy[pBaseEntity->GetIndex()]) {
					Draw->DrawString(structer.x + structer.w, structer.y + 10, Color::Orange(), pfont, "Buddy");
				}
				Draw->DrawString(structer.x + structer.w, structer.y, buddy[pBaseEntity->GetIndex()] ? Color::Orange() : Color::White(), pfont, pinfo.name);
			}
		}
	}
}
void __fastcall hkPaintTraverse(void* ecx, void* edx, unsigned int vguiPanel, bool forceRepaint, bool allowForce) {
	vlv->oPaintTraverse(ecx, vguiPanel, forceRepaint, allowForce);

	static unsigned int MatPanel;
	if (!MatPanel) {
		const char* szName = vlv->pPanel->GetName(vguiPanel);
		if (strstr(szName, "MatSystemTopPanel")) {
			font = vlv->pSurface->CreateFontA();
			pfont = vlv->pSurface->CreateFontA();
			vlv->pSurface->SetFontGlyphSet(font, "Calibri", 14, 400, 0, 0, FONTFLAG_ANTIALIAS);
			vlv->pSurface->SetFontGlyphSet(pfont, "Calibri", 16, 400, 0, 0, FONTFLAG_ANTIALIAS);
			MatPanel = vguiPanel;
		}
	}
	if (MatPanel == vguiPanel) {
		Draw->DrawPlayerlist(0, 30);
		InitializeToggle();

		WriteVisuals();
		if (RickAstley::menu) {
			Draw->DrawMenu(X::menu_x, X::menu_y);
			GetCursorPos(&cur);
			Draw->MakeMouse(cur.x, cur.y);
			vlv->pEngine->ExecuteClientCmd("cl_mouseenable 0");
		}
	}
}



void MakeAntiAim(CUserCmd* pCmd, C_BaseEntity* pLocal, C_BaseCombatWeapon* pWeapon, bool& SENDPACKET) {
	if (!X::misc_enable)
		return;

	if (!X::misc_antiaim)
		return;

	float servertime = pLocal->TickBase() * vlv->pGlobals->interval_per_tick;
	float nextattack = pWeapon->flNextPrimaryAttack();

	bool bAttack = false;
	if (servertime > nextattack)
		bAttack = true;

	if (bAttack && (pCmd->buttons & IN_ATTACK)) {
		SENDPACKET = false;
	}
	else {
		SENDPACKET = true;
	}

	if(SENDPACKET && !(pWeapon->IsKnife()) && !(pWeapon->IsGrenades())) {
	if (pitchDropdown::iFactor == 1) { // Emotion
		pCmd->viewangles.x = 89;
	}

	if (!X::misc_antiuntrust && pitchDropdown::iFactor == 2) { // Up!
		pCmd->viewangles.x = -180;
	}

	if (!X::misc_antiuntrust && pitchDropdown::iFactor == 3) { // Fakedown!
		pCmd->viewangles.x = 180;
	}

	if (yawDropdown::iFactor == 1) { // Backwards
		pCmd->viewangles.y += 180;
	}

	if (yawDropdown::iFactor == 2) { // Sideways
		pCmd->viewangles.y += 90;
	}

	if (yawDropdown::iFactor == 3) { // Jitter
		static bool xddd = false;

		if (!xddd)
			pCmd->viewangles.y = 90;
		else
			pCmd->viewangles.y = -90;

		xddd = !xddd;
	}
	}

}

C_BaseCombatWeapon* C_BaseEntity::Active() {
	ULONG pWeepEhandle = *(PULONG)((DWORD)this + offsets->m_hActiveWeapon);
	return (C_BaseCombatWeapon*)(vlv->pEntList->GetClientEntityFromHandle(pWeepEhandle));
}
int iSpam = 0;
int iSpamName = 0;
void MakeNamespam() {
	if (!X::misc_enable)
		return;
	
	if (!X::misc_namespam)
		return;

	static ConVar* pVar = vlv->pCvar->FindVar(charenc("name"));
	iSpam++;
	if (pVar) {
		*(int*)((DWORD)&pVar->fnChangeCallback + 0xC) = NULL;

		if (iSpam > 5)
			iSpamName = iSpamName + 1;

		if (iSpamName > 3)
			iSpamName = 0;
		pVar->SetValue(nameSpammer[iSpamName]);

		if (iSpam > 6)
			iSpam = 0;
	}
}
int iCool = 0;
int iStole = 0;
void MakeChatspam() {
	if (!X::misc_enable)
		return;

	if (!X::misc_chatspam)
		return;

	iStole++;
	if (iStole > 10) {
		iCool = iCool + 1;

		if (iCool > 5)
			iCool = 0;
		char random[255];
		sprintf(random, "say %s", chatSpammer[iCool]);
		vlv->pEngine->ExecuteClientCmd(random);
	}

	if (iStole > 11)
		iStole = 0;
}

bool CheckWall(C_BaseEntity *local, CUserCmd *cmd, float flWall, float flCornor) {
	if (!X::misc_enable)
		return false;

	if (!X::misc_walldetection)
		return false;

	static CTraceFilterWorldOnly filter;

	bool ret = false;

	Vector localPosition = local->GetEyePos();

	for (int y = 0; y < 360; y++)
	{
		Vector tmp(10.0f, cmd->viewangles.y, 0.0f);
		tmp.y += y;
		tmp.Normalized();

		Vector forward;
		AngleVectors(tmp, &forward);

		float length = ((16.0f + 3.0f) + ((16.0f + 3.0f) * sin(DEG2RAD(10.0f)))) + 7.0f;
		forward *= length;

		Ray_t ray;
		trace_t traceData;

		ray.Init(localPosition, (localPosition + forward));
		vlv->pEngineTrace->TraceRay(ray, 0x46004003, (CTraceFilter*)&filter, &traceData);

		if (traceData.fraction != 1.0f)
		{
			Vector angles;
			Vector Negate = traceData.plane.normal;

			Negate *= -1;
			AngleVectors(Negate, &angles);

			tmp.y = angles.y;
			tmp.Normalized();
			trace_t leftTrace, rightTrace;

			Vector left, right;
			AngleVectors(tmp + Vector(0.0f, 30.0f, 0.0f), &left);
			AngleVectors(tmp - Vector(0.0f, 30.0f, 0.0f), &right);

			left *= (length + (length * sin(DEG2RAD(30.0f))));
			right *= (length + (length * sin(DEG2RAD(30.0f))));

			ray.Init(localPosition, (localPosition + left));
			vlv->pEngineTrace->TraceRay(ray, 0x46004003, (CTraceFilter*)&filter, &leftTrace);

			ray.Init(localPosition, (localPosition + right));
			vlv->pEngineTrace->TraceRay(ray, 0x46004003, (CTraceFilter*)&filter, &rightTrace);

			if ((leftTrace.fraction == 1.0f)
				&& (rightTrace.fraction != 1.0f))
			{
				tmp.y -= flCornor;
				// LEFT
			}
			else if ((leftTrace.fraction != 1.0f)
				&& (rightTrace.fraction == 1.0f))
			{
				tmp.y += flCornor;
				// RIGHT
			}

			cmd->viewangles.y = tmp.y;
			cmd->viewangles.y -= flWall;
			ret = true;
		}
	}

	return ret;
}

class CMoveData
{
public:
	bool            m_bFirstRunOfFunctions : 1;
	bool            m_bGameCodeMovedPlayer : 1;

	int                m_nPlayerHandle;    // edict index on server, client entity handle on client

	int                m_nImpulseCommand;    // Impulse command issued.
	Vector            m_vecViewAngles;    // Command view angles (local space)
	Vector            m_vecAbsViewAngles;    // Command view angles (world space)
	int                m_nButtons;            // Attack buttons.
	int                m_nOldButtons;        // From host_client->oldbuttons;
	float            m_flForwardMove;
	float            m_flSideMove;
	float            m_flUpMove;

	float            m_flMaxSpeed;
	float            m_flClientMaxSpeed;

	// Variables from the player edict (sv_player) or entvars on the client.
	// These are copied in here before calling and copied out after calling.
	Vector            m_vecVelocity;        // edict::velocity        // Current movement direction.
	Vector            m_vecAngles;        // edict::angles
	Vector            m_vecOldAngles;

	// Output only
	float            m_outStepHeight;    // how much you climbed this move
	Vector            m_outWishVel;        // This is where you tried 
	Vector            m_outJumpVel;        // This is your jump velocity

										   // Movement constraints    (radius 0 means no constraint)
	Vector            m_vecConstraintCenter;
	float            m_flConstraintRadius;
	float            m_flConstraintWidth;
	float            m_flConstraintSpeedFactor;

	float            m_flUnknown[5];

	Vector            m_vecAbsOrigin;        // edict::origin
};

void RunCommand(C_BaseEntity* pEntity, CUserCmd *pUserCmd) {
	if (!vlv->pMoveHelper)
		return;

	static bool once = false;

	if (!once)
	{
		vlv->pMoveHelper = **(ImoveHelper***)(FindPattern("client.dll", (PBYTE)"\x8B\x0D\x00\x00\x00\x00\x8B\x45\x00\x51\x8B\xD4\x89\x02\x8B\x01", "xx????xx?xxxxxxx") + 2);
		//curPlayer = *(BaseEntity**)((int)g_pGameMovement + 8);
		once = true;
	}

	int tickBase = pEntity->TickBase();

	float oldCurTime = vlv->pGlobals->curtime;
	float oldFrameTime = vlv->pGlobals->frametime;

	vlv->pGlobals->curtime = pEntity->TickBase() * vlv->pGlobals->interval_per_tick;
	vlv->pGlobals->frametime = vlv->pGlobals->interval_per_tick;

	CUserCmd oldCmd;

	memcpy(&oldCmd, pUserCmd, sizeof(CUserCmd));

	//DWORD oldCurCmd = *(DWORD*)((DWORD)self + 0x16E8);

	//*(DWORD*)((DWORD)self + 0x16E8) = (DWORD)cmd;

	CMoveData move_data;
	memset(&move_data, 0, sizeof(move_data));

	vlv->pMoveHelper->SetHost(pEntity);

	vlv->pPrediction->SetupMove(pEntity, pUserCmd, NULL, &move_data);
	vlv->pGameMovement->ProcessMovement(pEntity, &move_data);
	vlv->pPrediction->FinishMove(pEntity, pUserCmd, &move_data);

	//*(DWORD*)((DWORD)self + 0x16E8) = oldCurCmd;

	if (oldCmd.hasbeenpredicted)
	{
		tickBase = pEntity->TickBase();
	}
	else
	{
		++tickBase;
	}

	vlv->pMoveHelper->SetHost(NULL);

	vlv->pGlobals->curtime = oldCurTime;
	vlv->pGlobals->frametime = oldFrameTime;
}

typedef void(__stdcall* tRunCommand)(C_BaseEntity*, CUserCmd*, void*);
tRunCommand oRunCommand;

//void __stdcall hkdRunCommand(C_BaseEntity* pEntity, CUserCmd* pCmd, void* moveHelper) {
	//oRunCommand(pEntity, pCmd, moveHelper);
	//vlv->pMoveHelper = (ImoveHelper*)moveHelper;
//}

void SetPrediction(Vector& Angles, C_BaseEntity* pLocal, C_BaseEntity* pEntity) {
	Angles.y += (pEntity->GetVelocity().y * vlv->pGlobals->interval_per_tick) * 0.19f;
}

void AntiAim(CUserCmd* pCmd, C_BaseCombatWeapon* g, C_BaseEntity* p, bool& sendPacket) {
	if (g->IsKnife())
		return;

	if (g->IsGrenades())
		return;

	if (!X::misc_enable)
		return;

	if (!X::misc_antiaim)
		return;

	float servertime = p->TickBase() * vlv->pGlobals->interval_per_tick;
	float nextattack = g->flNextPrimaryAttack();
	static float iChoked = 0.0;
	bool bAttack = true;
	if (nextattack > servertime)
		bAttack = false;

	if (pCmd->buttons & IN_ATTACK && bAttack && iChoked < 0.5f) {
		sendPacket = false;
		iChoked++;
	}
	else {
		sendPacket = true;
		iChoked = 0.0;
	}

	if (sendPacket) {
		pCmd->viewangles.x = 89;
		pCmd->viewangles.y += 180;
	}
}


Vector GetBonePosition(C_BaseEntity* g, int boneid, Vector& angle) {
	angle.x = *(float*)((DWORD)g->BoneMatrix() + 0x30 * boneid + 0xC);
	angle.y = *(float*)((DWORD)g->BoneMatrix() + 0x30 * boneid + 0x1C);
	angle.z = *(float*)((DWORD)g->BoneMatrix() + 0x30 * boneid + 0x2C);
	return angle;
}

Vector CalcAngle(Vector& src, Vector& dst, Vector& angles) {
	double delta[3] = { (src[0] - dst[0]), (src[1] - dst[1]), (src[2] - dst[2]) };
	float hyp = sqrt(delta[0] * delta[0] + delta[1] * delta[1] + delta[2] * delta[2]);
	angles[0] = (float)(asinf(delta[2] / hyp) * M_RADPI);
	angles[1] = (float)(atanf(delta[1] / delta[0]) * M_RADPI);
	angles[2] = 0.0f;
	if (delta[0] >= 0.0) {
		angles[1] += 180.0f;
	}

	return angles;
}

Vector CalcAngleRcs(Vector& src, Vector& dst, Vector& angles, C_BaseEntity* pLocal, bool recoil) {
	double delta[3] = { (src[0] - dst[0]), (src[1] - dst[1]), (src[2] - dst[2]) };
	float hyp = sqrt(delta[0] * delta[0] + delta[1] * delta[1] + delta[2] * delta[2]);
	if(recoil) {
		angles[0] = (float)(asinf(delta[2] / hyp) * M_RADPI - pLocal->GetPunch().x * 2.f);
	angles[1] = (float)(atanf(delta[1] / delta[0]) * M_RADPI - pLocal->GetPunch().y * 2.f);
	} else {
		angles[0] = (float)(asinf(delta[2] / hyp) * M_RADPI);
		angles[1] = (float)(atanf(delta[1] / delta[0]) * M_RADPI);
	}
	angles[2] = 0.0f;
	if (delta[0] >= 0.0) {
		angles[1] += 180.0f;
	}

	return angles;
}



float GetFOV(Vector viewangle, Vector eyepos, Vector dest) {
	Vector ang, aim;
	CalcAngle(eyepos, dest, ang);
	AngleVectors(viewangle, &aim);
	AngleVectors(ang, &ang);

	float mag_s = std::sqrt((aim[0] * aim[0]) + (aim[1] * aim[1]) + (aim[2] * aim[2]));
	float mag_d = mag_s;
	float u_dot_v = aim[0] * ang[0] + aim[1] * ang[1] + aim[2] * ang[2];
	float fov = std::acos(u_dot_v / (mag_s * mag_d)) * (180.f / M_PI_F);
	return fov;
}

float GetFOVLegit(Vector viewangle, Vector eyepos, Vector dest, C_BaseEntity* pLocal, bool recoil) {
	Vector ang, aim;
	CalcAngleRcs(eyepos, dest, ang, pLocal, recoil);
	AngleVectors(viewangle, &aim);
	AngleVectors(ang, &ang);

	float mag_s = std::sqrt((aim[0] * aim[0]) + (aim[1] * aim[1]) + (aim[2] * aim[2]));
	float mag_d = mag_s;
	float u_dot_v = aim[0] * ang[0] + aim[1] * ang[1] + aim[2] * ang[2];
	float fov = std::acos(u_dot_v / (mag_s * mag_d)) * (180.f / M_PI_F);
	return fov;
}

void MakeRecoiler(CUserCmd* pCmd, C_BaseEntity* p) {
	if (!X::aim_recoil)
		return;

	Vector twater = p->GetPunch();

	pCmd->viewangles.x -= twater.x * 2.f;
	pCmd->viewangles.y -= twater.y * 2.f;
}

void MakeBhop(CUserCmd* pCmd, C_BaseEntity* pLocal) {
	if (!X::misc_bhop)
		return;

	if (!X::misc_enable)
		return;
		static bool bLastJumped = false;
		static bool bShouldFake = false;

		if (!bLastJumped && bShouldFake)
		{
			bShouldFake = false;
			pCmd->buttons |= IN_JUMP;
		}
		else if (pCmd->buttons&IN_JUMP)
		{
			if (pLocal->Flags() & FL_ONGROUND)
			{
				bLastJumped = true;
				bShouldFake = true;
			}
			else
			{
				pCmd->buttons &= ~IN_JUMP;
				bLastJumped = false;
			}
		}
		else
		{
			bLastJumped = false;
			bShouldFake = false;
		}
}

#define	HITGROUP_GENERIC	0
#define	HITGROUP_HEAD		1
#define	HITGROUP_CHEST		2
#define	HITGROUP_STOMACH	3
#define HITGROUP_LEFTARM	4	
#define HITGROUP_RIGHTARM	5
#define HITGROUP_LEFTLEG	6
#define HITGROUP_RIGHTLEG	7
#define HITGROUP_GEAR		10

float GetHitgroupDamageMultiplier(int iHitGroup)
{
	switch (iHitGroup)
	{
	case HITGROUP_GENERIC: {
		return 1.0f;
	}

	case HITGROUP_HEAD: {
		return 2.0f;
	}

	case HITGROUP_CHEST: {
		return 1.0f;
	}

	case HITGROUP_STOMACH: {
		return 1.0f;
	}

	case HITGROUP_LEFTARM: {
	case HITGROUP_RIGHTARM:
		return 1.0f;
	}

	case HITGROUP_LEFTLEG: {
	case HITGROUP_RIGHTLEG:
		return 1.0f;
	}
	}
	return 1.0f;
}

struct FireBulletData {

	Vector           src;
	trace_t          enter_trace;
	Vector           direction;
	CTraceFilter    filter;
	float           trace_length;
	float           trace_length_remaining;
	float           current_damage;
	int             penetrate_count;
};

void ScaleDamage(int hitgroup, C_BaseEntity *enemy, float weapon_armor_ratio, float &current_damage)
{
	current_damage *= GetHitgroupDamageMultiplier(hitgroup);

	int armor = enemy->ArmorValue();
	int helmet = enemy->HasHelmet();

	if (armor > 0)
	{
		if (hitgroup == HITGROUP_HEAD)
		{
			if (helmet)
				current_damage *= (weapon_armor_ratio * .5f);
		}
		else
		{
			current_damage *= (weapon_armor_ratio * .5f);
		}
	}
}

bool DidHitNonWorldEntity(C_BaseEntity* m_pEnt) {
	return m_pEnt != NULL && m_pEnt == vlv->pEntList->GetClientEntity(0);
}

bool TraceToExit(Vector &end, trace_t *enter_trace, Vector start, Vector dir, trace_t *exit_trace)
{
	float distance = 0.0f;

	while (distance <= 90.0f)
	{
		distance += 4.0f;
		end = start + dir * distance;

		auto point_contents = vlv->pEngineTrace->GetPointContents(end, MASK_SHOT_HULL | CONTENTS_HITBOX, NULL);

		if (point_contents & MASK_SHOT_HULL && (!(point_contents & CONTENTS_HITBOX)))
			continue;

		auto new_end = end - (dir * 4.0f);

		Ray_t ray;
		ray.Init(end, new_end);
		vlv->pEngineTrace->TraceRay(ray, MASK_SHOT, 0, exit_trace);

		if (exit_trace->startsolid && exit_trace->surface.flags & SURF_HITBOX)
		{
			ray.Init(end, start);
			CTraceFilter filter;
			filter.pSkip = exit_trace->m_pEnt;
			vlv->pEngineTrace->TraceRay(ray, 0x600400B, &filter, exit_trace);

			if ((exit_trace->fraction < 1.0f || exit_trace->allsolid) && !exit_trace->startsolid)
			{
				end = exit_trace->endpos;
				return true;
			}
			continue;
		}

		if (!(exit_trace->fraction < 1.0 || exit_trace->allsolid || exit_trace->startsolid) || exit_trace->startsolid)
		{
			if (exit_trace->m_pEnt)
			{
				if (DidHitNonWorldEntity(enter_trace->m_pEnt))
					return true;
			}
			continue;
		}

		if (((exit_trace->surface.flags >> 7) & 1) && !((enter_trace->surface.flags >> 7) & 1))
			continue;

		if (exit_trace->plane.normal.Dot(dir) <= 1.0f)
		{
			auto fraction = exit_trace->fraction * 4.0f;
			end = end - (dir * fraction);
			return true;
		}
	}
	return false;
}

void TraceLine(Vector& vecAbsStart, Vector& vecAbsEnd, unsigned int mask, C_BaseEntity* ignore, trace_t* ptr) {
	Ray_t ray;
	ray.Init(vecAbsStart, vecAbsEnd);
	CTraceFilter filter;
	filter.pSkip = ignore;

	vlv->pEngineTrace->TraceRay(ray, mask, &filter, ptr);
}

bool HandleBulletPenetration(CCSWeaponInfo *wpn_data, FireBulletData &data) {
	surfacedata_t *enter_surface_data = vlv->pProps->GetSurfaceData(data.enter_trace.surface.surfaceProps);
	int enter_material = enter_surface_data->game.material;
	float enter_surf_penetration_mod = *(float*)((DWORD)enter_surface_data + 76);

	data.trace_length += data.enter_trace.fraction * data.trace_length_remaining;
	data.current_damage *= pow((wpn_data->m_flRangeModifier), (data.trace_length * 0.002));

	if ((data.trace_length > 3000.f) || (enter_surf_penetration_mod < 0.1f))
		data.penetrate_count = 0;

	if (data.penetrate_count <= 0)
		return false;

	Vector dummy;
	trace_t trace_exit;
	if (!TraceToExit(dummy, &data.enter_trace, data.enter_trace.endpos, data.direction, &trace_exit))
		return false;




	surfacedata_t *exit_surface_data = vlv->pProps->GetSurfaceData(trace_exit.surface.surfaceProps);
	int exit_material = exit_surface_data->game.material;

	float exit_surf_penetration_mod = *(float*)((DWORD)exit_surface_data + 76);
	float final_damage_modifier = 0.16f;
	float combined_penetration_modifier = 0.0f;

	if (((data.enter_trace.contents & CONTENTS_GRATE) != 0) || (enter_material == 89) || (enter_material == 71))
	{
		combined_penetration_modifier = 3.0f;
		final_damage_modifier = 0.05f;
	}
	else
	{
		combined_penetration_modifier = (enter_surf_penetration_mod + exit_surf_penetration_mod) * 0.5f;
	}

	if (enter_material == exit_material)
	{
		if (exit_material == 87 || exit_material == 85)
			combined_penetration_modifier = 3.0f;
		else if (exit_material == 76)
			combined_penetration_modifier = 2.0f;
	}

	float v34 = fmaxf(0.f, 1.0f / combined_penetration_modifier);
	float v35 = (data.current_damage * final_damage_modifier) + v34 * 3.0f * fmaxf(0.0f, (3.0f / wpn_data->m_flPenetration) * 1.25f);
	float thickness = (trace_exit.endpos - data.enter_trace.endpos).Length();

	thickness *= thickness;
	thickness *= v34;
	thickness /= 24.0f;

	float lost_damage = fmaxf(0.0f, v35 + thickness);

	if (lost_damage > data.current_damage)
		return false;

	if (lost_damage >= 0.0f)
		data.current_damage -= lost_damage;

	if (data.current_damage < 1.0f)
		return false;

	data.src = trace_exit.endpos;
	data.penetrate_count--;

	return true;
}

bool SimulateFireBullet(C_BaseCombatWeapon* pWeapon, FireBulletData &data)
{
	C_BaseEntity* pLocalEntity = (C_BaseEntity*)vlv->pEntList->GetClientEntity(vlv->pEngine->GetLocalPlayer());
	data.penetrate_count = 4;
	data.trace_length = 0.0f;
	CCSWeaponInfo* weaponData = pLocalEntity->Active()->GetCSWpnData();

	if (weaponData == NULL)
		return false;

	data.current_damage = (float)weaponData->m_iDamage;

	while ((data.penetrate_count > 0) && (data.current_damage >= 1.0f))
	{
		data.trace_length_remaining = weaponData->m_flRange - data.trace_length;

		Vector end = data.src + data.direction * data.trace_length_remaining;

		//data.enter_trace
		TraceLine(data.src, end, MASK_SHOT, pLocalEntity, &data.enter_trace);

		Ray_t ray;
		ray.Init(data.src, end + data.direction*40.f);

		vlv->pEngineTrace->TraceRay(ray, MASK_SHOT, &data.filter, &data.enter_trace);

		TraceLine(data.src, end + data.direction*40.f, MASK_SHOT, pLocalEntity, &data.enter_trace);

		if (data.enter_trace.fraction == 1.0f)
			break;

		if ((data.enter_trace.hitgroup <= 7) && (data.enter_trace.hitgroup > 0) && (pLocalEntity->Team() != data.enter_trace.m_pEnt->Team()) && (data.enter_trace.m_pEnt->Team() == 2 || data.enter_trace.m_pEnt->Team() == 3)) {
			data.trace_length += data.enter_trace.fraction * data.trace_length_remaining;
			data.current_damage *= pow(weaponData->m_flRangeModifier, data.trace_length * 0.002);
			ScaleDamage(data.enter_trace.hitgroup, data.enter_trace.m_pEnt, weaponData->m_flArmorRatio, data.current_damage);

			return true;
		}

		if (!HandleBulletPenetration(weaponData, data))
			break;
	}

	return false;
}

bool GetDamage(Vector& point, float* damage, C_BaseEntity* pLocalEntity) {
	Vector dst = point;
	FireBulletData data;
	data.src = pLocalEntity->GetEyePos();
	data.filter.pSkip = pLocalEntity;

	Vector angles = CalcAngle(data.src, point, dst);
	AngleVectors(angles, &data.direction);
	Vector dataNormalized;

	data.direction.Normalized();

	C_BaseCombatWeapon* gWeapon = pLocalEntity->Active();
	if (SimulateFireBullet(gWeapon, data))
	{
		*damage = data.current_damage;
		return true;
	}

	return false;
}

void MakePerfectSilent(CUserCmd* pCmd, C_BaseCombatWeapon* pWeapon, C_BaseEntity* pLocalEntity, bool& bSendPacket, Vector oldAngle, float sidemove, float forwardmove) {
	if (!X::aim_enable)
		return;

	if (!X::aim_psilent && !X::aim_silent)
		return;

	float servertime = pLocalEntity->TickBase() * vlv->pGlobals->interval_per_tick;
	float nextprimaryattack = pLocalEntity->Active()->flNextPrimaryAttack();

	bool bAttack = true;
	if (nextprimaryattack > servertime)
		bAttack = false;
	static float iChoked = 0.0;
	if (pCmd->buttons & IN_ATTACK && bAttack && iChoked < 0.5f) {
		bSendPacket = false;
		iChoked++;
	}
	else {
		bSendPacket = true;
		iChoked = 0.0;
	}

	if (bSendPacket) {
		pCmd->forwardmove = forwardmove;
		pCmd->sidemove = sidemove;
		pCmd->viewangles = oldAngle;
	}
}

void MakeTelehop(CUserCmd* pCmd, C_BaseEntity* pLocal) {
	if (X::misc_antiuntrust)
		return;

	if (!X::misc_autostrafe)
		return;


	static float move = 650.f;
	float s_move = move * 0.5065f;

	if (pCmd->buttons & IN_JUMP && !(pLocal->Flags() & FL_ONGROUND)) {

		pCmd->forwardmove = move * 0.015f;
		pCmd->sidemove += (float)(((pCmd->tick_count % 2) * 2) - 1) * s_move;

		if (pCmd->mousedx)
			pCmd->sidemove = (float)(pCmd->mousedx, -1, 1) * s_move;

		static float strafe = pCmd->viewangles.y;

		float rt = pCmd->viewangles.y, rotation;
		rotation = strafe - rt;

		if (rotation < FloatNegate(vlv->pGlobals->interval_per_tick))
			pCmd->sidemove = -s_move;

		if (rotation > vlv->pGlobals->interval_per_tick)
			pCmd->sidemove = s_move;

		strafe = rt;
	}
}


void MakeAim(C_BaseEntity* pLocal, CUserCmd* pCmd, C_BaseCombatWeapon* pWeapon) {
	for (int i = 1; i < vlv->pEntList->GetHighestEntityIndex(); i++) {
		C_BaseEntity* ent = (C_BaseEntity*)vlv->pEntList->GetClientEntity(i);

		if (!X::aim_enable)
			continue;

		if (!ent)
			continue;

		if (!ent->IsValid())
			continue;

		if (ent->Team() == pLocal->Team())
			continue;

		if (ent->IsImmune())
			continue;

		if (pWeapon->IsKnife())
			continue;

		if (pWeapon->IsGrenades())
			continue;

		if (pWeapon->iClip1() < 1)
			continue;

		float servertime = pLocal->TickBase() * vlv->pGlobals->interval_per_tick;
		float nextattack = pWeapon->flNextPrimaryAttack();

		bool bAttack = true;
		if (nextattack > servertime)
			bAttack = false;

		float dmg = 0;
		Vector vFrom, vEnd;
		GetBonePosition(ent, X::aim_bone, vFrom);
		CalcAngle(pLocal->GetEyePos(), vFrom, vEnd);
		if (GetFOV(pCmd->viewangles, pLocal->GetEyePos(), vFrom) < X::aim_fov) {
			if (IsVisible(pLocal, ent) && !X::aim_autowall) {
				if (X::aim_autoshoot && !(pCmd->buttons & IN_ATTACK) && bAttack) {
					pCmd->buttons |= IN_ATTACK;
				}

				if (pCmd->buttons & IN_ATTACK) {
					pCmd->viewangles = vEnd;
					if (!X::aim_silent) {
						vlv->pEngine->SetViewAngles(vEnd.Clamp());
					}
				}
			}
			else if (GetDamage(vFrom, &dmg, pLocal) || IsVisible(pLocal, ent) && X::aim_autowall) {
				if (X::aim_autoshoot && !(pCmd->buttons & IN_ATTACK) && bAttack) {
					pCmd->buttons |= IN_ATTACK;
				}

				if (pCmd->buttons & IN_ATTACK) {
					pCmd->viewangles = vEnd;
					if (!X::aim_silent) {
						vlv->pEngine->SetViewAngles(vEnd.Clamp());
					}
				}
			}
		}
	}
}


/*
auto AutoStrafe(C_BaseEntity* pLocal, CUserCmd* cmd) -> void
{
Vector oldViewAngles = cmd->viewangles;

bool bCanBhop = false;
static bool bLastJumped = false, bShouldFake = false;
if (pLocal->MoveType() != MOVETYPE_LADDER && !(pLocal->Flags() & FL_ONGROUND))
{
bCanBhop = true;
}

if (pLocal->MoveType() != MOVETYPE_NOCLIP)
{
Vector velocity = pLocal->GetVelocity();
float speed = sqrt((velocity.x * velocity.x) + (velocity.y * velocity.y));

static float tick_rate;
if (vlv->pGlobals->interval_per_tick * 100.0f > 1.0f) tick_rate = 1.1f;
else tick_rate = 1.0f;

float value = (8.15f - tick_rate) - (this->GetMaxSpeed() / 340.0f);

if (this->GetMaxSpeed() > 160.0f && this->GetMaxSpeed() < 750.0f)
{
value = (4.6f - tick_rate) - (this->GetMaxSpeed() / 340.0f);
}

if (this->GetMaxSpeed() > 750.0f)
{
value = (3.0f - tick_rate) - (this->GetMaxSpeed() / 1000.0f);
}

if (value <= 0.275f)
{
value = 0.275f;
}

bool bKeysPressed = true;
if (cmd->buttons & IN_MOVELEFT || cmd->buttons & IN_MOVERIGHT || cmd->buttons & IN_BACK || cmd->buttons & IN_FORWARD) bKeysPressed = false;

if ((bKeysPressed && bCanBhop) || (bKeysPressed && GetAsyncKeyState(VK_SPACE)))
{
static float old_yaw = 0.0f;
float diff = AngleNormalize(oldViewAngles.y - old_yaw);

if (abs(diff) < value)
{
static bool bFlip = false;
if (bFlip)
{
oldViewAngles.y -= value;
cmd->sidemove = -400.0f;
bFlip = false;
}
else
{
oldViewAngles.y += value;
cmd->sidemove = 400.0f;
bFlip = true;
}
}
else
{
if (diff > 0.0f)
{
cmd->sidemove = -400.0f;
}

if (diff < 0.0f)
{
cmd->sidemove = 400.0f;
}
}

old_yaw = oldViewAngles.y;
}
}
}*/

void SmoothAnglesOut(Vector& AnglesToSmooth, CUserCmd* pCmd, float factor) {
	Vector vDelta = pCmd->viewangles - AnglesToSmooth;
	vDelta.Clamp();
	int smoother = factor * 5;
	AnglesToSmooth = pCmd->viewangles - vDelta / smoother;
}



void MakeLegitbot(CUserCmd* pCmd, C_BaseCombatWeapon* pWeapon, C_BaseEntity* pLocal) {
	for (int i = 1; i < vlv->pEntList->GetHighestEntityIndex(); i++) {
		C_BaseEntity* pBaseEntity = vlv->pEntList->GetClientEntity(i);

		if (X::aim_enable)
			continue;

		if (!X::legit_aimbot_enable)
			continue;

		if (!pBaseEntity)
			continue;

		if (!pBaseEntity->IsValid())
			continue;

		if (pBaseEntity->Team() == pLocal->Team())
			continue;

		if (pBaseEntity->IsImmune())
			continue;

		if (pWeapon->IsKnife())
			continue;

		if (pWeapon->IsGrenades())
			continue;

		if (pWeapon->iClip1() < 1)
			continue;

		Vector From, To;

		if (pWeapon->IsPistolEx()) {
			GetBonePosition(pBaseEntity, X::legit_aimbot_pistol_bone, From);
			CalcAngleRcs(pLocal->GetEyePos(), From, To, pLocal, X::legit_aimbot_pistol_recoil);
			SmoothAnglesOut(To, pCmd, X::legit_aimbot_pistol_speed);
			if (GetFOVLegit(pCmd->viewangles, pLocal->GetEyePos(), From, pLocal, X::legit_aimbot_pistol_recoil) < X::legit_aimbot_pistol_fov) {
				if (IsVisible(pLocal, pBaseEntity)) {
					//if (X::legit_aimbot_autofire) {
					//	pCmd->buttons |= IN_ATTACK;
					//}
					if (X::legit_aimbot_key == 0 && GetAsyncKeyState(VK_LBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 1 && GetAsyncKeyState(VK_RBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 2 && GetAsyncKeyState(VK_MBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 3 && GetAsyncKeyState(VK_XBUTTON1)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 4 && GetAsyncKeyState(VK_XBUTTON2)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
				}
			}
		}

		if (pWeapon->IsSniper()) {
			GetBonePosition(pBaseEntity, X::legit_aimbot_sniper_bone, From);
			CalcAngleRcs(pLocal->GetEyePos(), From, To, pLocal, X::legit_aimbot_sniper_recoil);
			SmoothAnglesOut(To, pCmd, X::legit_aimbot_sniper_speed);
			if (GetFOVLegit(pCmd->viewangles, pLocal->GetEyePos(), From, pLocal, X::legit_aimbot_sniper_recoil) < X::legit_aimbot_sniper_fov) {
				if (IsVisible(pLocal, pBaseEntity)) {
					//if (X::legit_aimbot_autofire) {
					//	pCmd->buttons |= IN_ATTACK;
					//}
					if (X::legit_aimbot_key == 0 && GetAsyncKeyState(VK_LBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 1 && GetAsyncKeyState(VK_RBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 2 && GetAsyncKeyState(VK_MBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 3 && GetAsyncKeyState(VK_XBUTTON1)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 4 && GetAsyncKeyState(VK_XBUTTON2)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
				}
			}
		}

		if (pWeapon->IsRifle()) {
			GetBonePosition(pBaseEntity, X::legit_aimbot_rifle_bone, From);
			CalcAngleRcs(pLocal->GetEyePos(), From, To, pLocal, X::legit_aimbot_rifle_recoil);
			SmoothAnglesOut(To, pCmd, X::legit_aimbot_rifle_speed);
			if (GetFOVLegit(pCmd->viewangles, pLocal->GetEyePos(), From, pLocal, X::legit_aimbot_rifle_recoil) < X::legit_aimbot_rifle_fov) {
				if (IsVisible(pLocal, pBaseEntity)) {
					//if (X::legit_aimbot_autofire) {
					//	pCmd->buttons |= IN_ATTACK;
					//}
					
					if (X::legit_aimbot_key == 0 && GetAsyncKeyState(VK_LBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 1 && GetAsyncKeyState(VK_RBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 2 && GetAsyncKeyState(VK_MBUTTON)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 3 && GetAsyncKeyState(VK_XBUTTON1)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
					else if (X::legit_aimbot_key == 4 && GetAsyncKeyState(VK_XBUTTON2)) {
						vlv->pEngine->SetViewAngles(To.Clamp());
					}
				}
			}
		}
		

	}
}

bool __stdcall hkCreateMove(float flSampleTime, CUserCmd* pCmd) {
	vlv->oCreateMove(flSampleTime, pCmd);
	if (!pCmd->command_number)
		return true;

	C_BaseEntity* pLocalEntity = (C_BaseEntity*)vlv->pEntList->GetClientEntity(vlv->pEngine->GetLocalPlayer());

	if (!pLocalEntity)
		return false;

	if (!pLocalEntity->IsValid())
		return false;

	C_BaseCombatWeapon* pWeapon = pLocalEntity->Active();

	if (!pWeapon)
		return false;

	PDWORD pEBP;
	__asm mov pEBP, ebp;
	bool& bSendPacket = *(bool*)(*pEBP - 0x1C);
	float sidemove = pCmd->sidemove;
	float forwardmove = pCmd->forwardmove;
	Vector origView = pCmd->viewangles;
	Vector viewforward, viewright, viewup, aimforward, aimright, aimup;
	Vector qAimAngles;
	qAimAngles.Init(0.0f, pCmd->viewangles.y, 0.0f);
	AngleVectors(qAimAngles, &viewforward, &viewright, &viewup);
	if (vlv->pEngine->IsConnected() && vlv->pEngine->IsInGame()) {
		MakeBhop(pCmd, pLocalEntity);
		RunCommand(pLocalEntity, pCmd);
		MakeLegitbot(pCmd, pWeapon, pLocalEntity);
		MakeAim(pLocalEntity, pCmd, pWeapon);
		MakeRecoiler(pCmd, pLocalEntity);
		MakeAntiAim(pCmd, pLocalEntity, pWeapon, bSendPacket);
		MakeTelehop(pCmd, pLocalEntity);
		SpreadFactor(pCmd, pWeapon);
		MakeNamespam();
		MakeChatspam();
		AngleVectors(qAimAngles, &viewforward, &viewright, &viewup);
		qAimAngles.Init(0.0f, pCmd->viewangles.y, 0.0f);
		AngleVectors(qAimAngles, &aimforward, &aimright, &aimup);
		Vector vForwardNorm;		AngleNormalize(viewforward, vForwardNorm);
		Vector vRightNorm;			AngleNormalize(viewright, vRightNorm);
		Vector vUpNorm;				AngleNormalize(viewup, vUpNorm);

		float forward = pCmd->forwardmove;
		float right = pCmd->sidemove;
		float up = pCmd->upmove;
		if (forward > 450) forward = 450;
		if (right > 450) right = 450;
		if (up > 450) up = 450;
		if (forward < -450) forward = -450;
		if (right < -450) right = -450;
		if (up < -450) up = -450;
		pCmd->forwardmove = DotProduct(forward * vForwardNorm, aimforward) + DotProduct(right * vRightNorm, aimforward) + DotProduct(up * vUpNorm, aimforward);
		pCmd->sidemove = DotProduct(forward * vForwardNorm, aimright) + DotProduct(right * vRightNorm, aimright) + DotProduct(up * vUpNorm, aimright);
		pCmd->upmove = DotProduct(forward * vForwardNorm, aimup) + DotProduct(right * vRightNorm, aimup) + DotProduct(up * vUpNorm, aimup);

		if (X::misc_enable && X::misc_antiuntrust) {
			pCmd->viewangles.Clamp();
		}
	}

	return false;
}

void __stdcall hkFrameStage(ClientFrameStage_t curstage) {


	C_BaseEntity* pLocalEntity = (C_BaseEntity*)vlv->pEntList->GetClientEntity(vlv->pEngine->GetLocalPlayer());

	if (!pLocalEntity)
		return;

	
	static int offset1 = offsets->m_Local + 0x64; // Visual.
	static int offset2 = offsets->m_Local + 0x70; // Punch.

	Vector* viewPunch = nullptr;
	Vector* aimPunch = nullptr;

	Vector viewPunchReal, aimPunchReal;

	if (curstage == FRAME_RENDER_START)
	{
		if (pLocalEntity && X::misc_novisrecoil)
		{
			viewPunch = (Vector*)((DWORD)pLocalEntity + offset1);
			aimPunch = (Vector*)((DWORD)pLocalEntity + offset2);

			if (viewPunch && aimPunch)
			{
				viewPunchReal = *viewPunch;
				aimPunchReal = *aimPunch;

				viewPunch->Init();
				aimPunch->Init();
			}
		}
	}

	vlv->oFrameStage(curstage);

	if (viewPunch && aimPunch) {
		if (X::misc_novisrecoil) {
			*viewPunch = viewPunchReal;
			*aimPunch = aimPunchReal;
		}
	}
}

void Source::Initialize() {
	CreateInterface engine = (CreateInterface)GetProcAddress(GetModuleHandleA("engine.dll"), "CreateInterface");
	CreateInterface client = (CreateInterface)GetProcAddress(GetModuleHandleA("client.dll"), "CreateInterface");
	CreateInterface vgui = (CreateInterface)GetProcAddress(GetModuleHandleA("vgui2.dll"), "CreateInterface");
	CreateInterface surface = (CreateInterface)GetProcAddress(GetModuleHandleA("vguimatsurface.dll"), "CreateInterface");
	CreateInterface vstdlib = (CreateInterface)GetProcAddress(GetModuleHandleA("vstdlib.dll"), "CreateInterface");
	CreateInterface vprops = (CreateInterface)GetProcAddress(GetModuleHandleA("vphysics.dll"), "CreateInterface");
	CreateInterface matsystem = (CreateInterface)GetProcAddress(GetModuleHandleA("materialsystem.dll"), "CreateInterface");

	pSurface = (ISurface*)GetInterface("VGUI_Surface", "pSurface", surface);
	pPanel = (IPanel*)GetInterface("VGUI_Panel", "pPanel", vgui);
	pEngine = (IVEngineClient*)GetInterface("VEngineClient", "pEngine", engine);
	pClient = (IBaseClientDLL*)GetInterface("VClient", "pClient", client);
	pEntList = (IClientEntityList*)GetInterface("VClientEntityList", "pEntList", client);
	pOverlay = (IVDebugOverlay*)GetInterface("VDebugOverlay", "pOverlay", engine);
	pCvar = (ICvar*)GetInterface("VEngineCvar", "pCvar", vstdlib);
	pEngineTrace = (IEngineTrace*)GetInterface("EngineTraceClient", "pEngineTrace", engine);
	pProps = (IPhysicsSurfaceProps*)GetInterface("VPhysicsSurfaceProps", "pProps", vprops);
	pModelInfo = (IVModelInfo*)GetInterface("VModelInfoClient", "pModelInfo", engine);
	pMatSystem = (IVMaterialSystem*)GetInterface("VMaterialSystem", "pMatSystem", matsystem);
	pModelRender = (IVModelRender*)GetInterface("VEngineModel", "pModelRender", engine);
	pRenderView = (IVRenderView*)GetInterface("VEngineRenderView", "pRenderView", engine);
	pPrediction = (CPrediction*)GetInterface("VClientPrediction", "pPrediction", client);
	pGameMovement = (CGameMovement*)GetInterface("GameMovement", "pGameMovement", client);


	void** BaseClient = *(void***)pClient;
	xClient = *(IBaseClientDLL***)((DWORD)BaseClient[10] + 5);

	panelhook = new CVMTHookManager((DWORD**)pPanel);
	clienthook = new CVMTHookManager(*(DWORD***)xClient);
	framerhook = new CVMTHookManager((DWORD**)pClient);
	PDWORD* predhooker = (DWORD**)pPrediction;
	predhook = new CVMTHookManager(predhooker);
	PDWORD* PWZModel = (DWORD**)pModelRender;
	modelhook = new CVMTHookManager(PWZModel);

	pInput = *(CInput**)((*(DWORD**)pClient)[15] + 0x1);
	oPaintTraverse = (tPaintTraverse)panelhook->dwHookMethod((DWORD)hkPaintTraverse, 41);
	oCreateMove = (ClientModeInternally)clienthook->dwHookMethod((DWORD)hkCreateMove, 24);
	oFrameStage = (tFrameStage)framerhook->dwHookMethod((DWORD)hkFrameStage, 36);
	oDrawModelExecute = (hkdDrawModelExecute)modelhook->dwHookMethod((DWORD)hkDrawModelExecute, 21);
//	oRunCommand = (tRunCommand)predhook->dwHookMethod((DWORD)hkdRunCommand, 19); 

	PDWORD pdwClient = (PDWORD)*(PDWORD)pClient;
	DWORD dwInitAddr = (DWORD)(pdwClient[0]);
	for (DWORD dwIter = 0; dwIter <= 0xFF; dwIter++) {
		if (*(PBYTE)(dwInitAddr + dwIter - 1) == 0x08 && *(PBYTE)(dwInitAddr + dwIter) == 0xA3) {
			pGlobals = (CGlobalVarsBase*)*(PDWORD)*(PDWORD)(dwInitAddr + dwIter + 1);
			break;
		}
	}
}

DWORD WINAPI Start(LPVOID lpdas) {
	vlv->Initialize();
	netvars->Init();
	offsets->DumpOffsets();
	return 0;
}

BOOL APIENTRY DllMain(HINSTANCE hinst, DWORD dwReason, LPVOID lpReserved) {
	if (dwReason == DLL_PROCESS_ATTACH) {
		CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)Start, NULL, NULL, NULL);
	}
	return true;
}
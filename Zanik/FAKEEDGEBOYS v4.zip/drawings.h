class Drawings {
public:
	void DrawBox(int x, int y, int w, int h, Color color);
	void FillRGBA(int x, int y, int w, int h, Color color);
	void DrawLine(int x, int y, int xx, int yy, Color color);
	void DrawString(int x, int y, Color clr, unsigned long font, const char* pszText);
	void DrawTabs(int x, int y, int w, int h, const char* szString, int& iTab, int iCount);
	void DrawParalellogram(int x, int y, int w, int h, Color color, Color outline);
	void DrawMenu(int x, int y);
	void DrawButton(int x, int y, int yPosition, const char* szString, int iCount, bool& var);
	void MakeMouse(int x, int y);
	void DrawBoxOutline(int x, int y, int w, int h, Color color);
	void DrawHealthbar(int x, int y, int w, int h, int health, Color color, Color outline);
	void DrawSlider(int x, int y, int w, float min, float max, float& value, const char* szString, int iCount);
	void DrawSliderMini(int x, int y, int w, float min, float max, float& value, const char* szString, int iCount);
	void VectorLine(Vector& start, Vector& end, Color color);
	void DrawPlayerlist(int x, int y);
	void MakeGroupBox(int x, int y, int w, int h, int wToBlur, const char* szString, Color color, Color outline);
	void MakeNotification(int x, int y, int w, int h, const char* szNotification);
	void DrawColorSpectrum(int x, int y, int w, int h);
	void DrawDropdown(int x, int y, int w, int h, int iCount, const char* szString, const char* psz[], int max, bool& toggled, int& istuffed);
	void ChangeMouse(int x, int y, int w, int h, int& iNuffed, int iCount);
	Color Drawings::GetColorFromPenPosition(Vector stx);
};

bool save = false;
bool load = false;

namespace X {
	/* Aim */
	bool aim_enable = false;
	bool aim_silent = false;
	bool aim_psilent = false;
	bool aim_autoshoot = false;
	bool aim_recoil = false;
	bool aim_autowall = false;
	bool aim_ignoreteam = true;
	bool aim_nospread = false;
	float aim_fov = 20.f;
	float aim_bone = 6.f;
	/* Visuals */
	bool esp_enable = false;
	bool esp_box = false;
	bool esp_name = false;
	bool esp_health = false;
	bool esp_chams = false;
	bool esp_boxoutline = false;
	bool esp_ignoreteam = false;
	bool esp_transparentwalls = false;
	float esp_transparentwalls_factor = 1.f;
	/* Misc */
	bool misc_enable = true;
	bool misc_bhop = false;
	bool misc_antiuntrust = true;
	bool misc_antiaim = false;
	bool misc_uselisp = false;
	bool misc_usefakedown = false;
	bool misc_walldetection = false;
	bool misc_playerlist = false;
	bool misc_nohands = false;
	bool misc_noweapons = false;
	bool misc_novisrecoil = false;
	bool misc_noflash = false;
	bool misc_nosky = false;
	bool misc_autostrafe = false;
	bool misc_useattargets = false;
	bool misc_namespam = false;
	bool misc_chatspam = false;
	/* Legit */
	bool legit_aimbot_enable = false;
	bool legit_aimbot_autofire = false;
	/* Legit - Pistol */
	bool legit_aimbot_pistol_autowall = false;
	bool legit_aimbot_pistol_recoil = false;
	float legit_aimbot_pistol_fov = 10.f;
	float legit_aimbot_pistol_speed = 5.f;
	float legit_aimbot_pistol_bone = 6.f;
	/* Legit - Rifle */
	bool legit_aimbot_rifle_autowall = false;
	bool legit_aimbot_rifle_recoil = false;
	float legit_aimbot_rifle_fov = 10.f;
	float legit_aimbot_rifle_speed = 5.f;
	float legit_aimbot_rifle_bone = 6.f;
	/* Legit - Sniper */
	bool legit_aimbot_sniper_autowall = false;
	bool legit_aimbot_sniper_recoil = false;
	float legit_aimbot_sniper_fov = 10.f;
	float legit_aimbot_sniper_speed = 5.f;
	float legit_aimbot_sniper_bone = 6.f;

	int legit_aimbot_key = 0;
	/* Options */
	float menu_color_r = 1.f;
	float menu_color_g = 0.f;
	float menu_color_b = 0.f;
	float menu_color_a = 1.f;

	


	int menu_x = 140;
	int menu_y = 140;

	int currSett = 0;
}

namespace RickAstley {
	bool menu = false;
}

namespace hands {
	float r = 255.f;
	float g = 120.f;
	float b = 0.f;

}

namespace handsVis {

	float r = 0.f;
	float g = 0.f;
	float b = 255.f;
}

namespace model_ct {
	float r = 0.f;
	float g = 0.f;
	float b = 0.f;
}

namespace model_ctVis {
	float r = 0.f;
	float g = 0.f;
	float b = 0.f;
}

namespace model_ter {
	float r = 0.f;
	float g = 0.f;
	float b = 0.f;
}

namespace model_terVis {
	float r = 0.f;
	float g = 0.f;
	float b = 0.f;
}

namespace pitchDropdown {
	bool toggled = false;
	int iFactor = 0;
}

namespace yawDropdown {
	bool toggled = false;
	int iFactor = 0;
}

namespace menuhandle {
	int w = 600, h = 310;
}

POINT cur;

unsigned long font, pfont;

void Drawings::DrawBox(int x, int y, int w, int h, Color color) {
	vlv->pSurface->DrawSetColor(color);
	vlv->pSurface->DrawOutlinedRect(x, y, x + w, y + h);
}

void Drawings::FillRGBA(int x, int y, int w, int h, Color color) {
	vlv->pSurface->DrawSetColor(color);
	vlv->pSurface->DrawFilledRect(x, y, x + w, y + h);
}

void Drawings::DrawLine(int x, int y, int xx, int yy, Color color) {
	vlv->pSurface->DrawSetColor(color);
	vlv->pSurface->DrawLine(x, y, xx, yy);
}

void Drawings::DrawString(int x, int y, Color clr, unsigned long font, const char* pszText) {
	if (pszText == NULL)
		return;
	wchar_t szString[1024] = { '\0' };
	wsprintfW(szString, L"%S", pszText);
	vlv->pSurface->DrawSetTextPos(x, y);
	vlv->pSurface->DrawSetTextFont(font);
	vlv->pSurface->DrawSetTextColor(clr);
	vlv->pSurface->DrawPrintText(szString, wcslen(szString));
}

void Drawings::DrawTabs(int x, int y, int w, int h, const char* szString, int& iTab, int iCount) {
	x += iCount * w; // Kan inte s�tta denna p� DrawParalellogram d� vi redan modifierar x axeln.
	GetCursorPos(&cur);
	static unsigned int last = 0;
	bool isActive = false;
	if ((cur.x > x) && (cur.x < x + w) && (cur.y > y) && (cur.y < y + h)) {
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000 && GetTickCount() - last > 150) {
			iTab = iCount;
		}
	}

	if (iTab == iCount) {
		isActive = true;
	}
	else {
		isActive = false;
	}

	if (!isActive) {
		this->FillRGBA(x, y, w, h, Color(17, 18, 19, 255));
	}
	else {
		this->FillRGBA(x, y, w, h, Color(20, 21, 22, 255));
		this->FillRGBA(x, y + h - 2, w, 2, Color(23, 153, 151, 255));
	}

		this->DrawString(x + 6, y + h / 2 - 8, Color::White(), pfont, szString);

}

void Drawings::DrawHealthbar(int x, int y, int w, int h, int health, Color color, Color outline) {
	UINT hw = (((w)* health) / 100);
	this->FillRGBA(x, y, w, h, Color::Black());
	this->FillRGBA(x, y, hw, h, color);
	this->DrawBox(x, y, w, h, Color::Black());
}

void Drawings::DrawButton(int x, int y, int yPosition, const char* szString, int iCount, bool& var) {
	y += iCount * 15;
	GetCursorPos(&cur);
	int w = 10, h = 10;

	int ix = x + 180;
	static unsigned int last = 0;
	if ((cur.x > yPosition) && (cur.x < yPosition + w) && (cur.y > y) && (cur.y < y + h)) {
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000 && GetTickCount() - last > 150) {
			var = !var;
			last = GetTickCount();
		}
	}
	this->DrawString(x, y, Color(255, 255, 255, 255), pfont, szString);
	this->FillRGBA(yPosition, y, w, h, var ? Color(24, 24, 24, 255) : Color(60, 60, 60, 255));
	this->DrawBox(yPosition, y, w, h, Color(30, 30, 30, 255));
}

void Drawings::VectorLine(Vector& start, Vector& end, Color color) {
	this->DrawLine(start.x, start.y, end.x, end.y, color);
}

void InitializeToggle() {
	if (GetAsyncKeyState(VK_INSERT) & 1) {
		RickAstley::menu = !RickAstley::menu;
		vlv->pEngine->ExecuteClientCmd("cl_mouseenable 1");
	}
}

void Drawings::MakeMouse(int x, int y) {
	this->FillRGBA(x + 1, y, 1, 17, Color(3, 6, 26, 255));
	for (int i = 0; i < 11; i++)
		this->FillRGBA(x + 2 + i, y + 1 + i, 1, 1, Color(3, 6, 26, 255));
	this->FillRGBA(x + 8, y + 12, 5, 1, Color(3, 6, 26, 255));
	this->FillRGBA(x + 8, y + 13, 1, 1, Color(3, 6, 26, 255));
	this->FillRGBA(x + 9, y + 14, 1, 2, Color(3, 6, 26, 255));
	this->FillRGBA(x + 10, y + 16, 1, 2, Color(3, 6, 26, 255));
	this->FillRGBA(x + 8, y + 18, 2, 1, Color(3, 6, 26, 255));
	this->FillRGBA(x + 7, y + 16, 1, 2, Color(3, 6, 26, 255));
	this->FillRGBA(x + 6, y + 14, 1, 2, Color(3, 6, 26, 255));
	this->FillRGBA(x + 5, y + 13, 1, 1, Color(3, 6, 26, 255));
	this->FillRGBA(x + 4, y + 14, 1, 1, Color(3, 6, 26, 255));
	this->FillRGBA(x + 3, y + 15, 1, 1, Color(3, 6, 26, 255));
	this->FillRGBA(x + 2, y + 16, 1, 1, Color(3, 6, 26, 255));
	for (int i = 0; i < 4; i++)
		this->FillRGBA(x + 2 + i, y + 2 + i, 1, 14 - (i * 2), Color(255 - (i * 4), 255 - (i * 4), 255 - (i * 4), 255));
	this->FillRGBA(x + 6, y + 6, 1, 8, Color(235, 235, 235, 255));
	this->FillRGBA(x + 7, y + 7, 1, 9, Color(231, 231, 231, 255));
	for (int i = 0; i < 4; i++)
		this->FillRGBA(x + 8 + i, y + 8 + i, 1, 4 - i, Color(227 - (i * 4), 227 - (i * 4), 227 - (i * 4), 255));
	this->FillRGBA(x + 8, y + 14, 1, 4, Color(207, 207, 207, 255));
	this->FillRGBA(x + 9, y + 16, 1, 2, Color(203, 203, 203, 255));
}

int CalculateMouse(int xStart, int yStart, int xEnd, int yEnd) {
	int realstart = ((1920 / 2) - (1920 / 2)) + xStart;
	return cur.x - realstart;
}


void Drawings::DrawSlider(int x, int y, int w, float min, float max, float& value, const char* szString, int iCount) {
	y += iCount * 15;
	int ix = x + 140;
	GetCursorPos(&cur);
	int yi = y + 4;

	if ((cur.x > ix) && (cur.x < ix + w) && (cur.y > yi) && (cur.y < yi + 6)) {
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
			value = CalculateMouse(ix, y, w, 20) / ((float)w / (float)(max));
		}
	}


	char valueer[255];
	sprintf(valueer, "%s:     %1.0f", szString, value);

	this->FillRGBA(ix, yi, value * ((float)w / (float)(max)), 6, Color(215, 62, 66, 255));


	this->FillRGBA(ix, yi, w, 1, Color(30, 30, 30, 255)); // First line UPPER
	this->FillRGBA(ix, yi + 5, w, 1, Color(30, 30, 30, 255)); // Second line DOWN

	this->FillRGBA(ix - 1, yi + 2, 1, 2, Color(215, 62, 66, 255));

	this->FillRGBA(ix - 1, yi + 1, 1, 1, Color(30, 30, 30, 255));
	this->FillRGBA(ix - 2, yi + 2, 1, 2, Color(30, 30, 30, 255));
	this->FillRGBA(ix - 1, yi + 4, 1, 1, Color(30, 30, 30, 255));

	this->FillRGBA(ix + w, yi + 1, 1, 1, Color(30, 30, 30, 255));
	this->FillRGBA(ix + w + 1, yi + 2, 1, 2, Color(30, 30, 30, 255));
	this->FillRGBA(ix + w, yi + 4, 1, 1, Color(30, 30, 30, 255));

	this->FillRGBA(ix + value * ((float)w / (float)(max)) - 1, yi - 3, 4, 12, Color(70, 70, 70, 255));
	this->DrawBox(ix + value * ((float)w / (float)(max)) - 1, yi - 3, 4, 12, Color::Black());

	this->DrawString(x, y, Color(255, 255, 255, 255), pfont, valueer);

}

void Drawings::DrawSliderMini(int x, int y, int w, float min, float max, float& value, const char* szString, int iCount) {
	y += iCount * 15;
	int ix = x + 90;
	GetCursorPos(&cur);
	int yi = y + 4;

	if ((cur.x > ix) && (cur.x < ix + w) && (cur.y > yi) && (cur.y < yi + 6)) {
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) {
			value = CalculateMouse(ix, y, w, 20) / ((float)w / (float)(max));
		}
	}


	char valueer[255];
	sprintf(valueer, "%s:     %1.0f", szString, value);

	this->FillRGBA(ix, yi, value * ((float)w / (float)(max)), 6, Color(215, 62, 66, 255));


	this->FillRGBA(ix, yi, w, 1, Color(30, 30, 30, 255)); // First line UPPER
	this->FillRGBA(ix, yi + 5, w, 1, Color(30, 30, 30, 255)); // Second line DOWN

	this->FillRGBA(ix - 1, yi + 2, 1, 2, Color(215, 62, 66, 255));

	this->FillRGBA(ix - 1, yi + 1, 1, 1, Color(30, 30, 30, 255));
	this->FillRGBA(ix - 2, yi + 2, 1, 2, Color(30, 30, 30, 255));
	this->FillRGBA(ix - 1, yi + 4, 1, 1, Color(30, 30, 30, 255));

	this->FillRGBA(ix + w, yi + 1, 1, 1, Color(30, 30, 30, 255));
	this->FillRGBA(ix + w + 1, yi + 2, 1, 2, Color(30, 30, 30, 255));
	this->FillRGBA(ix + w, yi + 4, 1, 1, Color(30, 30, 30, 255));

	this->FillRGBA(ix + value * ((float)w / (float)(max)) - 1, yi - 3, 4, 12, Color(70, 70, 70, 255));
	this->DrawBox(ix + value * ((float)w / (float)(max)) - 1, yi - 3, 4, 12, Color::Black());

	this->DrawString(x, y, Color(255, 255, 255, 255), pfont, valueer);

}

bool Janela[8][2];
POINT Coolio;
bool MenuMovement(int &x, int &y, int w, int h, int index) {
	//Credits: Code64/CodeRed
	for (int i = 0; i < 8; i++)
		if (Janela[i][0] && i != index)
			return false;

	POINT Cur;
	GetCursorPos(&Cur);

	if (GetAsyncKeyState(VK_LBUTTON) < 0)
	{
		if (Cur.x > (x) && Cur.x < (x) + w && Cur.y >(y) && Cur.y < (y) + h || Janela[index][0])
		{
			Janela[index][0] = true;

			if (!Janela[index][1])
			{
				Coolio.x = Cur.x - x;
				Coolio.y = Cur.y - y;
				Janela[index][1] = true;

			}
		}
		else
		{
			Janela[index][0] = false;
			Janela[index][1] = false;
		}
	}

	if (GetAsyncKeyState(VK_LBUTTON) == 0 && Janela[index][0])
	{
		Janela[index][0] = false;
		Janela[index][1] = false;
	}

	if (Janela[index][0])
	{
		x = Cur.x - Coolio.x;
		y = Cur.y - Coolio.y;
	}

	return true;

}

void Drawings::DrawBoxOutline(int x, int y, int w, int h, Color color) {
	this->DrawBox(x, y, w, h, color);
	this->DrawBox(x - 1, y - 1, w + 2, h + 2, Color(0, 0, 0, 255));
}

bool buddy[1000] = { false };
void Drawings::DrawPlayerlist(int x, int y) {
	if (!X::misc_enable)
		return;

	if (!X::misc_playerlist)
		return;

	int lister = 0;
	C_BaseEntity* pLocal = vlv->pEntList->GetClientEntity(vlv->pEngine->GetLocalPlayer());
	for (int i = 1; i < vlv->pEntList->GetHighestEntityIndex(); i++) {
		C_BaseEntity* pBaseEntity = vlv->pEntList->GetClientEntity(i);

		if (!pBaseEntity)
			continue;

		if (!pBaseEntity) {
			i = i - 1;
		}

		if (vlv->pEngine->IsConnected() && vlv->pEngine->IsInGame()) {
			if (pBaseEntity) {
				player_info_t pinfo;
				vlv->pEngine->GetPlayerInfo(i, &pinfo);
				this->DrawString(x + 4, y + 15 * i, Color(255, 255, 255, 255), pfont, pinfo.name);
				this->DrawBox(x, y + 15 * i, 120, 10, Color(0, 0, 0, 255));
				this->DrawButton(x + 50, y, 30, "Buddy", i, buddy[pBaseEntity->GetIndex()]);
			}
		}
	}
}


BOOL WritePrivateProfileInt(LPCTSTR lpAppName, LPCTSTR lpKeyName, int nInteger, LPCTSTR lpFileName) {
	TCHAR lpString[1024];
	wsprintf(lpString, "%d", nInteger);
	return WritePrivateProfileString(lpAppName, lpKeyName, lpString, lpFileName);
}

#define AquaMarine Color(7, 160, 165, 255)

void Drawings::MakeGroupBox(int x, int y, int w, int h, int wToBlur, const char* szString, Color color, Color outline) {
	this->FillRGBA(x, y, w, h, Color(31, 33, 35, 255));
	this->DrawBox(x, y, w, h, color);
	this->DrawBox(x + 1, y + 1, w - 2, h - 2, outline);
	this->FillRGBA(x + 10, y, wToBlur, 2, Color(34, 36, 39, 255));
	this->DrawString(x + 12, y - 8, Color::White(), pfont, szString);
}

namespace colorZ {
	int Width = 168;
	int Height = 179;
}

bool bNotification = false;
void Drawings::MakeNotification(int x, int y, int w, int h, const char* szNotification) {
	if (!bNotification) {
		float flTimer = GetTickCount();
		float flTimerCounted = 255 - flTimer / 20.f;
		this->FillRGBA(x, y, w, h, Color(34, 36, 39, flTimerCounted));
		this->FillRGBA(x, y, w, 30, Color(23, 26, 28, flTimerCounted));
		this->FillRGBA(x, y + 30, w, 2, Color(255, 88, 87, flTimerCounted));
		this->DrawString(x + 5, y + 8, Color(255, 255, 255, flTimerCounted), pfont, szNotification);
		this->DrawString(x + 15, y + 50, Color(255, 255, 255, flTimerCounted), pfont, "Hit insert for menu!");
		this->DrawString(x + 15, y + 60, Color(255, 255, 255, flTimerCounted), pfont, "Im fading away!");
		if (flTimerCounted < 2.f) {
			bNotification = true;
		}
	}
}

void Drawings::ChangeMouse(int x, int y, int w, int h, int& iNuffed, int iCount) {
	y += iCount * 15;
	int xy = x + 70;
	GetCursorPos(&cur);
	static UINT last = 0;

	this->FillRGBA(xy, y, w, h, Color(24, 24, 24, 255)); // After

	if ((cur.x > xy) && (cur.x < xy + w) && (cur.y > y) && (cur.y < y + h)) {
		this->FillRGBA(xy, y, w, h, Color(28, 28, 28, 255)); // Before
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000 && GetTickCount() - last > 150) {
			iNuffed = 0;
			last = GetTickCount();
		}
		if (GetAsyncKeyState(VK_RBUTTON) & 0x8000 && GetTickCount() - last > 150) {
			iNuffed = 1;
			last = GetTickCount();
		}
		if (GetAsyncKeyState(VK_MBUTTON) & 0x8000 && GetTickCount() - last > 150) {
			iNuffed = 2;
			last = GetTickCount();
		}
		if (GetAsyncKeyState(VK_XBUTTON1) & 0x8000 && GetTickCount() - last > 150) {
			iNuffed = 3;
			last = GetTickCount();
		}
		if (GetAsyncKeyState(VK_XBUTTON2) & 0x8000 && GetTickCount() - last > 150) {
			iNuffed = 4;
			last = GetTickCount();
		}
	}

	
	this->DrawBox(xy, y, w, h, Color::Black());

	if (iNuffed == 0) {
		this->DrawString(xy + 2, y + 2, Color::White(), pfont, "Mouse 1");
	}
	if (iNuffed == 1) {
		this->DrawString(xy + 2, y + 2, Color::White(), pfont, "Mouse 2");
	}
	if (iNuffed == 2) {
		this->DrawString(xy + 2, y + 2, Color::White(), pfont, "Mouse 3");
	}
	if (iNuffed == 3) {
		this->DrawString(xy + 2, y + 2, Color::White(), pfont, "Mouse 4");
	}
	if (iNuffed == 4) {
		this->DrawString(xy + 2, y + 2, Color::White(), pfont, "Mouse 5");
	}
	this->DrawString(x, y + 2, Color::White(), pfont, "Key");
}

Color Drawings::GetColorFromPenPosition(Vector stx)
{
	int div = colorZ::Width / 6;
	int phase = stx.x / div;
	float t = ((int)stx.x % div) / (float)div;
	int r, g, b;

	switch (phase)
	{
	case(0):
		r = 255;
		g = 255 * t;
		b = 0;
		break;
	case(1):
		r = 255 * (1.f - t);
		g = 255;
		b = 0;
		break;
	case(2):
		r = 0;
		g = 255;
		b = 255 * t;
		break;
	case(3):
		r = 0;
		g = 255 * (1.f - t);
		b = 255;
		break;
	case(4):
		r = 255 * t;
		g = 0;
		b = 255;
		break;
	case(5):
		r = 255;
		g = 0;
		b = 255 * (1.f - t);
		break;
	}

	float sat = stx.y / colorZ::Height;
	return Color(r + sat * (128 - r), g + sat * (128 - g), b + sat * (128 - b));
}

Vector GetMouse(int x, int y) {
	return Vector(x, y, 0);
}

void Drawings::DrawColorSpectrum(int x, int y, int w, int h) {
	static int GradientTexture = 0;
	static std::unique_ptr<Color[]> Gradient = nullptr;
	if (!Gradient)
	{
		Gradient = std::make_unique<Color[]>(w * h);

		for (int i = 0; i < w; i++)
		{
			int div = w / 6;
			int phase = i / div;
			float t = (i % div) / (float)div;
			int r, g, b;

			switch (phase)
			{
			case(0):
				r = 255;
				g = 255 * t;
				b = 0;
				break;
			case(1):
				r = 255 * (1.f - t);
				g = 255;
				b = 0;
				break;
			case(2):
				r = 0;
				g = 255;
				b = 255 * t;
				break;
			case(3):
				r = 0;
				g = 255 * (1.f - t);
				b = 255;
				break;
			case(4):
				r = 255 * t;
				g = 0;
				b = 255;
				break;
			case(5):
				r = 255;
				g = 0;
				b = 255 * (1.f - t);
				break;
			}

			for (int k = 0; k < h; k++)
			{
				float sat = k / (float)h;
				int _r = r + sat * (128 - r);
				int _g = g + sat * (128 - g);
				int _b = b + sat * (128 - b);

				*reinterpret_cast<Color*>(Gradient.get() + i + k * w) = Color(_r, _g, _b);
			}
		}

		GradientTexture = vlv->pSurface->CreateNewTextureID(true);
		vlv->pSurface->DrawSetTextureRGBA(GradientTexture, (unsigned char*)Gradient.get(), w, h);
	}
	vlv->pSurface->DrawSetColor(Color(255, 255, 255, 255));
	vlv->pSurface->DrawSetTexture(GradientTexture);
	vlv->pSurface->DrawTexturedRect(x, y, x + w, y + h);

	Vector stx;

	stx.x = cur.x;
	stx.y = cur.y;
	if((cur.x > x) && (cur.x < x + w) && (cur.y > y) && (cur.y < y + h)) {
		this->FillRGBA(x, y + h + 20, 30, 30, this->GetColorFromPenPosition(GetMouse(cur.x, cur.y)));
	}
	this->DrawBox(x, y + h + 20, 30, 30, Color::Black());
}

const char* PitchAntiaims[5] = {
	"Off", // 0
	"Emotion", // 1
	"Upp (!)", // 3
	"Fakedown (!)" // 4
};

const char* YawAntiaims[4] = {
	"Off", // 0
	"Backwards", // 1
	"Sideways", // 2
	"Jitter" // 3
};

const char* nameSpammer[4] = {
	"BIG HAKE",
	".BIG HAKE",
	"BIG HAKE",
	".BIG HAKE"
};

const char* chatSpammer[6] = {
	"Get good with BIG HAKE",
	"rekt by BIG HAKE",
	"VAC Undetected CS:GO cheat, at BIG HAKE",
	"BIG HAKE | CS:GO Cheat, Rage / Legit",
	"We are BIG HAKE guys, come join the force!",
	"Use source luke! ~ BIG HAKE"
};

void Drawings::DrawDropdown(int x, int y, int w, int h, int iCount, const char* szString, const char * psz[], int max, bool& toggled, int& istuffed) {
	y += iCount * 15;
	int xx = x + 150;
	GetCursorPos(&cur);
	static UINT last = 0;
	if ((cur.x > xx) && (cur.x < xx + w) && (cur.y > y) && (cur.y < y + h)) {
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000 && GetTickCount() - last > 150) {
			toggled = !toggled;
			last = GetTickCount();
		}
	}

	if (toggled) {
		this->FillRGBA(xx, y, w, h, Color(24, 24, 24, 255));
		this->DrawBox(xx, y, w, h, Color::Black());
		this->DrawString(xx + 2, y + 2, Color::White(), pfont, psz[istuffed]);
		for (int i = 0; i < max; i++) {
			int newY = y + h * i + h;

			this->FillRGBA(xx, newY, w, h, Color(28, 28, 28, 255));
			if ((cur.x > xx) && (cur.x < xx + w) && (cur.y > newY) && (cur.y < newY + h)) {
				this->FillRGBA(xx, newY, w, h, Color(30, 30, 30, 255));
				if (GetAsyncKeyState(VK_LBUTTON) & 1) {
					toggled = false;
					istuffed = i;
				}
			}

			
			this->DrawBox(xx, newY, w, h, Color::Black());
			this->DrawString(xx + 2, newY, Color::White(), pfont, psz[i]);
		}
	}
	else {
		this->FillRGBA(xx, y, w, h, Color(24, 24, 24, 255));
		this->DrawBox(xx, y, w, h, Color::Black());
		this->DrawString(xx + 2, y + 2, Color::White(), pfont, psz[istuffed]);
	}

	if (!(cur.x > xx) || !(cur.x < xx + w) || !(cur.y > y)) {
		if (GetAsyncKeyState(VK_LBUTTON) & 0x8000 && GetTickCount() - last > 150) {
			toggled = false;
		}
	}
	this->DrawString(x, y + 2, Color::White(), pfont, szString);

}

int iTab = 0;
int iColors = 0;
void Drawings::DrawMenu(int x, int y) {
	
	int w = menuhandle::w, h = menuhandle::h;
	
	this->FillRGBA(x, y, w, h, Color(34, 36, 39, 255));
	this->FillRGBA(x, y, w, 30, Color(23, 26, 28, 255));
	this->FillRGBA(x, y + 30, w, 2, Color(255, 88, 87, 255));
	this->DrawString(x + 5, y + 8, Color::White(), pfont, "HvH.Academy | Alpah");

	this->DrawTabs(x, y + 32, 100, 30, "Rage", iTab, 0);
	this->DrawTabs(x, y + 32, 100, 30, "Legit", iTab, 1);
	this->DrawTabs(x, y + 32, 100, 30, "Visuals", iTab, 2);
	this->DrawTabs(x, y + 32, 100, 30, "Misc", iTab, 3);
	this->DrawTabs(x, y + 32, 100, 30, "Config", iTab, 4);
	this->DrawTabs(x, y + 32, 100, 30, "Colors", iTab, 5);

	if (iTab == 0) {	// Rage							 
		this->MakeGroupBox(x + 20, y + 80, 290, 200, 44, "Aimbot", Color::White(), Color(255, 255, 255, 40));
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Enable", 0, X::aim_enable);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Silent", 1, X::aim_silent);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Auto Fire", 2, X::aim_autoshoot);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Auto Wall", 3, X::aim_autowall);
		this->DrawSlider(x + 25, y + 95, 140, 0.f, 181.f, X::aim_fov, "Field Of View", 4);
		this->DrawSlider(x + 25, y + 95, 140, 0.f, 10.f, X::aim_bone, "Hitbone", 5);

		this->MakeGroupBox(x + 20 + 300, y + 80, 260, 200, 54, "Accuracy", Color::White(), Color(255, 255, 255, 40));
		this->DrawButton(x + 25 + 300, y + 95, x + 25 + 300 + 240, "No Recoil", 0, X::aim_recoil);
		this->DrawButton(x + 25 + 300, y + 95, x + 25 + 300 + 240, "No Spread", 1, X::aim_nospread);
		// x + 25 + 300 + 255, really nigga..
	}

	if (iTab == 1) { // Legit
		this->MakeGroupBox(x + 20, y + 80, 180, 95, 44, "Aimbot", Color::White(), Color(255, 255, 255, 40));
		this->DrawButton(x + 25, y + 95, x + 25 + 160, "Enable", 0, X::legit_aimbot_enable);
		this->DrawButton(x + 25, y + 95, x + 25 + 160, "Auto Fire", 1, X::legit_aimbot_autofire);
		this->ChangeMouse(x + 25, y + 95, 100, 20, X::legit_aimbot_key, 2);

		// Pistol
		this->MakeGroupBox(x + 20, y + 180, 180, 95, 44, "Pistol", Color::White(), Color(255, 255, 255, 40));
		this->DrawButton(x + 25, y + 195, x + 25 + 160, "Recoil", 0, X::legit_aimbot_pistol_recoil);
		this->DrawButton(x + 25, y + 195, x + 25 + 160, "Auto Wall", 1, X::legit_aimbot_pistol_autowall);
		this->DrawSliderMini(x + 25, y + 195, 70, 0.f, 30.f, X::legit_aimbot_pistol_fov, "Fov", 2);
		this->DrawSliderMini(x + 25, y + 195, 70, 0.f, 20.f, X::legit_aimbot_pistol_speed, "Speed", 3);
		this->DrawSliderMini(x + 25, y + 195, 70, 0.f, 10.f, X::legit_aimbot_pistol_bone, "Bone", 4);

		// Rifle
		this->MakeGroupBox(x + 20 + 200, y + 80, 180, 95, 44, "Rifle", Color::White(), Color(255, 255, 255, 40));
		this->DrawButton(x + 25 + 200, y + 95, x + 25 + 360, "Recoil", 0, X::legit_aimbot_rifle_recoil);
		this->DrawButton(x + 25 + 200, y + 95, x + 25 + 360, "Auto Wall", 1, X::legit_aimbot_rifle_autowall);
		this->DrawSliderMini(x + 25 + 200, y + 95, 70, 0.f, 30.f, X::legit_aimbot_rifle_fov, "Fov", 2);
		this->DrawSliderMini(x + 25 + 200, y + 95, 70, 0.f, 20.f, X::legit_aimbot_rifle_speed, "Speed", 3);
		this->DrawSliderMini(x + 25 + 200, y + 95, 70, 0.f, 10.f, X::legit_aimbot_rifle_bone, "Bone", 4);

		// Sniper
		this->MakeGroupBox(x + 20 + 200, y + 180, 180, 95, 44, "Sniper", Color::White(), Color(255, 255, 255, 40));
		this->DrawButton(x + 25 + 200, y + 195, x + 25 + 360, "Recoil", 0, X::legit_aimbot_sniper_recoil);
		this->DrawButton(x + 25 + 200, y + 195, x + 25 + 360, "Auto Wall", 1, X::legit_aimbot_sniper_autowall);
		this->DrawSliderMini(x + 25 + 200, y + 195, 70, 0.f, 30.f, X::legit_aimbot_sniper_fov, "Fov", 2);
		this->DrawSliderMini(x + 25 + 200, y + 195, 70, 0.f, 20.f, X::legit_aimbot_sniper_speed, "Speed", 3);
		this->DrawSliderMini(x + 25 + 200, y + 195, 70, 0.f, 10.f, X::legit_aimbot_sniper_bone, "Bone", 4);
	}

	if (iTab == 2) { // Visuals	
		this->MakeGroupBox(x + 20, y + 80, w - 40, 200, 46, "Players", Color::White(), Color(255, 255, 255, 40));
		this->DrawButton(x + 25, y + 95, x + 25 + w - 60, "Enable", 0, X::esp_enable);
		this->DrawButton(x + 25, y + 95, x + 25 + w - 60, "Box", 1, X::esp_box);
		this->DrawButton(x + 25, y + 95, x + 25 + w - 60, "Outline", 2, X::esp_boxoutline);
		this->DrawButton(x + 25, y + 95, x + 25 + w - 60, "Name", 3, X::esp_name);
		this->DrawButton(x + 25, y + 95, x + 25 + w - 60, "Health", 4, X::esp_health);
		this->DrawButton(x + 25, y + 95, x + 25 + w - 60, "Chams", 5, X::esp_chams);
		this->DrawButton(x + 25, y + 95, x + 25 + w - 60, "Asus Walls", 6, X::esp_transparentwalls);
		this->DrawSlider(x + 25, y + 95, w - 195, 0.f, 1.f, X::esp_transparentwalls_factor, "Asus Factor", 7);
		this->DrawButton(x + 25, y + 95, x + 25 + w - 60, "Ignore Team", 8, X::esp_ignoreteam);
	}

	if (iTab == 3) { // Misc
		this->MakeGroupBox(x + 20, y + 80, 290, 200, 42, "Others", Color::White(), Color(255, 255, 255, 40));

		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Enable", 0, X::misc_enable);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Bunny Hop", 1, X::misc_bhop);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "No Visual Recoil", 2, X::misc_novisrecoil);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "No Sky", 3, X::misc_nosky);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "No Weapons", 4, X::misc_noweapons);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "No Flash", 5, X::misc_noflash);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Hand Chams", 6, X::misc_nohands);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Name spam", 7, X::misc_namespam);
		this->DrawButton(x + 25, y + 95, x + 25 + 270, "Chat spam", 8, X::misc_chatspam);
		
		

		this->MakeGroupBox(x + 20 + 300, y + 80, 260, 200, 52, "Anti Aim", Color::White(), Color(255, 255, 255, 40));

		this->DrawButton(x + 25 + 300, y + 95, x + 25 + 300 + 240, "Enable", 0, X::misc_antiaim);

		
			this->DrawDropdown(x + 25 + 300, y + 95, 100, 20, 2, "X", PitchAntiaims, 4, pitchDropdown::toggled, pitchDropdown::iFactor);

			this->DrawDropdown(x + 25 + 300, y + 95, 100, 20, 5, "Y", YawAntiaims, 4, yawDropdown::toggled, yawDropdown::iFactor);
		
	}

	if (iTab == 4) { // Config
		this->DrawString(x + 20, y + 80, Color::White(), pfont, "Rip zanik...");
		this->DrawString(x + 20, y + 100, Color::White(), pfont, "Regards -Zanik.");
	}

	if (iTab == 5) { // Colors
		this->DrawTabs(x, y + 64, 150, 30, "Counter-Terrorist", iColors, 0);
		this->DrawTabs(x, y + 64, 150, 30, "Terrorist", iColors, 1);
		this->DrawTabs(x, y + 64, 150, 30, "Hands", iColors, 2);
		this->DrawTabs(x, y + 64, 150, 30, "Boxes", iColors, 3);

		if (iColors == 0) {
			this->MakeGroupBox(x + 20, y + 105, 290, 180, 44, "Visible", Color::White(), Color(255, 255, 255, 40));
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, model_ctVis::r, "Red", 0);
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, model_ctVis::g, "Green", 1);
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, model_ctVis::b, "Blue", 2);

			this->FillRGBA(x + 25, y + 190, 100, 20, Color(model_ctVis::r, model_ctVis::g, model_ctVis::b, 255));
			this->DrawBox(x + 25, y + 190, 100, 20, Color::Black());

			this->MakeGroupBox(x + 20 + 300, y + 105, 260, 180, 50, "Invisible", Color::White(), Color(255, 255, 255, 40));
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, model_ct::r, "Red", 0);
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, model_ct::g, "Green", 1);
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, model_ct::b, "Blue", 2);

			this->FillRGBA(x + 25 + 300, y + 190, 100, 20, Color(model_ct::r, model_ct::g, model_ct::b, 255));
			this->DrawBox(x + 25 + 300, y + 190, 100, 20, Color::Black());
		}

		if (iColors == 1) {
			this->MakeGroupBox(x + 20, y + 105, 290, 180, 44, "Visible", Color::White(), Color(255, 255, 255, 40));
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, model_terVis::r, "Red", 0);
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, model_terVis::g, "Green", 1);
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, model_terVis::b, "Blue", 2);

			this->FillRGBA(x + 25, y + 190, 100, 20, Color(model_terVis::r, model_terVis::g, model_terVis::b, 255));
			this->DrawBox(x + 25, y + 190, 100, 20, Color::Black());

			this->MakeGroupBox(x + 20 + 300, y + 105, 260, 180, 50, "Invisible", Color::White(), Color(255, 255, 255, 40));
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, model_ter::r, "Red", 0);
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, model_ter::g, "Green", 1);
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, model_ter::b, "Blue", 2);

			this->FillRGBA(x + 25 + 300, y + 190, 100, 20, Color(model_ter::r, model_ter::g, model_ter::b, 255));
			this->DrawBox(x + 25 + 300, y + 190, 100, 20, Color::Black());
		}

		if (iColors == 2) {
			this->MakeGroupBox(x + 20, y + 105, 290, 180, 44, "Visible", Color::White(), Color(255, 255, 255, 40));
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, handsVis::r, "Red", 0);
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, handsVis::g, "Green", 1);
			this->DrawSlider(x + 25, y + 115, 140, -6.f, 257.f, handsVis::b, "Blue", 2);

			this->FillRGBA(x + 25, y + 190, 100, 20, Color(handsVis::r, handsVis::g, handsVis::b, 255));
			this->DrawBox(x + 25, y + 190, 100, 20, Color::Black());

			this->MakeGroupBox(x + 20 + 300, y + 105, 260, 180, 50, "Invisible", Color::White(), Color(255, 255, 255, 40));
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, hands::r, "Red", 0);
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, hands::g, "Green", 1);
			this->DrawSlider(x + 25 + 300, y + 115, 100, -6.f, 258.f, hands::b, "Blue", 2);

			this->FillRGBA(x + 25 + 300, y + 190, 100, 20, Color(hands::r, hands::g, hands::b, 255));
			this->DrawBox(x + 25 + 300, y + 190, 100, 20, Color::Black());
		}
		
	}



	MenuMovement(X::menu_x, X::menu_y, w, 30, 0);
}


extern Drawings* Draw;
Drawings* Draw = new Drawings();


#include "main.h"
#include "pattern_scan.h"
void NetWorkedOffsets::DumpOffsets() {
	this->m_iHealth = netvars->getOffset("DT_BasePlayer", "m_iHealth");
	this->m_iClip1 = netvars->getOffset("DT_BaseCombatWeapon", "m_iClip1");
	this->m_iClip2 = netvars->getOffset("DT_BaseCombatWeapon", "m_iPrimaryReserveAmmoCount");
	this->m_bIsDefusing = netvars->getOffset("DT_CSPlayer", "m_bIsDefusing");
	this->m_lifeState = netvars->getOffset("DT_BasePlayer", "m_lifeState");
	this->m_iTeamNum = netvars->getOffset("DT_BaseEntity", "m_iTeamNum");
	this->m_fFlags = netvars->getOffset("DT_BasePlayer", "m_fFlags");
	this->m_hOwnerEntity = netvars->getOffset("DT_BaseEntity", "m_hOwnerEntity");
	this->m_flFlashDuration = netvars->getOffset("DT_CSPlayer", "m_flFlashDuration");
	this->m_flFlashMaxAlpha = netvars->getOffset("DT_CSPlayer", "m_flFlashMaxAlpha");
	this->m_CurrentStage = netvars->getOffset("DT_ParticleSmokeGrenade", "m_CurrentStage");
	this->m_ArmorValue = netvars->getOffset("DT_CSPlayer", "m_ArmorValue");
	this->m_bGunGameImmunity = netvars->getOffset("DT_CSPlayer", "m_bGunGameImmunity");
	this->m_punch = netvars->getOffset("DT_BasePlayer", "m_aimPunchAngle");
	this->m_visualpunch = netvars->getOffset("DT_BasePlayer", "m_viewPunchAngle");
	this->m_Local = netvars->getOffset("DT_BasePlayer", "m_Local");
	this->ForceBone = netvars->getOffset("DT_BaseAnimating", "m_nForceBone");
	this->MoveMent = netvars->getOffset("DT_CSPlayer", "m_bIsWalking");
	this->isScoped = netvars->getOffset("DT_CSPlayer", "m_bIsScoped");
	this->m_kit1 = netvars->getOffset("DT_EconEntity", "m_nFallbackPaintKit");
	this->m_CollisionGroup = netvars->getOffset("DT_BaseEntity", "m_CollisionGroup");
	this->m_Collision = netvars->getOffset("DT_BaseEntity", "m_Collision");
	this->m_iKills = netvars->getOffset("DT_CSPlayerResource", "m_iKills");
	this->m_movetype = netvars->getOffset("DT_BaseToggle", "m_movementType");
	this->m_nTickBase = netvars->getOffset("DT_BasePlayer", "m_nTickBase");
	this->m_flNextPrimaryAttack = netvars->getOffset("DT_BaseCombatWeapon", "m_flNextPrimaryAttack");
	this->m_bHasHelmet = netvars->getOffset("DT_CSPlayer", "m_bHasHelmet");
	this->m_hActiveWeapon = netvars->getOffset("DT_BaseCombatCharacter", "m_hActiveWeapon");
	this->dwiItemIDHigh = netvars->getOffset("DT_BaseCombatWeapon", "m_iItemIDHigh");
	this->dwiItemIDLow = netvars->getOffset("DT_BaseCombatWeapon", "m_iItemIDLow");
	this->dwOrigOwnerHigh = netvars->getOffset("DT_BaseCombatWeapon", "m_OriginalOwnerXuidHigh");
	this->dwOrigOwnerLow = netvars->getOffset("DT_BaseCombatWeapon", "m_OriginalOwnerXuidLow");
	this->dwiFallbackPaintKit = netvars->getOffset("DT_BaseCombatWeapon", "m_nFallbackPaintKit");
	this->dwiFallbackSeed = netvars->getOffset("DT_BaseCombatWeapon", "m_nFallbackSeed");
	this->dwflFallbackWear = netvars->getOffset("DT_BaseCombatWeapon", "m_flFallbackWear");
	this->dwiFallbackStatTrak = netvars->getOffset("DT_BaseCombatWeapon", "m_nFallbackStatTrak");
	this->dwszCustomName = netvars->getOffset("DT_BaseCombatWeapon", "m_szCustomName");
	this->m_iObserveTarget = netvars->getOffset("DT_BasePlayer", "m_hObserverTarget");
	this->m_iEyeAngles = netvars->getOffset("DT_CSPlayer", "m_angEyeAngles[0]");

	this->LoadFromBufferEx = FindPattern(strenc("client.dll"), strenc("55 8B EC 83 E4 F8 83 EC 34 53 8B 5D 0C 89 4C 24 04"));
	this->InitKeyValuesEx = FindPattern(strenc("client.dll"), strenc("55 8B EC 51 33 C0 C7 45"));
	this->LoadClanTagEx = FindPattern(strenc("engine.dll"), strenc("53 56 57 8B DA 8B F9 FF 15 ? ? ? ? 6A 24 8B C8 8B 30"));
}

NetWorkedOffsets* offsets = new NetWorkedOffsets();
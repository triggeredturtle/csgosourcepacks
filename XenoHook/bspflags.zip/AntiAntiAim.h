#pragma once

void ApplyAAAHooks();
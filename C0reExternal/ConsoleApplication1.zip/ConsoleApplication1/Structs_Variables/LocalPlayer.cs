﻿namespace ExternalBase.C0re.Structs_Variables
{
    struct LocalPlayer
    {
        public static int Base;
        public static int Team;
        public static int ClientState;
        public static int GlowBase;
        public static int JumpFlags;
    }
}

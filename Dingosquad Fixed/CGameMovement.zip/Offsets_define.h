;CSGO Custom OffsetDumper v1.0
;Last Update Offsets: Fri May 26 11:41:32 2017
[Offsets]
#define m_dwLocalPlayer 0xAA8FBC
#define m_bSpotted 0x939
#define m_dwIndex 0x64

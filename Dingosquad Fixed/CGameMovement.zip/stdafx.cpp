#include "stdafx.h"
CInterfaces Interfaces;
CUtils Utils;
int apple = 0;
#pragma once

extern bool DoesHWIDMatch();
extern bool jakeschecks();
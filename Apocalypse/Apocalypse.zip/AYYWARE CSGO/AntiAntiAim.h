/*
Rest In Peace ApocalypseCheats
*/

// Credits to Valve and Shad0w
#pragma once

extern bool islbyupdate;
extern float ProxyLBYtime;
extern float enemysLastProxyTimer[65];

void ApplyAAAHooks();
#pragma once

#include "../SDK/SDK.h"
#include "../interfaces.h"
#include "../settings.h"

namespace Noflash
{
	void FrameStageNotify(ClientFrameStage_t stage);
}

#pragma once

#include "../settings.h"
#include "../SDK/SDK.h"
#include "../interfaces.h"
#include "../Hooks/hooks.h"
#include "../Utils/util.h"

namespace FakeLag
{
	void CreateMove(CUserCmd* cmd);
};

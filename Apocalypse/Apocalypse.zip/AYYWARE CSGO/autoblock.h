#pragma once

#include <climits>
#include "../settings.h"
#include "../SDK/SDK.h"
#include "../interfaces.h"

namespace Autoblock
{
	void CreateMove(CUserCmd* cmd);
}

/*
Syn's Apocalypse Framework
*/

#pragma once

#define Apocalypse_META_GAME "Counter-Strike: Global Offensive"
#define Apocalypse_META_CHEATVER "0.7"
#define Apocalypse_META_CHEATNAME "Apocalypse for Counter-Strike: Global Offensive"

void PrintMetaHeader();
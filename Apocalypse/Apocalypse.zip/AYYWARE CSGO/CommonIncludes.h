/*
Rest In Peace ApocalypseCheats
*/

#pragma once
#define _WINSOCKAPI_

// Includes
#include <Windows.h>
#include <cstdlib>
#include <cstdio>
#include <math.h>
#include <string>
#include <conio.h>
#include <vector>

#include "MetaInfo.h"
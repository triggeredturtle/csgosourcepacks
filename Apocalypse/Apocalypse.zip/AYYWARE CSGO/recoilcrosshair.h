#pragma once

#include "../settings.h"
#include "../SDK/SDK.h"
#include "../Utils/draw.h"
#include "../interfaces.h"

namespace Recoilcrosshair
{
	void Paint();
};

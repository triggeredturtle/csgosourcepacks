﻿/*
AyyWare 2 - Extreme Alien Technology
By Syn
*/

#include "Menu.h"
#include "Controls.h"
#include "DLLMain.h"
#include "Valve/CRC32.h"
#include "Hooks.h"
AyyWareWindow Menu::Window;

void UpdatePlayerList();

std::map<DWORD, PlayerListItem_t> PlayerList;
void UnL()
{
	DoUnload = true;
}
void Menu::DoFrame()
{
	GUI.Update();
	GUI.Draw();

	UpdatePlayerList();
	if (Menu::Window.MiscTab.Unload.GetState())
		UnL();
}


void Menu::Initialize()
{
	Window.Setup();

	GUI.RegisterWindow(&Window);
	GUI.BindWindow(VK_INSERT, &Window);
	
	//Menu::Window.SetConfigFile(Menu::Window.SettingsFile.GetItem());
	//GUI.LoadWindowState(&Window, Window.SettingsFile.GetItem());

	Utilities::Log("Menu: Loaded");

}

//-------------------------------------------------------------

void ReloadSettings(void)
{
	Menu::Window.SaveToCurrentConfig();
	Menu::Window.SetConfigFile(Menu::Window.SettingsFile.GetItem());
	GUI.LoadWindowState(&Menu::Window, Menu::Window.SettingsFile.GetItem());
}

void AyyWareWindow::Setup()
{
	SetPosition(50, 50);
	SetTitle("AYYWARE 2.0 For Counter-Strike: Global Offensive");

	SetSize(900, 550);
	EnableTabs(true);

	RegisterTab(&RageBotTab);
	RegisterTab(&LegitBotTab);
	RegisterTab(&VisualsTab);
	RegisterTab(&MiscTab);
	RegisterTab(&PlayersTab);
	RegisterTab(&HvHTab);

	SettingsFile.AddItem("OFF");
	SettingsFile.AddItem("Legit");
	SettingsFile.AddItem("Rage");
	SettingsFile.SetPosition(-180, 420);
	SettingsFile.SetSize(160, 16);
	SettingsFile.SetEventItemSelect(&ReloadSettings);

	char userBuffer[120];

		sprintf_s(userBuffer, "Logged in as SynRaw");

	UserLabel.SetText(userBuffer);
	UserLabel.SetPosition(-180, 435);
	
	Radar->SetPosition(250, 250);
	Radar->SetSize(200, 200);
	Radar->SetTitle("    Radar");
	RageBotTab.Setup();
	LegitBotTab.Setup();
	VisualsTab.Setup();
	MiscTab.Setup();
	PlayersTab.Setup();
	HvHTab.Setup();
	
}

void CRageTab::Setup()
{
	SetTitle("RageBot");
	
	grpAimbot.SetPosition(10, 10);
	grpAimbot.SetSize(680, 50);
	grpAimbot.SetText("AIMBOT");
	grpAimbot.SetColumns(1);
	RegisterControl(&grpAimbot);

	RegisterControl(&Menu::Window.SettingsFile);
	RegisterControl(&Menu::Window.UserLabel);
	
	//grpAimbot.PlaceLabledControl("UnLoad Cheat", this, &Unload, 0, -1);
	
	grpAimbot.PlaceLabledControl("Enable", this, &AimbotEnable, 0, 0);
	grpAimbot.PlaceLabledControl("Auto Shoot", this, &AimbotAutoFire, 0, 1);
	AimbotFov.SetBoundaries(0.1f, 180.f); AimbotFov.SetValue(0.98f);
	grpAimbot.PlaceLabledControl("FoV Value", this, &AimbotFov, 0, 2);
	AimbotSilentAim.AddItem("Normal");
	AimbotSilentAim.AddItem("Slient");
	AimbotSilentAim.AddItem("p$ilent");
	grpAimbot.PlaceLabledControl("Aim Mode", this, &AimbotSilentAim, 0, 3);
	grpAimbot.PlaceLabledControl("Auto-Pistol", this, &AimbotAutoPistol, 0, 4);
	grpAimbot.PlaceLabledControl("Activate on Key", this, &AimbotKeyPress, 0, 5);
	grpAimbot.PlaceLabledControl("Key Bind", this, &AimbotKeyBind, 0, 6);
	grpAimbot.PlaceLabledControl("Engine Prediction", this, &OtherEnginePrediction, 0, 7);

	grpTarget.SetPosition(10, GetNextGroupboxY(&grpAimbot));
	grpTarget.SetSize(680, 65);
	grpTarget.SetText("Targetting");
	grpTarget.SetColumns(2);
	RegisterControl(&grpTarget);

	TargetSelection.AddItem("CrossHair");
	TargetSelection.AddItem("Distance");
	TargetSelection.AddItem("Lowest HP");
	grpTarget.PlaceLabledControl("Selection Type", this, &TargetSelection, 0, 0);

	grpTarget.PlaceLabledControl("Friendly Fire", this, &TargetFriendlyFire, 1, 0);
	TargetHitbox.AddItem("Head");
	TargetHitbox.AddItem("Neck");
	TargetHitbox.AddItem("Chest");
	TargetHitbox.AddItem("Stomach");
	grpTarget.PlaceLabledControl("HitBox", this, &TargetHitbox, 0, 1);
	TargetHitscan.AddItem("Off"); //0
	TargetHitscan.AddItem("Low"); // 1
	TargetHitscan.AddItem("Medium"); // 2
	TargetHitscan.AddItem("High"); // 3
	grpTarget.PlaceLabledControl("MultiBox", this, &TargetHitscan, 1, 1);
	TargetMultiPoint.AddItem("OFF"); // 1
	TargetMultiPoint.AddItem("ON"); // 2
	grpTarget.PlaceLabledControl("MultiPoint", this, &TargetMultiPoint, 0, 2);
	TargetPointScale.SetBoundaries(0.01f, 1.f); TargetPointScale.SetValue(0.50f);
	grpTarget.PlaceLabledControl("PointScale", this, &TargetPointScale, 1, 2);
	grpAccuracy.SetPosition(10, GetNextGroupboxY(&grpTarget));
	grpAccuracy.SetSize(680, 53);
	grpAccuracy.SetText("Accuracy");
	grpAccuracy.SetColumns(1);
	RegisterControl(&grpAccuracy);

	grpAccuracy.PlaceLabledControl("No-Recoil", this, &AccuracyRecoil, 0, 0);
	grpAccuracy.PlaceLabledControl("Pitch Resolver", this, &AccuracyResolver, 0, 1);
	grpAccuracy.PlaceLabledControl("Yaw Resolver", this, &AccuracyResolverYaw, 0, 2);
	grpAccuracy.PlaceLabledControl("Auto-Wall", this, &AccuracyAutoWall, 0, 3);
	grpAccuracy.PlaceLabledControl("Auto-Crouch", this, &AccuracyAutoCrouch, 0, 4);
	//grpAccuracy.PlaceLabledControl("Auto-Stop", this, &AccuracyAutoStop, 0, 5);
	grpAccuracy.PlaceLabledControl("Auto-Scope", this, &AccuracyAutoScope, 0, 5);
	
}

void CLegitTab::Setup()
{
SetTitle("LegetBot");
RegisterControl(&Menu::Window.SettingsFile);
RegisterControl(&Menu::Window.UserLabel);


AimbotGroup.SetPosition(10, 10);
AimbotGroup.SetSize(680, 50);
AimbotGroup.SetText("Aim boat");
AimbotGroup.SetColumns(2);
RegisterControl(&AimbotGroup);

AimbotGroup.PlaceLabledControl("Enable", this, &AimbotEnable, 0, 0);
AimbotGroup.PlaceLabledControl("Auto Fire", this, &AimbotAutoFire, 1, 0);
AimbotGroup.PlaceLabledControl("Use Key", this, &AimbotKeyPress, 0, 1);
AimbotGroup.PlaceLabledControl("Key-Bind", this, &AimbotKeyBind, 1, 1);
AimbotGroup.PlaceLabledControl("AutoPistol", this, &AimbotAutoPistol, 0, 2);
AimbotInaccuracy.SetBoundaries(0.f, 100.f);
AimbotGroup.PlaceLabledControl("Inaccuracy", this, &AimbotInaccuracy, 1, 2);


WeaponMainGroup.SetPosition(10, GetNextGroupboxY(&AimbotGroup));
WeaponMainGroup.SetSize(680, 50);
WeaponMainGroup.SetText("Rifles and Misc");
WeaponMainGroup.SetColumns(2);
RegisterControl(&WeaponMainGroup);

WeaponMainSpeed.SetBoundaries(0.001f, 1.f);
WeaponMainSpeed.SetValue(0.1f);
WeaponMainGroup.PlaceLabledControl("Speed", this, &WeaponMainSpeed, 0, 0);
WeaponMainFoV.SetBoundaries(0.1f, 20.f);
WeaponMainFoV.SetValue(2.f);
WeaponMainGroup.PlaceLabledControl("FoV", this, &WeaponMainFoV, 1, 0);
WeaponMainRecoil.SetState(true);
WeaponMainGroup.PlaceLabledControl("Recoil", this, &WeaponMainRecoil, 0, 1);
WeaponMainHitbox.AddItem("Head");
WeaponMainHitbox.AddItem("Neck");
WeaponMainHitbox.AddItem("Chest");
WeaponMainHitbox.AddItem("Stomach");
WeaponMainGroup.PlaceLabledControl("HitBox", this, &WeaponMainHitbox, 1, 1);

WeaponPistGroup.SetPosition(10, GetNextGroupboxY(&WeaponMainGroup));
WeaponPistGroup.SetSize(680, 50);
WeaponPistGroup.SetText("Pistols");
WeaponPistGroup.SetColumns(2);
RegisterControl(&WeaponPistGroup);

WeaponPistSpeed.SetBoundaries(0.001f, 1.f);
WeaponPistSpeed.SetValue(0.1f);
WeaponPistGroup.PlaceLabledControl("Speed", this, &WeaponPistSpeed, 0, 0);
WeaponPistFoV.SetBoundaries(0.1f, 20.f);
WeaponPistFoV.SetValue(2.f);
WeaponPistGroup.PlaceLabledControl("FoV", this, &WeaponPistFoV, 1, 0);
WeaponPistGroup.PlaceLabledControl("Recoil", this, &WeaponPistRecoil, 0, 1);
WeaponPistHitbox.AddItem("Head");
WeaponPistHitbox.AddItem("Neck");
WeaponPistHitbox.AddItem("Chest");
WeaponPistHitbox.AddItem("Stomach");
WeaponPistGroup.PlaceLabledControl("HitBox", this, &WeaponPistHitbox, 1, 1);

WeaponSnipGroup.SetPosition(10, GetNextGroupboxY(&WeaponPistGroup));
WeaponSnipGroup.SetSize(680, 50);
WeaponSnipGroup.SetText("Snipers");
WeaponSnipGroup.SetColumns(2);
RegisterControl(&WeaponSnipGroup);

WeaponSnipSpeed.SetBoundaries(0.001f, 1.f);
WeaponSnipSpeed.SetValue(0.1f);
WeaponSnipGroup.PlaceLabledControl("Speed", this, &WeaponSnipSpeed, 0, 0);
WeaponSnipFoV.SetBoundaries(0.1f, 20.f);
WeaponSnipFoV.SetValue(2.f);
WeaponSnipGroup.PlaceLabledControl("FoV", this, &WeaponSnipFoV, 1, 0);
WeaponSnipGroup.PlaceLabledControl("Recoil", this, &WeaponSnipRecoil, 0, 1);
WeaponSnipHitbox.AddItem("Head");
WeaponSnipHitbox.AddItem("Neck");
WeaponSnipHitbox.AddItem("Chest");
WeaponSnipHitbox.AddItem("Stomach");
WeaponSnipGroup.PlaceLabledControl("HitBox", this, &WeaponSnipHitbox, 1, 1);

ModGroup.SetPosition(10, GetNextGroupboxY(&WeaponSnipGroup));
ModGroup.SetSize(680, 50);
ModGroup.SetText("Modifier Key");
ModGroup.SetColumns(2);
RegisterControl(&ModGroup);

ModGroup.PlaceLabledControl("Key-Bind", this, &ModKey, 0, 0);
ModSpeed.SetBoundaries(0.001f, 1.f);
ModSpeed.SetValue(0.1f);
ModGroup.PlaceLabledControl("Speed", this, &ModSpeed, 0, 1);
ModFoV.SetBoundaries(0.1f, 20.f);
ModFoV.SetValue(2.f);
ModGroup.PlaceLabledControl("FoV", this, &ModFoV, 1, 1);
ModHitbox.AddItem("Head");
ModHitbox.AddItem("Neck");
ModHitbox.AddItem("Chest");
ModHitbox.AddItem("Stomach");
ModGroup.PlaceLabledControl("HitBox", this, &ModHitbox, 0, 2);
}

void CVisualsTab::Setup()
{
	SetTitle("Visuals");
	RegisterControl(&Menu::Window.SettingsFile);
	//RegisterControl(&Menu::Window.UserLabel);


	grpOptions.SetPosition(10, 10);
	grpOptions.SetSize(680, 50);
	grpOptions.SetText("Options");
	grpOptions.SetColumns(2);
	RegisterControl(&grpOptions);
	OptionsBox.AddItem("OFF");
	OptionsBox.AddItem("Box");
	OptionsBox.AddItem("Corner Box");
	OptionsBox.AddItem("Border Box");
	//OptionsBox.AddItem("Corner Box");
	grpOptions.PlaceLabledControl("Draw Box", this,	&OptionsBox,			0, 0);
	grpOptions.PlaceLabledControl("Draw Name", this, &OptionsName,			1, 0);
	OptionsHealth.AddItem("OFF");
	OptionsHealth.AddItem("Text");
	OptionsHealth.AddItem("AyyBar");
	OptionsHealth.AddItem("HealthBar");
	grpOptions.PlaceLabledControl("Draw Health", this, &OptionsHealth,		0, 1);
	grpOptions.PlaceLabledControl("Draw Weapon", this, &OptionsWeapon,		1, 1);
	grpOptions.PlaceLabledControl("Draw Info", this, &OptionsInfo,	0, 2);
	grpOptions.PlaceLabledControl("Draw Bones", this, &OptionsSkeleton,		1, 2);
	grpOptions.PlaceLabledControl("Draw Aim Spot", this, &OptionsAimSpot,	0, 3);
	grpOptions.PlaceLabledControl("Draw TraceLine", this, &OptionsTrace,		1, 3);

	grpFilters.SetPosition(10, GetNextGroupboxY(&grpOptions));
	grpFilters.SetSize(680, 55);
	grpFilters.SetText("Filters");
	grpFilters.SetColumns(1);
	RegisterControl(&grpFilters);

	grpFilters.PlaceLabledControl("Players", this, &FiltersPlayers, 0, 0);
	grpFilters.PlaceLabledControl("Only Enemies", this, &FiltersEnemiesOnly, 0, 1);
	grpFilters.PlaceLabledControl("Items", this, &FiltersWeapons, 0, 2);
	grpFilters.PlaceLabledControl("Chickens", this, &FiltersChickens, 0, 3);
	//grpFilters.PlaceLabledControl("Bomb", this, &FiltersC4, 0, 4);

	grpOther.SetPosition(10, GetNextGroupboxY(&grpFilters));
	grpOther.SetSize(680, 50);
	grpOther.SetText("Other Visuals");
	grpOther.SetColumns(1);
	RegisterControl(&grpOther);

	cboChams.AddItem("None");
	cboChams.AddItem("Normal");
	cboChams.AddItem("Flat");
	grpOther.PlaceLabledControl("Chams", this, &cboChams, 0, 0);
	grpOther.PlaceLabledControl("No Visual Recoil", this, &OtherNoVisualRecoil, 0, 2);
	grpOther.PlaceLabledControl("Recoil Crosshair", this, &OtherRecoilCrosshair, 0, 3);
	grpOther.PlaceLabledControl("CrossHair", this, &OtherCrosshair, 0, 4);
	//.PlaceLabledControl("No Flash", this, &OtherNoFlash, 0, 5);
	//grpOther.PlaceLabledControl("No Smoke", this, &OtherNoSmoke, 0, 6);
	grpOther.PlaceLabledControl("Hands Type", this, &OtherNoHands, 0, 1);
	OtherNoHands.AddItem("Off");
	OtherNoHands.AddItem("None");
	OtherNoHands.AddItem("Transparent");
	OtherNoHands.AddItem("Chams");
	OtherNoHands.AddItem("Rainbow");
	OtherNoHands.AddItem("WireFrame");
	grpOther.PlaceLabledControl("NoFlash", this, &OtherNoFlash, 0, 5);
	grpOther.PlaceLabledControl("RadarHack (InGame)", this, &RadarHack, 0, 6);
}

void CMiscTab::Setup()
{
	SetTitle("Misc");
	RegisterControl(&Menu::Window.SettingsFile);
	//RegisterControl(&Menu::Window.UserLabel);


	grpMisc.SetPosition(10, 10);
	grpMisc.SetSize(680, 65);
	grpMisc.SetText("Misc");
	grpMisc.SetColumns(1);
	RegisterControl(&grpMisc);

	
	grpMisc.PlaceLabledControl("Bunnyhop", this, &OtherBhop, 0, 0);
	grpMisc.PlaceLabledControl("Auto-Strafe", this, &OtherAutoStrafe, 0, 1);
	grpMisc.PlaceLabledControl("Circle Strafe", this, &OtherAutoCircle, 0, 2);
	grpMisc.PlaceLabledControl("Teleport Hack", this, &OtherTeleportHack, 0, 3);
	grpMisc.PlaceLabledControl("sv_cheats 1", this, &OtherBypass, 0, 4);
	cboChatSpam.AddItem("Off");
	cboChatSpam.AddItem("Promo");
	cboChatSpam.AddItem("AW Suck");
	cboChatSpam.AddItem("Players Info");

	
	grpMisc.PlaceLabledControl("Chat Spam", this, &cboChatSpam, 0, 5);
	cboNameSpam.AddItem("None");
	cboNameSpam.AddItem("Hide My Name");
	cboNameSpam.AddItem("ALI3NW4RE");
	cboNameSpam.AddItem("AIMWARE");
	cboNameSpam.AddItem("Colored");
	
	grpMisc.PlaceLabledControl("Name Changer", this, &cboNameSpam, 0, 6);
	grpMisc.PlaceLabledControl("Air Stuck", this, &keyAirStuck, 0, 7);
	//grpMisc.PlaceLabledControl("Lag Exploit", this, &OtherServerLag, 0, 8);
	ClanTagChanger.AddItem("OFF");
	ClanTagChanger.AddItem("ALI3NW4RE");
	ClanTagChanger.AddItem("VALVE");
	ClanTagChanger.AddItem("STAINLESS");
	ClanTagChanger.AddItem("Memeless");
	ClanTagChanger.AddItem("ALIENWARE SMALL");
	grpMisc.PlaceLabledControl("Clan Tag Changer", this, &ClanTagChanger, 0, 8);
	AutoBuy.AddItem("OFF");
	AutoBuy.AddItem("MM - Normal");
	AutoBuy.AddItem("MM - Noobie");
	AutoBuy.AddItem("NoSpread - Normal");
	grpMisc.PlaceLabledControl("AutoBuy", this, &AutoBuy, 0, 9);
	grpMisc.PlaceLabledControl("FovChanger", this, &FovEnable, 0, 10);
	Fovamount.SetBoundaries(-90.f, 180.f);
	Fovamount.SetValue(0.f);
	grpMisc.PlaceLabledControl("Value", this, &Fovamount, 0, 11);
	grpMisc.PlaceLabledControl("Game Unload", this, &Unload, 0, 12);


	/*grpSkins.SetPosition(10, GetNextGroupboxY(&grpMisc));
	grpSkins.SetSize(680, 50);
	grpSkins.SetText("Skins");
	grpSkins.SetColumns(1);
	RegisterControl(&grpSkins);

	SkinKnife.AddItem("None");
	SkinKnife.AddItem("Bayonet");
	SkinKnife.AddItem("Butterfly");
	SkinKnife.AddItem("Flip");
	SkinKnife.AddItem("Gun Game");
	SkinKnife.AddItem("Gut");
	SkinKnife.AddItem("Karambit");
	SkinKnife.AddItem("M9");
	SkinKnife.AddItem("Huntsman");
	SkinKnife.AddItem("Falchion");
	SkinKnife.AddItem("Dagger");
	grpSkins.PlaceLabledControl("Knife", this, &SkinKnife, 0, 0);*/


}

void CHvHTab::Setup()
{
	SetTitle("HvH");
	RegisterControl(&Menu::Window.SettingsFile);
	//RegisterControl(&Menu::Window.UserLabel);


	grpAA.SetPosition(10, 10);
	grpAA.SetSize(680, 50);
	grpAA.SetText("Anti-Aim");
	grpAA.SetColumns(2);
	RegisterControl(&grpAA);

	grpAA.PlaceLabledControl("Enable", this, &AntiAimEnable, 0, 0);
	AntiAimPitch.AddItem("None"); //0
	AntiAimPitch.AddItem("Up"); //1
	AntiAimPitch.AddItem("Emotion"); //2
	AntiAimPitch.AddItem("Jitter"); //3
	AntiAimPitch.AddItem("Angle Down"); //3
	AntiAimPitch.AddItem("Angle UP"); //4
	AntiAimPitch.AddItem("Lisp Down"); //5
	AntiAimPitch.AddItem("Lisp UP"); //6
	AntiAimPitch.AddItem("Fake Down"); //6
	AntiAimPitch.AddItem("Fake Zero"); //6
	AntiAimPitch.AddItem("Lisp Jitter"); //6
	grpAA.PlaceLabledControl("Pitch", this, &AntiAimPitch, 0, 1);

	AntiAimYaw.AddItem("None"); //0
	AntiAimYaw.AddItem("Spin Fast"); //1
	AntiAimYaw.AddItem("Spin Slow"); //2
	AntiAimYaw.AddItem("Angle BackWard"); //3
	AntiAimYaw.AddItem("BackWards"); //3
	AntiAimYaw.AddItem("SideWays"); //3
	AntiAimYaw.AddItem("SideWays (Untrusted)"); //3
	AntiAimYaw.AddItem("Lisp 1 (Jitter)"); //3
	AntiAimYaw.AddItem("Lisp 2 (Spin)"); //3
	AntiAimYaw.AddItem("Lisp 3 (Head)"); //3
	AntiAimYaw.AddItem("Lisp 4 (Body)"); //3
	AntiAimYaw.AddItem("Lisp 5 (SideWays)");
	AntiAimYaw.AddItem("Lisp 6 (Fake 1)"); //3
	AntiAimYaw.AddItem("Lisp 7 (Fake 2)"); //3
	AntiAimYaw.AddItem("Lisp 8 (Fake 3)");
	AntiAimYaw.AddItem("Fake BackWard");
	AntiAimYaw.AddItem("Jitter Over");
	AntiAimYaw.AddItem("Jitter BackWard");
	AntiAimYaw.AddItem("Jitter Synced");
	//AntiAimYaw.AddItem("BackWard At Enemy");



	grpAA.PlaceLabledControl("Yaw", this, &AntiAimYaw, 1, 1);
	AntiAimEdge.AddItem("None");
	AntiAimEdge.AddItem("Normal");
	AntiAimEdge.AddItem("Wall Out");
	grpAA.PlaceLabledControl("Edge Type", this, &AntiAimEdge, 0, 2);
	grpAA.PlaceLabledControl("ThirdPerson Anti-Aim", this, &ThirdPersonAA, 1, 2);
	

	grpHvH.SetPosition(10, GetNextGroupboxY(&grpAA));
	grpHvH.SetSize(680, 55);
	grpHvH.SetText("Misc HvH");
	grpHvH.SetColumns(2);
	RegisterControl(&grpHvH);
	
	AntiUntrusted.SetState(true);
	grpHvH.PlaceLabledControl("Anti-Untrusted", this, &AntiUntrusted, 0, 1);
	grpHvH.PlaceLabledControl("No Spread", this, &NoSpread, 0, 2);
	grpHvH.PlaceLabledControl("Fakelag", this, &FakeLagEnable, 0, 3);
	FakeLagAmount.SetBoundaries(0.f, 20.f);
	FakeLagAmount.SetValue(0.f);
	grpHvH.PlaceLabledControl("Fakelag Amount", this, &FakeLagAmount, 0, 4);


}

void CPlayersTab::Setup()
{
	SetTitle("HitScan");
	RegisterControl(&Menu::Window.SettingsFile);
	
	RegisterControl(&Menu::Window.SettingsFile);
	//RegisterControl(&Menu::Window.UserLabel);


	RadarList.SetPosition(10, 10);
	RadarList.SetSize(1000, 50);
	RadarList.SetText("HitScan");
	RadarList.SetColumns(1);
	RegisterControl(&RadarList);

	
	RadarList.PlaceLabledControl("Enabled", this, &OtherRadar,0,0);

	
	RadarList.PlaceLabledControl("Head", this, &OtherRadarEnemyOnly,0,1);

	RadarList.PlaceLabledControl("Upper Neck", this, &OtherRadarVisibleOnly, 1, 1);

	RadarList.PlaceLabledControl("Neck", this, &OtherRadarVisibleOnly, 1,1);



	
	OtherRadarScale.SetBoundaries(0, 10000);
	OtherRadarScale.SetValue(10000);
	RadarList.PlaceLabledControl("Radar Range", this, &OtherRadarScale,0,3);
	
}

DWORD GetPlayerListIndex(int EntId)
{
	player_info_t pinfo;
	Interfaces::Engine->GetPlayerInfo(EntId, &pinfo);

	// Bot
	if (pinfo.guid[0] == 'B' && pinfo.guid[1] == 'O')
	{
		char buf[64]; sprintf_s(buf, "BOT_420%sAY", pinfo.name);
		return CRC32(buf, 64);
	}
	else
	{
		return CRC32(pinfo.guid, 32);
	}
}

bool IsFriendly(int EntId)
{
	DWORD plistId = GetPlayerListIndex(EntId);
	if (PlayerList.find(plistId) != PlayerList.end())
	{
		return PlayerList[plistId].Friendly;
	}

	return false;
}

bool IsAimPrio(int EntId)
{
	DWORD plistId = GetPlayerListIndex(EntId);
	if (PlayerList.find(plistId) != PlayerList.end())
	{
		return PlayerList[plistId].AimPrio;
	}

	return false;
}

bool IsCalloutTarget(int EntId)
{
	DWORD plistId = GetPlayerListIndex(EntId);
	if (PlayerList.find(plistId) != PlayerList.end())
	{
		return PlayerList[plistId].Callout;
	}

	return false;
}

void UpdatePlayerList()
{
	IClientEntity* pLocal = Interfaces::EntList->GetClientEntity(Interfaces::Engine->GetLocalPlayer());
	if (Interfaces::Engine->IsConnected() && Interfaces::Engine->IsInGame() && pLocal && pLocal->IsAlive())
	{
		Menu::Window.PlayersTab.lstPlayers.ClearItems();

		// Loop through all active entitys
		for (int i = 0; i < Interfaces::EntList->GetHighestEntityIndex(); i++)
		{
			// Get the entity
			
			player_info_t pinfo;
			if (i != Interfaces::Engine->GetLocalPlayer() && Interfaces::Engine->GetPlayerInfo(i, &pinfo))
			{
				IClientEntity* pEntity = Interfaces::EntList->GetClientEntity(i);
				int HP = 100; char* Location = "Unknown";
				char *Friendly = " ", *AimPrio = " ";
				
				DWORD plistId = GetPlayerListIndex(Menu::Window.PlayersTab.lstPlayers.GetValue());
				if (PlayerList.find(plistId) != PlayerList.end())
				{
					Friendly = PlayerList[plistId].Friendly?"Friendly":"";
					AimPrio = PlayerList[plistId].AimPrio?"AimPrio":"";
				}
				 
			    if (pEntity && !pEntity->IsDormant())
				{
					HP = pEntity->GetHealth();
					Location = pEntity->GetLastPlaceName();
				}
				
				char nameBuffer[512];
				sprintf_s(nameBuffer, "%-24s %-10s %-10s [%d HP] [Last Seen At %s]", pinfo.name, IsFriendly(i)?"Friend":" ", IsAimPrio(i)?"AimPrio":" ", HP, Location);
				Menu::Window.PlayersTab.lstPlayers.AddItem(nameBuffer, i);
				
			}
			
		}

		DWORD meme = GetPlayerListIndex(Menu::Window.PlayersTab.lstPlayers.GetValue());

		// Have we switched to a different player?
		static int PrevSelectedPlayer = 0;
		if (PrevSelectedPlayer != Menu::Window.PlayersTab.lstPlayers.GetValue())
		{
			if (PlayerList.find(meme) != PlayerList.end())
			{
				Menu::Window.PlayersTab.PlayerFriendly.SetState(PlayerList[meme].Friendly);
				Menu::Window.PlayersTab.PlayerAimPrio.SetState(PlayerList[meme].AimPrio);
				Menu::Window.PlayersTab.PlayerCalloutSpam.SetState(PlayerList[meme].Callout);

			}
			else
			{
				Menu::Window.PlayersTab.PlayerFriendly.SetState(false);
				Menu::Window.PlayersTab.PlayerAimPrio.SetState(false);
				Menu::Window.PlayersTab.PlayerCalloutSpam.SetState(false);

			}
		}
		PrevSelectedPlayer = Menu::Window.PlayersTab.lstPlayers.GetValue();

		PlayerList[meme].Friendly = Menu::Window.PlayersTab.PlayerFriendly.GetState();
		PlayerList[meme].AimPrio = Menu::Window.PlayersTab.PlayerAimPrio.GetState();
		PlayerList[meme].Callout = Menu::Window.PlayersTab.PlayerCalloutSpam.GetState();

	}
}
/*
AyyWare 2 - Extreme Alien Technology
By Syn
*/

#pragma once

#include "GUI.h"
#include "Controls.h"
#include <map>
struct PlayerListItem_t
{
	bool Friendly;
	bool AimPrio;
	bool Callout;
};

DWORD GetPlayerListIndex(int EntId);
bool IsFriendly(int EntId);
bool IsAimPrio(int EntId);
bool IsCalloutTarget(int EntId);


extern std::map<DWORD, PlayerListItem_t> PlayerList;

class CRageTab : public CTab
{
public:
	void Setup();

	CGroupBox grpAimbot;
	CCheckBox AimbotEnable;
	CCheckBox AimbotAutoFire;
	CSlider	  AimbotFov;
	CComboBox AimbotSilentAim;
	CCheckBox AimbotPSilent;
	CCheckBox AimbotAutoPistol;
	CCheckBox AimbotKeyPress;
	CKeyBind  AimbotKeyBind;
	CComboBox AimbotAimstep;
	CCheckBox OtherEnginePrediction;
	CGroupBox grpTarget;
	CComboBox TargetSelection;
	CCheckBox TargetFriendlyFire;
	CComboBox TargetHitbox;
	CComboBox TargetHitscan;
	CComboBox TargetMultiPoint;
	CSlider TargetPointScale;

	CGroupBox grpAccuracy;
	//CCheckBox AccuracySpread;
	CCheckBox AccuracyRecoil;
	CCheckBox AccuracyAutoWall;
	CCheckBox AccuracyResolver;
	CCheckBox AccuracyResolverYaw;
	//CSlider	  AccuracyMinimumDamage;
	CCheckBox AccuracyAutoStop;
	CCheckBox AccuracyAutoScope;
	CCheckBox AccuracyAutoCrouch;
	CCheckBox AccuracySpreadLimit;
	CSlider	  AccuracyMinimumSpread;
};

class CLegitTab : public CTab
{
public:
	void Setup();

	// Aimbot Settings
	CGroupBox AimbotGroup;
	CCheckBox AimbotEnable;
	CCheckBox AimbotAutoFire;
	CCheckBox AimbotKeyPress;
	CKeyBind  AimbotKeyBind;
	CCheckBox AimbotAutoPistol;
	CSlider   AimbotInaccuracy;


	// Main
	CGroupBox WeaponMainGroup;
	CSlider   WeaponMainSpeed;
	CSlider   WeaponMainFoV;
	CCheckBox WeaponMainRecoil;
	CComboBox WeaponMainHitbox;

	// Pistol
	CGroupBox WeaponPistGroup;
	CSlider   WeaponPistSpeed;
	CSlider   WeaponPistFoV;
	CCheckBox WeaponPistRecoil;
	CComboBox WeaponPistHitbox;

	// Sniper
	CGroupBox WeaponSnipGroup;
	CSlider   WeaponSnipSpeed;
	CSlider   WeaponSnipFoV;
	CCheckBox WeaponSnipRecoil;
	CComboBox WeaponSnipHitbox;

	// Mod Key
	CGroupBox ModGroup;
	CKeyBind  ModKey;
	CSlider   ModSpeed;
	CSlider   ModFoV;
	CComboBox ModHitbox;

};

class CVisualsTab : public CTab
{
public:
	void Setup();

	CGroupBox grpOptions;
	CComboBox OptionsBox;
	CCheckBox OptionsName;
	CComboBox OptionsHealth;
	CCheckBox OptionsWeapon;
	CCheckBox OptionsInfo;
	CCheckBox OptionsSkeleton;
	CCheckBox OptionsTrace;
	CCheckBox OptionsAimSpot;
	CCheckBox OptionsCompRank;

	CGroupBox grpFilters;
	CCheckBox FiltersPlayers;
	CCheckBox FiltersEnemiesOnly;
	CCheckBox FiltersWeapons;
	CCheckBox FiltersChickens;
	CCheckBox FiltersC4;

	CGroupBox grpOther;
	CCheckBox OtherCrosshair;
	CCheckBox OtherRecoilCrosshair;
	CCheckBox OtherNoVisualRecoil;
	CCheckBox OtherHitmarker;
	CCheckBox OtherNoFlash;
	CCheckBox RadarHack;
	CCheckBox OtherNoSmoke;
	CComboBox OtherNoHands;
	CComboBox cboChams;
};

class CMiscTab : public CTab
{
public:
	void Setup();

	CGroupBox grpMisc;
	
	CCheckBox OtherBhop;
	CCheckBox OtherBypass;
	CCheckBox OtherAutoStrafe;
	CCheckBox OtherTeleportHack;
	CComboBox cboChatSpam;
	CComboBox cboNameSpam;
	CKeyBind keyAirStuck;
	CCheckBox OtherServerLag;
	CCheckBox OtherAutoCircle;
	CComboBox ClanTagChanger;
	CComboBox AutoBuy;
	CCheckBox FovEnable;
	CSlider Fovamount;
	CCheckBox Unload;
	CGroupBox grpSkins;
	CComboBox SkinKnife;
};

class CPlayersTab : public CTab
{
public:
	void Setup();
	CGroupBox RadarList;
	CListBox lstPlayers;

	CCheckBox PlayerFriendly;
	CCheckBox PlayerAimPrio;
	CCheckBox PlayerCalloutSpam;
	CCheckBox OtherRadar;
	CCheckBox OtherRadarEnemyOnly;
	CCheckBox OtherRadarVisibleOnly;
	CSlider	  OtherRadarScale;
	CSlider OtherRadarXPosition;
	CSlider OtherRadarYPosition;

};

class CHvHTab : public CTab
{
public:
	void Setup();
	CGroupBox grpAA;
	CCheckBox AntiAimEnable;
	CComboBox AntiAimPitch;
	CComboBox AntiAimYaw;
	CComboBox AntiAimEdge;
	CCheckBox AccuracyAngleFix;

	CGroupBox grpHvH;
	CCheckBox FakeLagEnable;
	CSlider FakeLagAmount;
	CCheckBox AntiUntrusted;
	CCheckBox NoSpread;
	CCheckBox ThirdPersonAA;
};

class AyyWareWindow : public CWindow
{
public:
	void Setup();

	CRageTab RageBotTab;
	CLegitTab LegitBotTab;
	CVisualsTab VisualsTab;
	CMiscTab MiscTab;
	CPlayersTab PlayersTab;
	CHvHTab HvHTab;

	CComboBox SettingsFile;
	CLabel UserLabel;
	
};

namespace Menu
{
	extern AyyWareWindow Window;
	void DoFrame();
	void Initialize();
};
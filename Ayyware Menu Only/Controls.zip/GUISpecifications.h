/*
AyyWare 2 - Extreme Alien Technology
By Syn
*/

#pragma once

#define UI_CURSORSIZE		12
#define UI_CURSORFILL		Color(255,255,255)
#define UI_CURSOROUTLINE	Color(20,20,20,140)

#define UI_WIN_TOPHEIGHT	26
#define UI_WIN_TITLEHEIGHT	32

#define UI_TAB_WIDTH		200
#define UI_TAB_HEIGHT		32

#define UI_WIN_CLOSE_X		20
#define UI_WIN_CLOSE_Y      6

#define UI_CHK_SIZE			16

#define COL_WHITE			Color(255, 255, 255)
#define UI_COL_MAIN			Color(27, 206, 94, 255)
#define UI_COL_MAINDARK		Color(113, 236, 159, 255)
#define UI_COL_FADEMAIN		Color(27, 206, 94, 40)
#define UI_COL_SHADOW		Color(25, 25, 25, 100)
#define UI_COL_CLIENTBACK	Color(238, 238, 238, 255)
#define UI_COL_TABSEPERATOR	Color(229, 229, 229, 255)
#define UI_COL_TABTEXT		Color(145, 145, 145, 255)
#define UI_COL_GROUPOUTLINE Color(222, 222, 222, 255)